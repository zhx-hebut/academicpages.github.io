# Multi-ConDoS: Multimodality Contrastive Domain Sharing for Self-Supervised Medical Image Segmentation

This repository is the official implementation of IEEE paper [Multi-ConDoS: Multimodality Contrastive Domain Sharing for Self-Supervised Medical Image Segmentation](https://ieeexplore.ieee.org/document/10167829). 

## Requirements

To install requirements :

```setup
conda env create -r env.yml
```

To download datasets :
- [MICCAI 2020: HECKTOR](https://www.aicrowd.com/challenges/hecktor)
- [BraTS 2018](https://www.med.upenn.edu/sbia/brats2018.html)

## For pre-training

To train the DSGAN model in the paper, run this command

```shell
python pytorch-DSGAN/train.py
```

## For fine-tuning

To train the downstream network, run this command
- for hecktor :

```shell
python torch_unet_z/train_Hecktor.py
```
 
- for brats :
```shell
python torch_unet_z/train_BraTS.py
```


## Evaluation

To evaluate my model
- for hecktor :
```shell
python torch_unet_z/predict.py 
```  
- for brats2018 :
```shell
python torch_unet_z/predict_3c.py 
```

## Citation

If Multi-ConDoS is used in your research, please cite the following article in your paper:
```
@article{Jiaojiao-TMI2023,
  author={Zhang, Jiaojiao and Zhang, Shuo and Shen, Xiaoqian and Lukasiewicz, Thomas and Xu, Zhenghua},
  journal={IEEE Transactions on Medical Imaging}, 
  title={Multi-ConDoS: Multimodal Contrastive Domain Sharing Generative Adversarial Networks for Self-Supervised Medical Image Segmentation}, 
  year={2023},
  volume={Early Access},
  pages={1-20},
  doi={10.1109/TMI.2023.3290356}}
```

Please also consider citing the following article in your paper:
```
@article{ZHANG-MIA2022,
title = {Multi-modal contrastive mutual learning and pseudo-label re-learning for semi-supervised medical image segmentation},
journal = {Medical Image Analysis},
pages = {102656},
year = {2023},
volume = {83},
author = {Shuo Zhang and Jiaojiao Zhang and Biao Tian and Thomas Lukasiewicz and Zhenghua Xu}
}
```

## Acknowledgements
- The code is developed based on [CycleGAN](https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix) and [SimCLR](https://github.com/Spijkervet/SimCLR).

If you have some issues, please contact 2195468073@qq.com

<!-- >📋  Pick a licence and describe how to contribute to your code repository.  -->
