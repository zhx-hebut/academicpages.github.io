import os
import time
import argparse
import logging
import numpy as np
import pandas as pd
import torch
import skimage.io as io
import torch.nn.functional as F
from PIL import Image
import matplotlib.pyplot as plt
from utils.metrics import dice
from utils.util import read_list
#from nets.unet import UNet
from nets.unet import UNet
#from train_00_transfer import set_argparse
import SimpleITK as sitk
plt.switch_backend('agg')
import warnings
warnings.filterwarnings("ignore")
def save_imgs(img_mode,out_path,img_np,true_mask,pred_mask,patientSliceID,dice_val,exp):
    # '''保存 pet'''
    # pet_np = img[:,:,0]
    # pet_np = pet_np.astype('uint8')
    # pet_img = Image.fromarray(pet_np)
    # pet_img.save('{}/{}_pet.jpg'.format(out_path,patientSliceID), cmap="gray")

    '''保存 ct'''
    # ct_np = img[:,:,1]
    # ct_np = img.astype('uint8')
    # mask_img = Image.fromarray(ct_np)
    # mask_img.save('{}/{}_ct.jpg'.format(out_path,patientSliceID), cmap="gray")

    io.imsave('{}/{}_img{}.jpg'.format(out_path,patientSliceID,exp),img_np)

    '''保存 true mask'''
    true_mask = true_mask * 255
    mask_true_img = Image.fromarray(true_mask)
    mask_true_img.save('{}/{}_true{}.png'.format(out_path,patientSliceID,exp), cmap="gray")

    '''保存 pred mask'''
    pred_mask_gray = pred_mask * 255
    pred_mask_img = Image.fromarray(pred_mask_gray)
    pred_mask_img.save('{}/{}_pred_{:.4f}{}.png'.format(out_path,patientSliceID,dice_val,exp), cmap="gray")
    # np.save('{}/{}_pred_{:.4f}.npy'.format(out_path,patientSliceID,dice_val),pred_mask)# (160, 160) dtype('uint8') 值为0 1 2 4
    def save_plt(num,np,title):
        plt.subplot(2,2,num)
        plt.imshow(np, cmap="gray")
        plt.axis('off')
        plt.title(title)

    save_plt(1,img_np,img_mode)
    save_plt(2,img_np,img_mode)
    save_plt(3,true_mask,"true mask")
    save_plt(4,pred_mask,title="pred mask-dice:{:.4f}".format(dice_val))
    # patientSliceID = patientSliceID.replace("_slice_","_")
    plt.savefig('{}/{}{}.png'.format(out_path,patientSliceID,exp))
    plt.show()

def predict_img(net,device,true_mask,init_img,scale_factor=1,out_threshold=0.5):
    """
    测试一张图片
    :return: list
    """
    # step 1/4 : path --> img_chw
    if len(init_img.shape) == 2:
        img_chw = np.expand_dims(init_img, axis=0)
    else:
        img_chw = init_img
    # img_chw = img_chw / 255
    # step 2/4 : img --> tensor
    img_tensor = torch.tensor(img_chw).to(torch.float32)
    img_tensor.unsqueeze_(0)  #or img = img.unsqueeze(0)
    img_tensor = img_tensor.to(device)
    # step 3/4 : tensor --> features
    time_tic = time.time()
    outputs = net(img_tensor)
    time_toc = time.time()
    time_s = time_toc - time_tic
    # print("time is ",time_s)
    pred_mask = outputs.ge(out_threshold).cpu().data.numpy().astype("uint8")
    pred_mask = pred_mask.squeeze()
    dice_val,PPV_val,sen_val = dice(pred_mask, true_mask)

    return pred_mask,dice_val,PPV_val,sen_val,time_s

def test_images(net,device,img_path,true_path,in_files,out_path=None,is_save_img=True,exp=''):
    img_mode = img_path.split('/')[-1].split('_')[-1]
    dice_total = 0.
    mean_dice= 0.
    PPV_total = 0.
    mean_PPV= 0.
    sen_total = 0.
    mean_sen = 0.
    for i, file_name in enumerate(in_files):
        # print("{}.Predicting image {} ...".format(i,file_name))
        path_file = os.path.join(img_path, file_name+'.npy')
        true_file = os.path.join(true_path, file_name+'.npy')
        namesplit = os.path.splitext(file_name)
        patientSliceID = namesplit[0]
        # img = Image.open(fn)  ##when data is image,jpg,png...
        img = np.load(path_file)       ##when data is npy
        true_mask = np.load(true_file)
        pred_mask ,dice_val ,PPV_val,sen_val,time_s = predict_img(net,device,true_mask,init_img=img,scale_factor=1,out_threshold=0.5)
        dice_total += dice_val 
        logging.info("Patient [{}] dice is [{:.4f}]. Time consuming is {:.4f}".format(patientSliceID,dice_val,time_s))
        PPV_total += PPV_val 
        #logging.info("Patient [{}] PPV is [{:.4f}]. Time consuming is {:.4f}".format(patientSliceID,PPV_val,time_s))
        sen_total += sen_val 
        #logging.info("Patient [{}] Sensitivity is [{:.4f}]. Time consuming is {:.4f}".format(patientSliceID,sen_val,time_s))
        


        if is_save_img==True:
            save_imgs(img_mode,out_path,img,true_mask,pred_mask,patientSliceID,dice_val,exp)
    mean_dice = dice_total / (i+1)
    mean_PPV = PPV_total / (i+1)
    mean_sen = sen_total / (i+1)
    return mean_dice,mean_PPV,mean_sen

def test_volumes(net,device,img_path,true_path,in_files,out_path=None):
    img_mode = img_path.split('/')[-1].split('_')[-1]
    slice_len = len(in_files)
    path_file1 = os.path.join(true_path, in_files[0]+'.npy')
    # print("zjj:",np.load(path_file1).shape) (144,144)
    w,h = np.load(path_file1).shape
    test_img_tensor = np.zeros((slice_len,1,w,h),np.float32)
    test_img_tensor_2c = np.zeros((slice_len,2,w,h),np.float32)
    image_3d_true = np.zeros((slice_len,w,h),np.uint8)
    img_shape = 0
    for i, file_name in enumerate(in_files):
        # print("{}.Predicting image {} ...".format(i,file_name))
        path_file = os.path.join(img_path, file_name+'.npy')
        true_file = os.path.join(true_path, file_name+'.npy')
        patient_name = file_name.split('.')[0]
        patient_slice = patient_name.split('_')[-1]
        patient_slice = int(patient_slice) - 1
        # img = Image.open(fn)  ##when data is image,jpg,png...
        img = np.load(path_file)       ##when data is npy
        true_mask = np.load(true_file)
        # step 1/4 : path --> img_chw
        if len(img.shape) == 2:
            img_shape = 2
            img_chw = np.expand_dims(img, axis=0)
            test_img_tensor[patient_slice] = img_chw
        else:
            img_shape = 3
            img_chw = img
            test_img_tensor_2c[patient_slice] = img_chw
        image_3d_true[patient_slice] = true_mask
    if img_shape ==2:
        img_tensor = torch.tensor(test_img_tensor).to(device,torch.float32)
    else:
        img_tensor = torch.tensor(test_img_tensor_2c).to(device,torch.float32)
    with torch.no_grad():
        outputs = net(img_tensor)
    pred_mask_tensor = outputs.ge(0.5).cpu().data.numpy().astype("uint8")
    image_3d_pred = np.squeeze(pred_mask_tensor,axis=1)
    return image_3d_pred,image_3d_true

def compute_3d_dice(net,device,img_path_full,true_path_full,in_files_full_list,patientID_list,out_dir):
    file_names = in_files_full_list       #列出所有病人的npy文件名
    patient_dice_3d_t = 0.
    patient_PPV_3d_t = 0.
    patient_sen_3d_t = 0.
    for i , id in enumerate(patientID_list):
        img_names = list(filter(lambda x: x.startswith(id), file_names))
        imgnp_3d_pred,imgnp_3d_true = test_volumes(net,device,img_path_full,true_path_full,in_files=img_names)
        patient_dice_3d,patient_PPV_3d,patient_sen_3d = dice(imgnp_3d_pred, imgnp_3d_true)
        patient_dice_3d_t += patient_dice_3d
        patient_PPV_3d_t += patient_PPV_3d
        patient_sen_3d_t += patient_sen_3d
        logging.info("{}   Patient {}'s 3d dice is {:.4f}".format(i+1,id,patient_dice_3d))
        logging.info("{} Patient {}'s 3d PPV is {:.4f}".format(i+1,id,patient_PPV_3d))
        logging.info("{} Patient {}'s 3d sen is {:.4f}".format(i+1,id,patient_sen_3d))
    mean_dice_all_3d = patient_dice_3d_t / (i+1)
    mean_PPV_all_3d = patient_PPV_3d_t / (i+1)
    mean_sen_all_3d = patient_sen_3d_t / (i+1)
    return mean_dice_all_3d, mean_PPV_all_3d, mean_sen_all_3d
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    gpu_list = [1] #[0,1]
    gpu_list_str = ','.join(map(str, gpu_list))
    os.environ.setdefault("CUDA_VISIBLE_DEVICES", gpu_list_str)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logging.info(f'Using device {device}')
    """Test master directory """
    base_dir = '/home/zjj/pertrain/torch_unet_z/REScl1/CT1/R0.1/H0_cl1gan-align-H52_ct_0.1_3730_2586/' 
    #base_dir = "/home/zjj/pertrain/torch_unet_z/RES40_ours_ct_best/H0_dsgan-align2d2u-con0.1-H156_ct_0.1_3441_2738"
    data_path = "/home/zjj/DATA/Hecktor_slice"
    img_mode = 'ct'
    out_path = os.path.join(base_dir, 'outputs') 
    if not os.path.exists(out_path):
        os.mkdir(out_path)
    # '''1、加载网络及权重'''
    # weight_path = os.path.join(base_dir, 'model_UNet.pth') 
    # logging.info("Loading model {}".format(weight_path))
    # net = UNet(in_channels=2, out_channels=1)
    # net.load_state_dict(torch.load(weight_path, map_location=device))
    '''2、直接加载模型'''
    model_path = os.path.join(base_dir, 'model_UNet_best.pth')  #model_UNet_best model_UNet
    logging.info("Loading model {}".format(model_path))
    net = torch.load(model_path, map_location=device)    # map_location：指定存放的位置，CPU/GPU


    net.to(device=device)
    net.eval()
    logging.info("Model loaded !")
    img_path = '{}/imgs_{}'.format(data_path,img_mode)
    true_path = '{}/masks'.format(data_path)
    # """1、仅测试一组数据的dice和进行可视化,不生成三维数据"""
    # test_list_path = data_path+'/randP1_slice_nidus_test.list'
    # in_files_list = read_list(test_list_path)
    # # print(in_files)
    # print("data number:",len(in_files_list))
    # mean_dice = test_images(net,device,
    #                 img_path,true_path,in_files_list,out_path,is_save_img=True,exp='')
    # print("mean dice is {:.4f}".format(mean_dice))

    """2、计算每个病人的3d dice和2d dice(切片取平均)"""
    time_tic_test = time.time()
    full_val_list_path = '{}/randP1_slice_all_val.list'.format(data_path)
    in_files_full_list = read_list(full_val_list_path)
    patientID_val_list_path = '{}/randP1_volume_val.list'.format(data_path)
    patientID_list = read_list(patientID_val_list_path)
    # print(in_files_full_list)
    mean_dice_all_3d, mean_PPV_all_3d, mean_sen_all_3d= compute_3d_dice(net,device,
                            img_path,true_path,in_files_full_list,patientID_list,out_dir=base_dir)
    time_end_test = time.time()
    print("3D Dice test time:{:.2f} min".format((time_end_test-time_tic_test)/60))
    print("Mean 3d dice on all patients:{:.4f} ".format(mean_dice_all_3d))
    print("Mean 3d PPV on all patients:{:.4f} ".format(mean_PPV_all_3d))
    print("Mean 3d sen on all patients:{:.4f} ".format(mean_sen_all_3d))
        
