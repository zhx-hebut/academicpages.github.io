import os
import time
import glob
import argparse
import logging
import numpy as np
import torch
import skimage.io as io
import torch.nn.functional as F
from collections import OrderedDict
from PIL import Image
import matplotlib.pyplot as plt
from utils.metrics import dice as dice_all
from medpy import metric
#from nets.unet_two import UNet
import SimpleITK as sitk
from utils.util import read_list,AverageMeter
plt.switch_backend('agg')
import warnings
warnings.filterwarnings("ignore")
def save_imgs(img_mode,out_path,img_np,true_mask,pred_mask,patientSliceID,dice_val,exp):

    '''保存 true mask'''
    true_mask_3c = np.zeros([160, 160], dtype=np.uint8)
    WT_Label = true_mask[0]
    true_mask_3c[WT_Label == 1] = 50
    TC_Label = true_mask[1]
    true_mask_3c[TC_Label == 1] = 255
    ET_Label = true_mask[2]
    true_mask_3c[ET_Label == 1] = 150

    mask_true_img = Image.fromarray(true_mask_3c)
    mask_true_img.save('{}/{}_true.png'.format(out_path,patientSliceID), cmap="gray")

    '''保存 pred mask'''
    pred_mask_3c = np.zeros([160, 160], dtype=np.uint8)
    WT_Label = pred_mask[0]
    pred_mask_3c[WT_Label == 1] = 50
    TC_Label = pred_mask[1]
    pred_mask_3c[TC_Label == 1] = 255
    ET_Label = pred_mask[2]
    pred_mask_3c[ET_Label == 1] = 150

    pred_mask_img = Image.fromarray(pred_mask_3c)
    pred_mask_img.save('{}/{}_pred-{}_{:.4f}.png'.format(out_path,patientSliceID,img_mode,dice_val), cmap="gray")
    # np.save('{}/{}_pred_{:.4f}.npy'.format(out_path,patientSliceID,dice_val),pred_mask)# (160, 160) dtype('uint8') 值为0 1 2 4
    def save_plt(num,np,title):
        plt.subplot(2,2,num)
        plt.imshow(np, cmap="gray")
        plt.axis('off')
        plt.title(title)

    save_plt(1,img_np,img_mode)
    save_plt(2,img_np,img_mode)
    save_plt(3,true_mask_3c,"true mask")
    save_plt(4,pred_mask_3c,title="pred mask-dice:{:.4f}".format(dice_val))
    # patientSliceID = patientSliceID.replace("_slice_","_")
    plt.savefig('{}/{}{}.png'.format(out_path,patientSliceID,exp))
    plt.show()

def predict_img(net,device,true_mask,init_img,scale_factor=1,out_threshold=0.5):
    """
    测试一张图片
    :return: list
    """
    # step 1/4 : path --> img_chw
    if len(init_img.shape) == 2:
        img_chw = np.expand_dims(init_img, axis=0)
    # img_chw = img_chw / 255
    # step 2/4 : img --> tensor
    img_tensor = torch.tensor(img_chw).to(torch.float32)
    img_tensor.unsqueeze_(0)  #or img = img.unsqueeze(0)
    img_tensor = img_tensor.to(device)
    # step 3/4 : tensor --> features
    time_tic = time.time()
    outputs = net(img_tensor)
    time_toc = time.time()
    time_s = time_toc - time_tic
    # print("time is ",time_s)
    pred_mask = outputs.ge(out_threshold).cpu().data.numpy().astype("uint8")
    pred_mask = pred_mask.squeeze()
    dice_val1, ppv_val1, sen_val1 = dice_all(pred_mask[0], true_mask[0])
    dice_val2, ppv_val2, sen_val2 = dice_all(pred_mask[1], true_mask[1])
    dice_val3, ppv_val3, sen_val3 = dice_all(pred_mask[2], true_mask[2])
    dice_val = (dice_val1 + dice_val2 + dice_val3) / 3
    ppv_val = (ppv_val1 + ppv_val2 + ppv_val3) / 3
    sen_val = (sen_val1 + sen_val2 + sen_val3) / 3
    return pred_mask,dice_val,ppv_val, sen_val, time_s

def test_images(net,device,img_path,true_path,in_files,out_path=None,is_save_img=False,exp=''):
    img_mode = img_path.split('/')[-1].split('_')[-1]
    dice_total = 0.
    mean_dice= 0.
    ppv_total = 0.
    ppv_dice= 0.
    sen_total = 0.
    sen_dice= 0.
    for i, file_name in enumerate(in_files):
        # print("{}.Predicting image {} ...".format(i,file_name))
        path_file = os.path.join(img_path, file_name+'.npy')
        true_file = os.path.join(true_path, file_name+'.npy')
        namesplit = os.path.splitext(file_name)
        patientSliceID = namesplit[0]
        # img = Image.open(fn)  ##when data is image,jpg,png...
        img = np.load(path_file)       ##when data is npy
        mask_np = np.load(true_file)
        
        pred_mask ,dice_val, ppv_val, sen_val ,time_s = predict_img(net,device,mask_np,init_img=img,scale_factor=1,out_threshold=0.5)
        dice_total += dice_val
        ppv_total += ppv_val
        sen_total += sen_val
        logging.info("Patient [{}] dice is [{:.4f}]. Time consuming is {:.4f}".format(patientSliceID,dice_val,time_s))
        logging.info("Patient [{}] ppv is [{:.4f}]. Time consuming is {:.4f}".format(patientSliceID,ppv_val,time_s))
        logging.info("Patient [{}] sen is [{:.4f}]. Time consuming is {:.4f}".format(patientSliceID,sen_val,time_s))

        if is_save_img==True:
            save_imgs(img_mode,out_path,img,mask_np,pred_mask,patientSliceID,dice_val,exp)
    mean_dice = dice_total / (i+1)
    mean_ppv = ppv_total / (i+1)
    mean_sen = sen_total / (i+1)

    return mean_dice, mean_ppv, mean_sen

def test_volumes(net,device,img_path,true_path,in_files,out_path=None):
    img_mode = img_path.split('/')[-1].split('_')[-1]
    slice_len = len(in_files)
    path_file1 = os.path.join(img_path,in_files[0]+'.npy')
    w,h = np.load(path_file1).shape
    test_img_tensor = np.zeros((slice_len,1,w,h),np.float32)

    true_3d_1 = np.zeros((slice_len,w,h),np.uint8)
    true_3d_2 = np.zeros((slice_len,w,h),np.uint8)
    true_3d_3 = np.zeros((slice_len,w,h),np.uint8)
    for i, file_name in enumerate(in_files):
        patient_name = file_name.split('.')[0]
        patient_slice = patient_name.split('_')[-1]
        patient_slice = int(patient_slice) - 1
        path_file = os.path.join(img_path, file_name+'.npy')
        true_file = os.path.join(true_path, file_name+'.npy')
        img = np.load(path_file)       ##when data is npy
        mask_np = np.load(true_file)
        WT_Label = mask_np[0]
        TC_Label = mask_np[1]
        ET_Label = mask_np[2]
        true_3d_1[patient_slice,:,:] = WT_Label
        true_3d_2[patient_slice,:,:] = TC_Label
        true_3d_3[patient_slice,:,:] = ET_Label
        if len(img.shape) == 2:
            img_chw = np.expand_dims(img, axis=0)
        test_img_tensor[patient_slice] = img_chw

    img_tensor = torch.tensor(test_img_tensor).to(device,torch.float32)
    with torch.no_grad():
        outputs = net(img_tensor)
    pred_mask_tensor = outputs.ge(0.5).cpu().data.numpy().astype("uint8")
    pred_3d_1 = pred_mask_tensor[:,0,:,:]
    pred_3d_2 = pred_mask_tensor[:,1,:,:]
    pred_3d_3 = pred_mask_tensor[:,2,:,:]

    pred_all_3d = OrderedDict([
        ('WT', pred_3d_1),
        ('TC', pred_3d_2),
        ('ET', pred_3d_3),
    ])
    true_all_3d = OrderedDict([
        ('WT', true_3d_1),
        ('TC', true_3d_2),
        ('ET', true_3d_3),
    ])
    return  pred_all_3d,true_all_3d

def compute_3d_dice(net,device,img_path_full,true_path_full,in_files_full_list,patientID_list,out_dir):
    file_names = in_files_full_list       #列出所有病人的npy文件名
    dice_3d_log = AverageMeter()
    ppv_3d_log = AverageMeter()
    sen_3d_log = AverageMeter()
    for i , id in enumerate(patientID_list):
        img_names = list(filter(lambda x: x.startswith(id), file_names))
        
        pred_all_3d,true_all_3d = test_volumes(net,device,img_path_full,true_path_full,in_files=img_names)
        pred_3d_WT = pred_all_3d['WT']
        pred_3d_TC = pred_all_3d['TC']
        pred_3d_ET = pred_all_3d['ET']
        true_3d_WT = true_all_3d['WT']
        true_3d_TC = true_all_3d['TC']
        true_3d_ET = true_all_3d['ET']
        
        patient_dice_3d_WT,patient_ppv_3d_WT,patient_sen_3d_WT = dice_all(pred_3d_WT, true_3d_WT)
        patient_dice_3d_TC,patient_ppv_3d_TC,patient_sen_3d_TC = dice_all(pred_3d_TC, true_3d_TC)
        patient_dice_3d_ET, patient_ppv_3d_ET, patient_sen_3d_ET = dice_all(pred_3d_ET, true_3d_ET)
        patient_dice_3d_all = (patient_dice_3d_WT + patient_dice_3d_TC + patient_dice_3d_ET) / 3
        patient_ppv_3d_all = (patient_ppv_3d_WT + patient_ppv_3d_TC + patient_ppv_3d_ET) / 3
        patient_sen_3d_all = (patient_sen_3d_WT + patient_sen_3d_TC + patient_sen_3d_ET) / 3

        
        dice_3d_log.add_value({"wt":patient_dice_3d_WT}, n=1) 
        dice_3d_log.add_value({"tc":patient_dice_3d_TC}, n=1) 
        dice_3d_log.add_value({"et":patient_dice_3d_ET}, n=1)

        ppv_3d_log.add_value({"wt":patient_ppv_3d_WT}, n=1) 
        ppv_3d_log.add_value({"tc":patient_ppv_3d_TC}, n=1) 
        ppv_3d_log.add_value({"et":patient_ppv_3d_ET}, n=1) 

        sen_3d_log.add_value({"wt":patient_sen_3d_WT}, n=1) 
        sen_3d_log.add_value({"tc":patient_sen_3d_TC}, n=1) 
        sen_3d_log.add_value({"et":patient_sen_3d_ET}, n=1)  
        # logging.info("{} Patient {}'s 3d dice WT class is {:.4f}".format(i+1,id,patient_dice_3d_WT))
        # logging.info("{} Patient {}'s 3d dice TC class is {:.4f}".format(i+1,id,patient_dice_3d_TC))
        # logging.info("{} Patient {}'s 3d dice ET class is {:.4f}".format(i+1,id,patient_dice_3d_ET))
        logging.info("{} Patient {}'s mean 3d dice all class  is {:.4f}".format(i+1,id,patient_dice_3d_all))

    dice_3d_log.updata_avg()
    dice_3d_mean_res = dice_3d_log.res_dict
    ppv_3d_log.updata_avg()
    ppv_3d_mean_res = ppv_3d_log.res_dict
    sen_3d_log.updata_avg()
    sen_3d_mean_res = sen_3d_log.res_dict
    return dice_3d_mean_res['wt'][0],dice_3d_mean_res['tc'][0],dice_3d_mean_res['et'][0],ppv_3d_mean_res['wt'][0],ppv_3d_mean_res['tc'][0],ppv_3d_mean_res['et'][0],sen_3d_mean_res['wt'][0],sen_3d_mean_res['tc'][0],sen_3d_mean_res['et'][0]
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    gpu_list = [0] #[0,1]
    gpu_list_str = ','.join(map(str, gpu_list))
    os.environ.setdefault("CUDA_VISIBLE_DEVICES", gpu_list_str)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logging.info(f'Using device {device}')


    """Test one model """
    base_dir = 'A_RES_BraTS_BEST/RES_FUL-SUP/res-semi-DTC-T1CE/' #res_Unet
    data_path = "data/BraTS_slice"
    img_mode = 't1ce'
    out_path = os.path.join(base_dir, 'outputs') 
    if not os.path.exists(out_path):
        os.mkdir(out_path)

    model_path = os.path.join(base_dir, 'model_UNet_last.pth')  #model_UNet_best model_UNet
    logging.info("Loading model {}".format(model_path))
    net = torch.load(model_path, map_location=device)    # map_location：指定存放的位置，CPU/GPU
    net.to(device=device)
    net.eval()
    logging.info("Model loaded !")

    img_path = '{}/imgs_{}'.format(data_path,img_mode)
    true_path = '{}/masks_all'.format(data_path)
    """1、仅测试一组数据的dice和进行可视化,不生成三维数据"""
    test_list_path = data_path+'/randP1_slice_nidus_test.list'
    in_files_list = read_list(test_list_path)
    # print(in_files)
    print("data number:",len(in_files_list))
    mean_dice = test_images(net,device,
                    img_path,true_path,in_files_list,out_path,is_save_img=True,exp='')
    print("mean dice is {:.4f}".format(mean_dice))

    """2、计算每个病人的3d dice和2d dice(切片取平均)"""
    time_tic_test = time.time()
    full_val_list_path = '{}/randP1_slice_all_val.list'.format(data_path)
    in_files_full_list = read_list(full_val_list_path)
    patientID_val_list_path = '{}/randP1_volume_val.list'.format(data_path)
    patientID_list = read_list(patientID_val_list_path)

    mean_dice_3d_WT,mean_dice_3d_TC,mean_dice_3d_ET,mean_ppv_3d_WT,mean_ppv_3d_TC,mean_ppv_3d_ET,mean_sen_3d_WT,mean_sen_3d_TC,mean_sen_3d_ET = compute_3d_dice(net,device,img_path,
                            true_path,in_files_full_list,patientID_list,out_dir=base_dir)

    print("Mean 3d dice WT on all patients:{:.4f} ".format(mean_dice_3d_WT))
    print("Mean 3d dice TC on all patients:{:.4f} ".format(mean_dice_3d_TC))
    print("Mean 3d dice ET on all patients:{:.4f} ".format(mean_dice_3d_ET))
    mean_dice_3d = (mean_dice_3d_WT + mean_dice_3d_TC + mean_dice_3d_ET) / 3
    print("Mean 3d dice on all patients:{:.4f} ".format(mean_dice_3d))


    print("Mean 3d ppv WT on all patients:{:.4f} ".format(mean_ppv_3d_WT))
    print("Mean 3d dice TC on all patients:{:.4f} ".format(mean_ppv_3d_TC))
    print("Mean 3d dice ET on all patients:{:.4f} ".format(mean_ppv_3d_ET))
    mean_ppv_3d = (mean_ppv_3d_WT + mean_ppv_3d_TC + mean_ppv_3d_ET) / 3
    print("Mean 3d dice on all patients:{:.4f} ".format(mean_ppv_3d))

    print("Mean 3d dice WT on all patients:{:.4f} ".format(mean_sen_3d_WT))
    print("Mean 3d dice TC on all patients:{:.4f} ".format(mean_sen_3d_TC))
    print("Mean 3d dice ET on all patients:{:.4f} ".format(mean_sen_3d_ET))
    mean_sen_3d = (mean_sen_3d_WT + mean_sen_3d_TC + mean_sen_3d_ET) / 3
    print("Mean 3d dice on all patients:{:.4f} ".format(mean_sen_3d))

    # """Test two model """
    # base_dir = 'A_RES_BraTS-3C_Ablation-10%/res-t2_t1ce-semiNCE-3C-1.18-noAll' #res_Unet
    # data_path = "data/BraTS_slice"
    # img_mode = 't2_t1ce'
    # img_mode1 = img_mode.split('_')[0]
    # img_mode2 = img_mode.split('_')[1]
    # out_path = os.path.join(base_dir, 'outputs') 
    # if not os.path.exists(out_path):
    #     os.mkdir(out_path)
    # # '''1、加载网络及权重'''
    # # weight_path = os.path.join(base_dir, 'model_UNet.pth') 
    # # logging.info("Loading model {}".format(weight_path))
    # # net = UNet(in_channels=2, out_channels=1)
    # # net.load_state_dict(torch.load(weight_path, map_location=device))
    # '''2、直接加载模型'''
    # # model_path = os.path.join(base_dir, 'model_UNet_last.pth')  #model_UNet_best model_UNet
    # net_name = 'UNet'
    # model_path_last_mode1 = os.path.join(base_dir,'model_{}_last_mode1.pth'.format(net_name))
    # model_path_last_mode2 = os.path.join(base_dir,'model_{}_last_mode2.pth'.format(net_name))
    # # logging.info("Loading model {}".format(model_path_last_mode1))
    # net_mode1 = torch.load(model_path_last_mode1, map_location=device)
    # net_mode1.to(device=device)
    # net_mode1.eval()
    # net_mode2 = torch.load(model_path_last_mode2, map_location=device)
    # net_mode2.to(device=device)
    # net_mode2.eval()
    # logging.info("Model loaded !")

    # img_path_mode1 = '{}/imgs_{}'.format(data_path,img_mode1)
    # img_path_mode2 = '{}/imgs_{}'.format(data_path,img_mode2)
    # true_path = '{}/masks_all'.format(data_path)
    # """1、仅测试一组数据的dice和进行可视化,不生成三维数据"""
    # test_list_path = data_path+'/randP1_slice_nidus_test.list'
    # in_files_list = read_list(test_list_path)
    # logging.info("test data number: {}".format(len(in_files_list)))
    # mean_dice1 = test_images(net_mode1,device,
    #                 img_path_mode1,true_path,in_files_list,out_path,is_save_img=True,exp=img_mode1)
    # mean_dice2 = test_images(net_mode2,device,
    #                 img_path_mode2,true_path,in_files_list,out_path,is_save_img=True,exp=img_mode2)
    # logging.info("mean dice is out1 {:.4f},out2 {:.4f}".format(mean_dice1,mean_dice2))

    # logging.info("==========2、Evaluate 3d dice and 2d dice======")
    # full_val_list_path = '{}/randP1_slice_all_val.list'.format(data_path)
    # in_files_full_list = read_list(full_val_list_path)
    # patientID_val_list_path = '{}/randP1_volume_val.list'.format(data_path)
    # patientID_list = read_list(patientID_val_list_path)

    # mean_dice_3d_WT1,mean_dice_3d_TC1,mean_dice_3d_ET1 = compute_3d_dice(net_mode1,device,img_path_mode1,
    #                         true_path,in_files_full_list,patientID_list,out_dir=base_dir)
    # logging.info("{} Mean 3d dice WT on all patients:{:.4f} ".format(img_mode1,mean_dice_3d_WT1))
    # logging.info("{} Mean 3d dice TC on all patients:{:.4f} ".format(img_mode1,mean_dice_3d_TC1))
    # logging.info("{} Mean 3d dice ET on all patients:{:.4f} ".format(img_mode1,mean_dice_3d_ET1))
    # mean_dice_3d1 = (mean_dice_3d_WT1 + mean_dice_3d_TC1 + mean_dice_3d_ET1) / 3

    # mean_dice_3d_WT2,mean_dice_3d_TC2,mean_dice_3d_ET2 = compute_3d_dice(net_mode2,device,img_path_mode2,
    #                         true_path,in_files_full_list,patientID_list,out_dir=base_dir)
    # logging.info("{} Mean 3d dice WT on all patients:{:.4f} ".format(img_mode2,mean_dice_3d_WT2))
    # logging.info("{} Mean 3d dice TC on all patients:{:.4f} ".format(img_mode2,mean_dice_3d_TC2))
    # logging.info("{} Mean 3d dice ET on all patients:{:.4f} ".format(img_mode2,mean_dice_3d_ET2))
    # mean_dice_3d2 = (mean_dice_3d_WT2 + mean_dice_3d_TC2 + mean_dice_3d_ET2) / 3

    # logging.info("Mean 3d dice on all patients {}: {:.4f},{}: {:.4f} ".format(img_mode1,mean_dice_3d1,img_mode2,mean_dice_3d2))
    # lr_path = glob.glob(base_dir + '/lr*.jpg')
    # new_lr_path = os.path.join(base_dir,'lr-3d_dice_{}-{:.2f}_{}-{:.2f}.jpg'.format(img_mode1,mean_dice_3d1,img_mode2,mean_dice_3d2))
    # os.rename(lr_path[0],new_lr_path)