import os
import cv2
import torch
import random
import logging
import numpy as np
from glob import glob
from torch.utils.data import Dataset
from torch.utils.data.sampler import Sampler

class BaseDataSets(Dataset):
    def __init__(self, data_dir=None, mode='train', img_mode='ct', list_name='slice_nidus_all.list',images_rate=1, transform=None):
        self._data_dir = data_dir
        self.sample_list = []
        self.mode = mode
        self.img_mode = img_mode
        self.list_name = list_name
        self.transform = transform

        list_path = os.path.join(self._data_dir,self.list_name)

        with open(list_path, "r") as f:
            for line in f.readlines():
                line = line.strip('\n')  #去掉列表中每一个元素的换行符
        #         print(line)
                self.sample_list.append(line)      
        # print(self.mode,self.sample_list)              
        logging.info(f'Creating total {self.mode} dataset with {len(self.sample_list)} examples')                

        if images_rate !=1 and self.mode == "train":
            images_num = int(len(self.sample_list) * images_rate)
            self.sample_list = self.sample_list[:images_num]
        logging.info(f"Creating factual {self.mode} dataset with {len(self.sample_list)} examples")
        # print(self.sample_list)
        

    def __len__(self):
        return len(self.sample_list)
    def __sampleList__(self):
        return self.sample_list

    def __getitem__(self, idx):
        if self.mode=='val_3d':
            case = idx
            #print("zjj 3d:",idx)
        else:
            case = self.sample_list[idx]
            #print("zjj 2d:",idx,"case: ",case)
        # print("idx: {},case: {}".format(idx,case))

        img_np_path = os.path.join(self._data_dir,'imgs_{}/{}.npy'.format(self.img_mode,case))
        mask_np_path = os.path.join(self._data_dir,'masks/{}.npy'.format(case))

        img_np = np.load(img_np_path)
        mask_np = np.load(mask_np_path)
        # assert img_np.shape == mask_np.shape, \
        #     f'Image and mask {idx} should be the same size, but are {img_np.shape} and {mask_np.shape}'
        if len(img_np.shape) == 3:
            #print("zjj before",img_np.shape) # (144,144,2)
            img_np.transpose((2,0,1))
            #print("zjj",img_np.shape) # (144,144,2)

        if len(img_np.shape) == 2:
            img_np = np.expand_dims(img_np, axis=0)#0
        if len(mask_np.shape) == 2:
            mask_np = np.expand_dims(mask_np, axis=0)#0
        sample = {'image': img_np.copy(), 'mask': mask_np.copy(),'idx':case}
        return sample
class PatientBatchSampler(Sampler):
    def __init__(self, slices_list,patientID_list):
        self.slices_list = slices_list
        self.patientID_list = patientID_list
        assert len(self.slices_list) >= len(self.patientID_list) > 0

    def __iter__(self):
        return (
            list(filter(lambda x: x.startswith(id), self.slices_list))
            for i,id
            in enumerate(self.patientID_list)
        )

    def __len__(self):
        return len(self.patientID_list)
        
class RandomGenerator(object):
    def __init__(self, output_size):
        self.output_size = output_size

    def __call__(self, sample):
        image, label = sample['image'], sample['mask']
        # # ind = random.randrange(0, img.shape[0])
        # # image = img[ind, ...]
        # # label = lab[ind, ...]
        # if random.random() > 0.5:
        #     image, label = random_rot_flip(image, label)
        # elif random.random() > 0.5:
        #     image, label = random_rotate(image, label)
        # x, y = image.shape
        # image = zoom(
        #     image, (self.output_size[0] / x, self.output_size[1] / y), order=0)
        # label = zoom(
        #     label, (self.output_size[0] / x, self.output_size[1] / y), order=0)

        image = torch.from_numpy(
            image.astype(np.float32)).unsqueeze(0)
        label = torch.from_numpy(
            label.astype(np.uint8))
        sample = {'image': image, 'mask': label}
        return sample
