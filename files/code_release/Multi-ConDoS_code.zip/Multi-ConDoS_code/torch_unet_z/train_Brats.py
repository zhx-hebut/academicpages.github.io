import os
import sys
import math
import time
import glob
import torch
import shutil
import random
import logging
import argparse
import numpy as np
from tqdm import tqdm
import torch.nn as nn
from torch import optim
import matplotlib.pyplot as plt
from torchsummary import summary
import torch.backends.cudnn as cudnn
from tensorboardX import SummaryWriter
import torchvision.transforms as transforms
#from torch.cuda.amp import autocast,GradScaler
from torch.utils.data import DataLoader, random_split

from nets.unet import UNet_m1, UNet_m2
#from nets.unet import UNet
from utils.metrics import dice as dice_all
from utils.metrics import batch_dice,compute_dice
from utils.losses import FocalLoss,BinaryDiceLoss
from utils.util import set_logging,Logger,plot_dice_loss,read_list,AverageMeter
from dataloader.dataset import BaseDataSets,PatientBatchSampler
from predict_brats_3c import test_images,compute_3d_dice
import platform
if platform.system() == "Windows":
  import dill as pickle
else:
  import pickle
# plt.switch_backend('agg')  #ssh跑程序时报"RuntimeError: Invalid DISPLAY variable。"加入此句
gpu_list = [6] #[0,1]
Fine_tune = True
Strategy = "1d1u"
set_args = True
base_dir = 'RES_FT/'
train_target = "None (21/1/1 15:47)"
data_path = '/home/zjj/DATA/BraTS2018_slice' # Hecktor_slice BraTS_slice
img_mode = 'ct'
val_3d_interval = 1
def train_net(data_path,base_dir,device,train_list,val_list,time_now,save_weight=False,img_mode='',lr_scheduler='warmupCosine',
            max_epoch=70,
            batch_size=90,
            base_lr=0.0002,
            images_rate=0.1,
            optim_name='adamw',
            loss_name='focal',
            weight_decay=1e-4,
            checkpoint_dir='CT2PET_6GPU_144',
            Load_pth = 'latest',
            split_rate=1):
    warm_up_epochs = int(max_epoch * 0.1)
    image_channels = 1 # image_channels=3 for RGB images
    class_num = 3       # For 1 class and background, use class_num=1
    if 'Hecktor' in data_path:
        img_h,img_w = 144,144
    elif 'BraTS' in data_path:
        img_h,img_w = 160,160
    """定义网络"""
    fine_tune_base_dir = '/mnt/sdc/zjj/Multi-ConDoS/checkpoints/' + checkpoint_dir
    model_path_g = fine_tune_base_dir + "/" + Load_pth + "_net_G.pth"    
    if Strategy == "1d1u" :
        if img_mode == "t1ce":
            from nets.unet import UNet_m1_1d1u
            net = UNet_m1_1d1u(in_channels=image_channels, out_channels=class_num, init_feature_num=32,bilinear=False)
        if img_mode == "t2":
            from nets.unet import UNet_m2_1d1u
            net = UNet_m2_1d1u(in_channels=image_channels, out_channels=class_num, init_feature_num=32,bilinear=False)

    if Strategy == "2d2u" :
        if img_mode == "t1ce":
            from nets.unet import UNet_m1
            net = UNet_m1(in_channels=image_channels, out_channels=class_num, init_feature_num=32,bilinear=False)
        if img_mode == "t2":
            from nets.unet import UNet_m2
            net = UNet_m2(in_channels=image_channels, out_channels=class_num, init_feature_num=32,bilinear=False)

    if Strategy == "3d3u" :
        if img_mode == "t1ce":
            from nets.unet import UNet_m1_3d3u
            net = UNet_m1_3d3u(in_channels=image_channels, out_channels=class_num, init_feature_num=32,bilinear=False)
        if img_mode == "t2":
            from nets.unet import UNet_m2_3d3u
            net = UNet_m2_3d3u(in_channels=image_channels, out_channels=class_num, init_feature_num=32,bilinear=False)
    
    if Fine_tune:
        print('loading the model from %s' % model_path_g)
        state_dict = torch.load(model_path_g, map_location=device)
        if hasattr(state_dict, '_metadata'):
            del state_dict._metadata
        # for k,v in state_dict.items():
        #    print("load：",k) #只打印key值，不打印具体参数。
        net.load_state_dict(state_dict,strict=False)
        logging.info("Loading model {}".format(model_path_g))

    # print(summary(net, (image_channels,img_h,img_w), device="cpu"))
    net = nn.DataParallel(net)
    net.to(device=device)
    net_name = str(net.module)[0:str(net.module).find('(')]

    train_dataset = BaseDataSets(data_dir=data_path, mode="train",img_mode=img_mode,list_name=train_list,images_rate=images_rate)
    val_dataset = BaseDataSets(data_dir=data_path, mode="val",img_mode=img_mode,list_name=val_list)
    val_dataset_3d = BaseDataSets(data_dir=data_path, mode="val_3d",img_mode=img_mode,list_name=val_list_full)

    if split_rate != 1:
        logging.warning(f"training on small images , rate is {split_rate}")
        num_train = int(len(train_dataset) * split_rate)
        num_val = len(train_dataset) - num_train
        train_dataset, val_dataset = random_split(train_dataset, [num_train, num_val])

    n_train = train_dataset.__len__()
    n_val = val_dataset.__len__()
    def worker_init_fn(worker_id):
        random.seed(1111 + worker_id)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=8, pin_memory=True, drop_last=True,worker_init_fn=worker_init_fn) #worker_init_fn=worker_init_fn
    val_loader_2d = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=8, pin_memory=True, drop_last=False,worker_init_fn=worker_init_fn)
    slices_list = val_dataset_3d.__sampleList__()
    batch_sampler = PatientBatchSampler(slices_list,patientID_list)
    val_loader_3d = DataLoader(val_dataset_3d,batch_sampler=batch_sampler, num_workers=8, pin_memory=True,worker_init_fn=worker_init_fn)
    day_time = time_now.split(' ')
    time_str = str(day_time[0].split('-')[1] + day_time[0].split('-')[2] + day_time[1].split(':')[0] + day_time[1].split(':')[1])
    log_dir = os.path.join(base_dir, 'logs_'+time_str)
    if optim_name=='adam':
        optimizer = optim.Adam(net.parameters(), lr=base_lr, weight_decay=weight_decay)
    elif optim_name=='lgd':
        optimizer = optim.SGD(net.parameters(), lr=base_lr, momentum=0.9,weight_decay=weight_decay)
    elif optim_name=='adamw':
        optimizer = optim.AdamW(net.parameters(), lr=base_lr, weight_decay=weight_decay)

    if lr_scheduler=='warmupMultistep':
        lr1,lr2,lr3 = int(max_epoch*0.25) , int(max_epoch*0.4) , int(max_epoch*0.6)
        lr_milestones = [lr1,lr2,lr3]
        warm_up_with_multistep_lr = lambda epoch: (epoch+1) / warm_up_epochs if epoch < warm_up_epochs \
                                                else 0.1**len([m for m in lr_milestones if m <= epoch])
        scheduler_lr = optim.lr_scheduler.LambdaLR(optimizer,lr_lambda = warm_up_with_multistep_lr)
    elif lr_scheduler=='warmupCosine':
        warm_up_with_cosine_lr = lambda epoch: (epoch+1) / warm_up_epochs if epoch < warm_up_epochs \
                                else 0.5 * ( math.cos((epoch - warm_up_epochs) /(max_epoch - warm_up_epochs) * math.pi) + 1)
        scheduler_lr = optim.lr_scheduler.LambdaLR(optimizer,lr_lambda = warm_up_with_cosine_lr)
    elif lr_scheduler=='autoReduce':
        scheduler_lr = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min',factor=0.5, patience=6, verbose=True, cooldown=2,min_lr=0)
    if loss_name=='bce':
        criterion = nn.BCELoss()
    elif loss_name=='focal':
        criterion = FocalLoss(alpha=0.75, gamma=2,logits=True,reduce=False) 

    dice_loss = BinaryDiceLoss()
    optimizer_name = str(optimizer)[0:str(optimizer).find('(')]

    logging.info(f'''Starting training:\n\tStart time:      {time_now}\n\tBase dir:        {base_dir}\n\tTrain target:    {train_target}\n\tData Path:       {data_path.split('/')[-1]}\n\tImages Mode:     {img_mode}\n\tTrain List:      {train_list}\n\tVal   List:      {val_list}
    Train Imgs Rate：{images_rate}\n\tTraining Num:    {n_train}\n\tValidation Num:  {n_val}\n\tMax Epochs:      {max_epoch}\n\tBatch Size:      {batch_size}\n\tLearning Rate:   {base_lr}\n\tWeight Decay:    {weight_decay}
    Net Name:        {net_name}\n\tOptimizer:       {optimizer_name}\n\tLoss:            {criterion}\n\tLR Scheduler:    {lr_scheduler}\n\tInput Channels:  {image_channels}\n\tClasses Num:     {class_num}\n\tImages Shape:    {img_h}*{img_w}\n\tFine tune:    {Fine_tune}\n\tLoad pth:    {Load_pth}
    \n\tcheckpoint_dir:    {checkpoint_dir}
    ''')
    loss_train_curve = list()
    loss_valid_curve = list()
    dice_train_curve = list()
    dice_valid_curve_2d = list()
    dice_valid_curve_3d = list()
    dice_valid_curve_3d_WT = list()
    dice_valid_curve_3d_TC = list()
    dice_valid_curve_3d_ET = list()

    ###############################################################
    PPV_valid_curve_3d = list()
    PPV_valid_curve_3d_WT = list()
    PPV_valid_curve_3d_TC = list()
    PPV_valid_curve_3d_ET = list()
    Sense_valid_curve_3d = list()
    Sense_valid_curve_3d_WT = list()
    Sense_valid_curve_3d_TC = list()
    Sense_valid_curve_3d_ET = list()
    ###############################################################

    lr_curve = list()
    best_performance = 0.0
    best_performance_WT = 0.0
    best_performance_TC = 0.0
    best_performance_ET = 0.0
    best=0.0
    best_epoch=0

    ###############################################################
    PPV_best_performance = 0.0
    PPV_best_performance_WT = 0.0
    PPV_best_performance_TC = 0.0
    PPV_best_performance_ET = 0.0
    Sense_best_performance = 0.0
    Sense_best_performance_WT = 0.0
    Sense_best_performance_TC = 0.0
    Sense_best_performance_ET = 0.0
    ###############################################################
    for epoch in range(max_epoch):
        # train the model
        net.train()
        train_loss = AverageMeter()
        train_dice = AverageMeter()
        n = 0
        with tqdm(total=n_train, desc=f'Epoch {epoch + 1}/{max_epoch}', unit='img') as pbar:
            for i,batch in enumerate(train_loader):
                n += 1
                # print(n)
                # forward
                imgs = batch['image']
                true_masks = batch['mask']
                # print("batch idxs:",batch['idx'])
                assert imgs.shape[1] == image_channels, \
                    f'Network has been defined with {image_channels} input channels, ' \
                    f'but loaded images have {imgs.shape[1]} channels. Please check that ' \
                    'the images are loaded correctly.'

                imgs = imgs.to(device=device, dtype=torch.float32)
                true_masks = true_masks.to(device=device, dtype=torch.float32)
                masks_pred = net(imgs)
                loss_base = criterion(masks_pred, true_masks)
                loss_dice = dice_loss(masks_pred, true_masks)
                loss = loss_base + loss_dice * 10
                train_loss.update(loss.item(),1)
                pred = (masks_pred > 0.5).float()
                dice_sum,num = batch_dice(pred.cpu().data, true_masks.cpu())
                dice = dice_sum / num
                train_dice.update(dice,1)

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                pbar.set_postfix(**{'loss_base(b)': loss_base.item(),'loss_dice(b)': loss_dice.item()})
                pbar.update(batch_size)

            mean_loss = train_loss.avg
            mean_dice = train_dice.avg
            loss_train_curve.append(mean_loss)
            dice_train_curve.append(mean_dice)

        net.eval()
        n_val_2d = len(val_loader_2d)
        n_val_3d = len(val_loader_3d)
        val_loss = AverageMeter()
        val_dice = AverageMeter()
        val_dice_3d = AverageMeter()
        val_dice_3d_WT = AverageMeter()
        val_dice_3d_TC = AverageMeter()
        val_dice_3d_ET = AverageMeter()
        ######################################################################################
        val_PPV_3d = AverageMeter()
        val_PPV_3d_WT = AverageMeter()
        val_PPV_3d_TC = AverageMeter()
        val_PPV_3d_ET = AverageMeter()
        val_Sense_3d = AverageMeter()
        val_Sense_3d_WT = AverageMeter()
        val_Sense_3d_TC = AverageMeter()
        val_Sense_3d_ET = AverageMeter()
        ######################################################################################
        if epoch % val_3d_interval==0:
            compute_3d = True
            n_val = n_val_3d
            val_loader = val_loader_3d
        else:
            compute_3d = False
            n_val = n_val_2d
            val_loader = val_loader_2d

        with tqdm(total=n_val, desc='Validation round', unit='batch', leave=False) as pbar:
            for j,batch_val in enumerate(val_loader):
                imgs, true_masks = batch_val['image'], batch_val['mask']
                imgs = imgs.to(device=device, dtype=torch.float32)
                true_masks = true_masks.to(device=device, dtype=torch.float32)

                if compute_3d==True:
                    batch_num = imgs.shape[0]
                    batch_fore = int(batch_num / 2)
                    imgs_fore = imgs[:batch_fore]
                    imgs_after = imgs[batch_fore:]
                    with torch.no_grad():
                        mask_pred_fore = net(imgs_fore)
                        mask_pred_after = net(imgs_after)
                    mask_pred = torch.cat([mask_pred_fore, mask_pred_after], dim=0)
                    pred = mask_pred.ge(0.5).float()
                    pred_np = pred.cpu().data.numpy().astype("uint8")
                    true_np = true_masks.cpu().numpy().astype("uint8")
                    dice_val_3d_1,PPV_val_3d_1,Sense_val_3d_1 = dice_all(pred_np[:,0,:,:], true_np[:,0,:,:])
                    dice_val_3d_2,PPV_val_3d_2,Sense_val_3d_2 = dice_all(pred_np[:,1,:,:], true_np[:,1,:,:])
                    dice_val_3d_3,PPV_val_3d_3,Sense_val_3d_3 = dice_all(pred_np[:,2,:,:], true_np[:,2,:,:])
                    dice_val_3d = (dice_val_3d_1 + dice_val_3d_2 + dice_val_3d_3) / 3
                    #####################################################################

                    PPV_val_3d = (PPV_val_3d_1 + PPV_val_3d_2 + PPV_val_3d_3) / 3
                    Sense_val_3d = (Sense_val_3d_1 + Sense_val_3d_2 + Sense_val_3d_3) / 3
                    #####################################################################

                    val_dice_3d.update(dice_val_3d,1)
                    val_dice_3d_WT.update(dice_val_3d_1,1)
                    val_dice_3d_TC.update(dice_val_3d_2,1)
                    val_dice_3d_ET.update(dice_val_3d_3,1)

                    #####################################################################
                    val_PPV_3d.update(PPV_val_3d, 1)
                    val_PPV_3d_WT.update(PPV_val_3d_1, 1)
                    val_PPV_3d_TC.update(PPV_val_3d_2, 1)
                    val_PPV_3d_ET.update(PPV_val_3d_3, 1)
                    val_Sense_3d.update(Sense_val_3d, 1)
                    val_Sense_3d_WT.update(Sense_val_3d_1, 1)
                    val_Sense_3d_TC.update(Sense_val_3d_2, 1)
                    val_Sense_3d_ET.update(Sense_val_3d_3, 1)
                    #####################################################################
                    dice_val_sum,nidus_num,nidus_start = compute_dice(pred.cpu().data, true_masks.cpu(),deNoNidus=True)
                    nidus_end = nidus_start+nidus_num-1
                    mask_pred = mask_pred[nidus_start:nidus_end+1]
                    true_masks = true_masks[nidus_start:nidus_end+1]
                else:
                    with torch.no_grad():
                        mask_pred = net(imgs)
                    pred = mask_pred.ge(0.5).float()
                    dice_val_sum,nidus_num = batch_dice(pred.cpu().data, true_masks.cpu())
                val_dice.update(dice_val_sum,nidus_num)
                loss_val_base = criterion(mask_pred, true_masks)
                loss_val_dice = dice_loss(mask_pred, true_masks)
                loss_val = loss_val_base + loss_val_dice * 10
                val_loss.update(loss_val.item(),1)
                pbar.update()
            valid_loss_mean = val_loss.avg
            valid_dice_mean_2d = val_dice.avg
            loss_valid_curve.append(valid_loss_mean)
            dice_valid_curve_2d.append(valid_dice_mean_2d)
            if epoch % val_3d_interval==0:
                valid_dice_mean_3d = val_dice_3d.avg
                valid_dice_mean_3d_WT = val_dice_3d_WT.avg
                valid_dice_mean_3d_TC = val_dice_3d_TC.avg
                valid_dice_mean_3d_ET = val_dice_3d_ET.avg
                dice_valid_curve_3d_WT.append(valid_dice_mean_3d_WT)
                dice_valid_curve_3d_TC.append(valid_dice_mean_3d_TC)
                dice_valid_curve_3d_ET.append(valid_dice_mean_3d_ET)

                ##############################################################
                valid_PPV_mean_3d = val_PPV_3d.avg
                valid_PPV_mean_3d_WT = val_PPV_3d_WT.avg
                valid_PPV_mean_3d_TC = val_PPV_3d_TC.avg
                valid_PPV_mean_3d_ET = val_PPV_3d_ET.avg
                PPV_valid_curve_3d_WT.append(valid_PPV_mean_3d_WT)
                PPV_valid_curve_3d_TC.append(valid_PPV_mean_3d_TC)
                PPV_valid_curve_3d_ET.append(valid_PPV_mean_3d_ET)
                valid_Sense_mean_3d = val_Sense_3d.avg
                valid_Sense_mean_3d_WT = val_Sense_3d_WT.avg
                valid_Sense_mean_3d_TC = val_Sense_3d_TC.avg
                valid_Sense_mean_3d_ET = val_Sense_3d_ET.avg
                Sense_valid_curve_3d_WT.append(valid_Sense_mean_3d_WT)
                Sense_valid_curve_3d_TC.append(valid_Sense_mean_3d_TC)
                Sense_valid_curve_3d_ET.append(valid_Sense_mean_3d_ET)
                ##############################################################


                
                best_performance = valid_dice_mean_3d
                model_path_best = os.path.join(base_dir,'model_{}_best.pth'.format(net_name))
                torch.save(net.module,model_path_best)

                best_performance_WT = valid_dice_mean_3d_WT
                best_performance_TC = valid_dice_mean_3d_TC
                best_performance_ET = valid_dice_mean_3d_ET

                temp=(best_performance_WT+best_performance_TC+best_performance_ET)/3
                if best<temp:
                    best=temp
                    best_epoch=epoch
                    model_path_best = os.path.join(base_dir,'model_{}_best.pth'.format(net_name))
                    torch.save(net.module,model_path_best)

                Sense_best_performance = valid_Sense_mean_3d
                Sense_best_performance_WT = valid_Sense_mean_3d_WT
                Sense_best_performance_TC = valid_Sense_mean_3d_TC
                Sense_best_performance_ET = valid_Sense_mean_3d_ET

                
                PPV_best_performance = valid_PPV_mean_3d
                PPV_best_performance_WT = valid_PPV_mean_3d_WT
                PPV_best_performance_TC = valid_PPV_mean_3d_TC
                PPV_best_performance_ET = valid_PPV_mean_3d_ET

        if lr_scheduler=='autoReduce':
            scheduler_lr.step(valid_loss_mean)
        else:
            scheduler_lr.step()
        lr_epoch = optimizer.param_groups[0]['lr']
        lr_curve.append(lr_epoch)
        logging.info(
            'Epoch:[{:0>3}/{:0>3}], Train Loss: {:.4f} , Val Loss: {:.4f} ,Train Dice: {:.4f} ,  Val Dice: {:.4f},LR: {:.4f},best_performance_WT: {:.4f},best_performance_TC: {:.4f}, best_performance_ET: {:.4f},PPV_best_performance_WT: {:.4f},PPV_best_performance_TC: {:.4f}, PPV_best_performance_ET: {:.4f}, Sense_best_performance_WT: {:.4f},Sense_best_performance_TC: {:.4f}, Sense_best_performance_ET: {:.4f}'.format(
                    epoch,max_epoch,         mean_loss, valid_loss_mean,        mean_dice,       valid_dice_mean_2d, lr_epoch,  best_performance_WT,  best_performance_TC,   best_performance_ET, PPV_best_performance_WT,  PPV_best_performance_TC,   PPV_best_performance_ET,   Sense_best_performance_WT,      Sense_best_performance_TC,       Sense_best_performance_ET))

    weights_epoch = os.path.join(base_dir, 'weights_epoch/')
    if save_weight:
        try:
            os.makedirs(weights_epoch)
            logging.info('Created checkpoint directory')
        except OSError:
            pass
        torch.save(net.module.state_dict(),
                weights_epoch + f'CP_epoch{epoch + 1}.pth')
        logging.info(f'Checkpoint {epoch + 1} saved !')

    model_path_name = base_dir + '/' + f'model_{net_name}_last.pth'
    torch.save(net.module,model_path_name)
    logging.info('Model saved !')
    logging.info(f'best_epoch: {best_epoch}')
    return loss_train_curve,loss_valid_curve,dice_train_curve,dice_valid_curve_2d,dice_valid_curve_3d,\
           dice_valid_curve_3d_WT,dice_valid_curve_3d_TC,dice_valid_curve_3d_ET,\
           PPV_valid_curve_3d_WT,PPV_valid_curve_3d_TC,PPV_valid_curve_3d_ET,\
           Sense_valid_curve_3d_WT,Sense_valid_curve_3d_TC,Sense_valid_curve_3d_ET,lr_curve,net_name, \
           best_performance_WT, best_performance_TC, best_performance_ET,best_performance,\
           PPV_best_performance_WT, PPV_best_performance_TC, PPV_best_performance_ET,PPV_best_performance,\
           Sense_best_performance_WT, Sense_best_performance_TC, Sense_best_performance_ET,Sense_best_performance,best
def set_random_seed(seed_num):
    if seed_num != '':
        logging.info(f'set random seed: {seed_num}')
        cudnn.benchmark = False
        cudnn.deterministic = True  
        random.seed(seed_num)    
        np.random.seed(seed_num) 
        torch.manual_seed(seed_num) 
        torch.cuda.manual_seed(seed_num) 
def set_argparse():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base_dir', type=str,default='RES/H',
                        help='base dir name')
    parser.add_argument('--data_path', type=str,default='/mnt/sdc/zjj/DATA/BraTS2018_slice',#"/home/zjj/DATA/Hecktor_slice",
                        help='data dir path')
    parser.add_argument('--train_list', type=str,default='randP1_slice_nidus_train.list',
                        help='a list of train data')
    parser.add_argument('--val_list', type=str,default='randP1_slice_nidus_val.list',
                        help='a list of val data')
    parser.add_argument('--img_mode', type=str,default='t1ce',
                        help='medical images mode')
    parser.add_argument('--max_epoch', type=int,default=1,
                        help='maximum epoch')
    parser.add_argument('--batch_size', type=int,default=70,
                        help='batch size per gpu')
    parser.add_argument('--optim_name', type=str,default='adamw',
                        help='optimizer name')
    parser.add_argument('--loss_name', type=str,default='bce',
                        help='loss name')
    parser.add_argument('--lr_scheduler', type=str,default='warmupCosine',
                        help='lr scheduler')
    parser.add_argument('--base_lr', type=float,default=0.0002,
                        help='segmentation network learning rate')
    parser.add_argument('--weight_decay', type=float,default=0.0001,
                        help='weight decay(L2 Regularization)')
    parser.add_argument('--images_rate', type=float,default=0.01,
                        help='images rate')
    parser.add_argument('--Fine_tune', type=bool,default=True,
                        help='Fine_tune') 
    parser.add_argument('--stragey', type=str,default='1d1u',
                        help='the stragey of share_layers:0d0u,1d1u,2d2u,3d3u')
    parser.add_argument('--checkpoint_dir', type=str,default='dsgan_BraTS_t1ce_t2',
                        help='checkpoint_dir')
    parser.add_argument('--Load_pth', type=str,default='latest',
                        help='Load_pth')
    args = parser.parse_args()
    return args

def backup_code(base_dir):
    code_path = os.path.join(base_dir, 'code')
    if not os.path.exists(code_path):
        os.makedirs(code_path)
    train_name = os.path.basename(__file__)
    dataset_name = 'dataset.py'
    shutil.copy('dataloader/' + dataset_name, code_path + '/' + dataset_name)
    shutil.copy(train_name, code_path + '/' + train_name)
if __name__ == '__main__':
    torch.cuda.current_device()
    torch.cuda._initialized = True
    if set_args==True:
        args = set_argparse()
        print('WARNING!!! Using argparse for parameters to obtain ')
        base_dir = args.base_dir
        img_mode = args.img_mode.strip('\'')
        data_path = args.data_path
        Fine_tune = args.Fine_tune
        Load_pth = args.Load_pth
        Strategy = args.stragey
    if not os.path.exists(base_dir):
        os.makedirs(base_dir)
    log_path = os.path.join(base_dir, 'training.log')
    sys.stdout = Logger(log_path=log_path)
    set_logging(log_path=log_path)

    set_random_seed(seed_num=1111)
    """选择GPU ID"""
    gpu_list_str = ','.join(map(str, gpu_list))
    os.environ.setdefault("CUDA_VISIBLE_DEVICES", gpu_list_str)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logging.info(f'Using device : {device}\n'
                 f'\tGPU ID is [{os.environ["CUDA_VISIBLE_DEVICES"]}],using {torch.cuda.device_count()} device\n'
                 f'\tdevice name:{torch.cuda.get_device_name(0)}')

    # # faster convolutions, but more memory
    # torch.backends.cudnn.benchmark = True
    time_now = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
    logging.info('============ Start  train ==============')
    time_tic = time.time()
    train_list = 'randP1_slice_nidus_train.list'
    val_list = 'randP1_slice_nidus_val.list'
    val_list_full = 'randP1_slice_all_val.list'
    test_list_path = data_path+'/randP1_slice_nidus_test.list'
    patientID_list = read_list(data_path+'/randP1_volume_val.list')
    ########################################################################################
    if set_args==True:
        ########### Using Argument Parser ##########
        loss_t,loss_v,dice_t,dice_v_2d,dice_v_3d,\
        dice_v_3d_WT,dice_v_3d_TC,dice_v_3d_ET, \
        PPV_v_3d_WT, PPV_v_3d_TC, PPV_v_3d_ET, \
        Sense_v_3d_WT, Sense_v_3d_TC, Sense_v_3d_ET, lr_curve,net_name,\
        best_performance_WT,best_performance_TC,best_performance_ET,best_performance, \
        PPV_best_performance_WT, PPV_best_performance_TC, PPV_best_performance_ET, PPV_best_performance, \
        Sense_best_performance_WT, Sense_best_performance_TC, Sense_best_performance_ET, Sense_best_performance,best \
            = train_net(args.data_path,args.base_dir,device,args.train_list,args.val_list,time_now,False,
                        args.img_mode,args.lr_scheduler,args.max_epoch,args.batch_size,args.base_lr,args.images_rate,args.optim_name,args.loss_name,args.weight_decay,args.checkpoint_dir,args.Load_pth)
    else:
        loss_t, loss_v, dice_t, dice_v_2d, dice_v_3d, \
        dice_v_3d_WT, dice_v_3d_TC, dice_v_3d_ET, \
        PPV_v_3d_WT, PPV_v_3d_TC, PPV_v_3d_ET, \
        Sense_v_3d_WT, Sense_v_3d_TC, Sense_v_3d_ET, lr_curve, net_name, \
        best_performance_WT, best_performance_TC, best_performance_ET, best_performance, \
        PPV_best_performance_WT, PPV_best_performance_TC, PPV_best_performance_ET, PPV_best_performance, \
        Sense_best_performance_WT, Sense_best_performance_TC, Sense_best_performance_ET, Sense_best_performance,best \
            = train_net(data_path,base_dir,device,train_list,val_list,time_now,False,img_mode)
    base_dir_WT = base_dir + "/WT"
    base_dir_TC = base_dir + "/TC"
    base_dir_ET = base_dir + "/ET"
    if not os.path.exists(base_dir_WT):
        os.makedirs(base_dir_WT)
    if not os.path.exists(base_dir_TC):
        os.makedirs(base_dir_TC)
    if not os.path.exists(base_dir_ET):
        os.makedirs(base_dir_ET)
    plot_dice_loss(loss_t,loss_v,dice_t,dice_v_2d,dice_v_3d_WT,val_3d_interval,lr_curve,base_dir_WT)
    plot_dice_loss(loss_t,loss_v,dice_t,dice_v_2d,dice_v_3d_TC,val_3d_interval,lr_curve,base_dir_TC)
    plot_dice_loss(loss_t,loss_v,dice_t,dice_v_2d,dice_v_3d_ET,val_3d_interval,lr_curve,base_dir_ET)

    logging.info('============= Start  Test ==============')
    model_path_best = os.path.join(base_dir,'model_{}_best.pth'.format(net_name))
    net = torch.load(model_path_best, map_location=device)
    net.to(device=device)
    net.eval()
    logging.info("Model loaded !")

    print(img_mode)
    img_path = '{}/imgs_{}'.format(data_path,img_mode)
    true_path = '{}/masks'.format(data_path)
    logging.info("===========1、Test a little images===========")
    out_path = os.path.join(base_dir, 'outputs')
    if not os.path.exists(out_path):
        os.makedirs(out_path)
    in_files_list = read_list(test_list_path)
    logging.info("test data number: {}".format(len(in_files_list)))
    mean_dice,mean_ppv,mean_sen = test_images(net,device,
                    img_path,true_path,in_files_list,out_path,is_save_img=True)
    logging.info("mean dice is {:.4f}".format(mean_dice))
    logging.info("mean ppv is {:.4f}".format(mean_ppv))
    logging.info("mean sen is {:.4f}".format(mean_sen))

    logging.info("==========2、Evaluate 3d dice and 2d dice======")
    time_tic_test = time.time()
    full_val_list_path = '{}/{}'.format(data_path,val_list_full)
    in_files_full_list = read_list(full_val_list_path)
    mean_dice_3d_WT,mean_dice_3d_TC,mean_dice_3d_ET,mean_ppv_3d_WT,mean_ppv_3d_TC,mean_ppv_3d_ET,mean_sen_3d_WT,mean_sen_3d_TC,mean_sen_3d_ET  = compute_3d_dice(net,device,img_path,
                                true_path,in_files_full_list,patientID_list,out_dir=base_dir)
    mean_dice_all_3d = (mean_dice_3d_WT+mean_dice_3d_TC+mean_dice_3d_ET)/3
    mean_ppv_all_3d = (mean_ppv_3d_WT + mean_ppv_3d_TC + mean_ppv_3d_ET) / 3
    mean_sen_all_3d = (mean_sen_3d_WT + mean_sen_3d_TC + mean_sen_3d_ET) / 3
    time_end_test = time.time()
    print("3d dice test time:",(time_end_test-time_tic_test)/60)
    logging.info("Mean 3d dice WT on all patients:{:.4f} ".format(mean_dice_3d_WT))
    logging.info("Mean 3d dice TC on all patients:{:.4f} ".format(mean_dice_3d_TC))
    logging.info("Mean 3d dice ET on all patients:{:.4f} ".format(mean_dice_3d_ET))
    logging.info("Mean 3d dice on all patients: {:.4f} ".format(mean_dice_all_3d))
    logging.info("Mean 3d ppv WT on all patients:{:.4f} ".format(mean_ppv_3d_WT))
    logging.info("Mean 3d ppv TC on all patients:{:.4f} ".format(mean_ppv_3d_TC))
    logging.info("Mean 3d ppv ET on all patients:{:.4f} ".format(mean_ppv_3d_ET))
    logging.info("Mean 3d ppv on all patients: {:.4f} ".format(mean_ppv_all_3d))

    
    logging.info("Mean 3d sen WT on all patients:{:.4f} ".format(mean_sen_3d_WT))
    logging.info("Mean 3d sen TC on all patients:{:.4f} ".format(mean_sen_3d_TC))
    logging.info("Mean 3d sen ET on all patients:{:.4f} ".format(mean_sen_3d_ET))
    logging.info("Mean 3d sen on all patients: {:.4f} ".format(mean_sen_all_3d))

    
    lr_path_WT = glob.glob(base_dir_WT + '/lr*.jpg')
    new_lr_path_WT = os.path.join(base_dir_WT,'lr-3d_dice{:.4f}.jpg'.format(mean_dice_all_3d))
    os.rename(lr_path_WT[0],new_lr_path_WT)

    lr_path_TC = glob.glob(base_dir_TC + '/lr*.jpg')
    new_lr_path_TC = os.path.join(base_dir_TC,'lr-3d_dice{:.4f}.jpg'.format(mean_dice_all_3d))
    os.rename(lr_path_TC[0],new_lr_path_TC)

    lr_path_ET = glob.glob(base_dir_ET + '/lr*.jpg')
    new_lr_path_ET = os.path.join(base_dir_ET,'lr-3d_dice{:.4f}.jpg'.format(mean_dice_all_3d))
    os.rename(lr_path_ET[0],new_lr_path_ET)

    PPV_best_performance_WT1 = format(PPV_best_performance_WT,".5f")
    PPV_best_performance_TC1 = format(PPV_best_performance_TC, ".5f")
    PPV_best_performance_ET1 = format(PPV_best_performance_ET, ".5f")
    Sense_best_performance_WT1 = format(Sense_best_performance_WT, ".5f")
    Sense_best_performance_TC1 = format(Sense_best_performance_TC, ".5f")
    Sense_best_performance_ET1 = format(Sense_best_performance_ET, ".5f")
    os.rename(base_dir_WT,base_dir_WT+"_"+str(best_performance_WT)+"_"+str(PPV_best_performance_WT1)+"_"+str(Sense_best_performance_WT1))
    os.rename(base_dir_TC,base_dir_TC+"_"+str(best_performance_TC)+"_"+str(PPV_best_performance_TC1)+"_"+str(Sense_best_performance_TC1))
    os.rename(base_dir_ET,base_dir_ET+"_"+str(best_performance_ET)+"_"+str(PPV_best_performance_ET1)+"_"+str(Sense_best_performance_ET1))

    evaluation_dice=(best_performance_WT+best_performance_TC+best_performance_ET)/3
    evaluation_dice = format(evaluation_dice, ".5f")
    evaluation_PPV=(PPV_best_performance_WT+PPV_best_performance_TC+PPV_best_performance_ET)/3
    evaluation_PPV = format(evaluation_PPV, ".5f")
    evaluation_sensitivity=(Sense_best_performance_WT+Sense_best_performance_TC+Sense_best_performance_ET)/3
    evaluation_sensitivity = format(evaluation_sensitivity, ".5f")
    best = format(best, ".5f")
    if Fine_tune:
        os.rename(base_dir, base_dir+"_"+args.checkpoint_dir+"_"+args.Load_pth+"_"+img_mode+"_"+str(args.images_rate)+"_"+str(evaluation_dice)+"_"+str(best))

    time_toc = time.time()
    time_s = time_toc - time_tic
    time_now = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time_toc))
    logging.info("Train finished time: {}".format(time_now))
    logging.info("Time consuming ：{:.2f} min in train and test".format(time_s / 60))
