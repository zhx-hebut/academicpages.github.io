""" Full assembly of the parts to form the complete network """

import torch.nn.functional as F
import torch
import torch.nn as nn
from torchsummary import summary
from torch.cuda.amp import autocast
class DoubleConv(nn.Module):
    """(convolution => [BN] => ReLU) * 2"""

    def __init__(self, in_channels, out_channels, mid_channels=None):
        super().__init__()
        if not mid_channels:
            mid_channels = out_channels
        self.double_conv = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(mid_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.double_conv(x)


class Down(nn.Module):
    """Downscaling with maxpool then double conv"""

    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.maxpool_conv = nn.Sequential(
            nn.MaxPool2d(2),
            DoubleConv(in_channels, out_channels)
        )

    def forward(self, x):
        return self.maxpool_conv(x)


class Up(nn.Module):
    """Upscaling then double conv"""

    def __init__(self, in_channels, out_channels, bilinear=True):
        super().__init__()

        # if bilinear, use the normal convolutions to reduce the number of channels
        if bilinear:
            self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
            self.conv = DoubleConv(in_channels, out_channels // 2, in_channels // 2)
        else:
            self.up = nn.ConvTranspose2d(in_channels , in_channels // 2, kernel_size=2, stride=2)
            self.conv = DoubleConv(in_channels, out_channels)


    def forward(self, x1, x2):
        x1 = self.up(x1)
        # input is CHW
        diffY = torch.tensor([x2.size()[2] - x1.size()[2]])
        diffX = torch.tensor([x2.size()[3] - x1.size()[3]])

        x1 = F.pad(x1, [diffX // 2, diffX - diffX // 2,
                        diffY // 2, diffY - diffY // 2])
        # if you have padding issues, see
        # https://github.com/HaiyongJiang/U-Net-Pytorch-Unstructured-Buggy/commit/0e854509c2cea854e247a9c615f175f76fbb2e3a
        # https://github.com/xiaopeng-liao/Pytorch-UNet/commit/8ebac70e633bac59fc22bb5195e513d5832fb3bd
        x = torch.cat([x2, x1], dim=1)
        return self.conv(x)


class OutConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(OutConv, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)

    def forward(self, x):
        return self.conv(x)
class UNet_share(nn.Module):
    def __init__(self,init_feature_num=32, bilinear=False):
        super(UNet_share, self).__init__()
        feature_num = init_feature_num
        self.bilinear = bilinear
        self.down3 = Down(feature_num*4, feature_num*8)
        factor = 2 if bilinear else 1
        self.down4 = Down(feature_num*8, feature_num*16 // factor)
        self.up1 = Up(feature_num*16, feature_num*8, bilinear)
        self.up2 = Up(feature_num*8, feature_num*4, bilinear)
    def forward(self, x3):
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        x_up1 = self.up1(x5, x4)
        x_up2 = self.up2(x_up1, x3)
        return x_up2

class UNet_mode1(nn.Module):
    def __init__(self, in_channels=1, out_channels=1,init_feature_num=32, bilinear=False):
        super(UNet_mode1, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        feature_num = init_feature_num
        self.bilinear = bilinear

        self.inc_mode1 = DoubleConv(in_channels, feature_num)
        self.down1_mode1 = Down(feature_num, feature_num*2)
        self.down2_mode1 = Down(feature_num*2, feature_num*4)
        factor = 2 if bilinear else 1
        self.up3_mode1 = Up(feature_num*4, feature_num*2, bilinear)
        self.up4_mode1 = Up(feature_num*2, feature_num * factor, bilinear)
        self.outc_mode1_out = OutConv(feature_num, out_channels)
    def forward(self, x, share_model):
        x1 = self.inc_mode1(x)
        x2 = self.down1_mode1(x1)
        x3 = self.down2_mode1(x2)    
        x_up2= share_model(x3)
        x_up3 = self.up3_mode1(x_up2, x2)
        x_up4 = self.up4_mode1(x_up3, x1)
        logits = self.outc_mode1_out(x_up4)
        out = torch.sigmoid(logits)
        return out
class UNet_mode2(nn.Module):
    def __init__(self, in_channels=1, out_channels=1,init_feature_num=32, bilinear=False):
        super(UNet_mode2, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        feature_num = init_feature_num
        self.bilinear = bilinear

        self.inc = DoubleConv(in_channels, feature_num)
        self.down1 = Down(feature_num, feature_num*2)
        self.down2 = Down(feature_num*2, feature_num*4)
        factor = 2 if bilinear else 1
        self.up3 = Up(feature_num*4, feature_num*2, bilinear)
        self.up4 = Up(feature_num*2, feature_num * factor, bilinear)
        self.outc_out = OutConv(feature_num, out_channels)
    def forward(self, x, share_model):
            #with autocast():
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)

        x_up2= share_model(x3)

        x_up3 = self.up3(x_up2, x2)
        x_up4 = self.up4(x_up3, x1)
        logits = self.outc_out(x_up4)
        out = torch.sigmoid(logits)
        return out

class UNet_share_1d1u(nn.Module):
    def __init__(self,init_feature_num=32, bilinear=False):
        super(UNet_share_1d1u, self).__init__()
        feature_num = init_feature_num
        self.bilinear = bilinear
        factor = 2 if bilinear else 1
        self.down4 = Down(feature_num*8, feature_num*16 // factor)
        self.up1 = Up(feature_num*16, feature_num*8, bilinear)
    def forward(self, x4):
        x5 = self.down4(x4)
        x_up1 = self.up1(x5, x4)
        return x_up1

class UNet_mode1_1d1u(nn.Module):
    def __init__(self, in_channels=1, out_channels=1,init_feature_num=32, bilinear=False):
        super(UNet_mode1_1d1u, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        feature_num = init_feature_num
        self.bilinear = bilinear

        self.inc_mode1 = DoubleConv(in_channels, feature_num)
        self.down1_mode1 = Down(feature_num, feature_num*2)
        self.down2_mode1 = Down(feature_num*2, feature_num*4)
        self.down3_mode1 = Down(feature_num*4, feature_num*8)
        factor = 2 if bilinear else 1
        self.up2_mode1 = Up(feature_num*8, feature_num*4, bilinear)
        self.up3_mode1 = Up(feature_num*4, feature_num*2, bilinear)
        self.up4_mode1 = Up(feature_num*2, feature_num * factor, bilinear)
        self.outc_mode1_out = OutConv(feature_num, out_channels)
    def forward(self, x, share_model):
        x1 = self.inc_mode1(x)
        x2 = self.down1_mode1(x1)
        x3 = self.down2_mode1(x2)       
        x4 = self.down3_mode1(x3)       
        x_up1= share_model(x4)
        x_up2 = self.up2_mode1(x_up1, x3)
        x_up3 = self.up3_mode1(x_up2, x2)
        x_up4 = self.up4_mode1(x_up3, x1)
        logits = self.outc_mode1_out(x_up4)
        out = torch.sigmoid(logits)
        return out
class UNet_mode2_1d1u(nn.Module):
    def __init__(self, in_channels=1, out_channels=1,init_feature_num=32, bilinear=False):
        super(UNet_mode2_1d1u, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        feature_num = init_feature_num
        self.bilinear = bilinear

        self.inc = DoubleConv(in_channels, feature_num)
        self.down1 = Down(feature_num, feature_num*2)
        self.down2 = Down(feature_num*2, feature_num*4)
        self.down3 = Down(feature_num*4, feature_num*8)
        factor = 2 if bilinear else 1
        self.up2 = Up(feature_num*8, feature_num*4, bilinear)
        self.up3 = Up(feature_num*4, feature_num*2, bilinear)
        self.up4 = Up(feature_num*2, feature_num * factor, bilinear)
        self.outc_out = OutConv(feature_num, out_channels)
    def forward(self, x, share_model):
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)

        x4 = self.down3(x3)       
        x_up1= share_model(x4)
        x_up2 = self.up2(x_up1, x3)

        x_up3 = self.up3(x_up2, x2)
        x_up4 = self.up4(x_up3, x1)
        logits = self.outc_out(x_up4)
        out = torch.sigmoid(logits)
        return out


class UNet_share_3d3u(nn.Module):
    def __init__(self,init_feature_num=32, bilinear=False):
        super(UNet_share_3d3u, self).__init__()
        feature_num = init_feature_num
        self.bilinear = bilinear
        self.down2 = Down(feature_num*2, feature_num*4)
        self.down3 = Down(feature_num*4, feature_num*8)
        factor = 2 if bilinear else 1
        self.down4 = Down(feature_num*8, feature_num*16 // factor)
        self.up1 = Up(feature_num*16, feature_num*8, bilinear)
        self.up2 = Up(feature_num*8, feature_num*4, bilinear)
        self.up3 = Up(feature_num*4, feature_num*2, bilinear)

    def forward(self, x2):
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        x_up1 = self.up1(x5, x4)
        x_up2 = self.up2(x_up1, x3)
        x_up3 = self.up3(x_up2, x2)
        return x_up3

class UNet_mode1_3d3u(nn.Module):
    def __init__(self, in_channels=1, out_channels=1,init_feature_num=32, bilinear=False):
        super(UNet_mode1_3d3u, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        feature_num = init_feature_num
        self.bilinear = bilinear

        self.inc_mode1 = DoubleConv(in_channels, feature_num)
        self.down1_mode1 = Down(feature_num, feature_num*2)
        factor = 2 if bilinear else 1
        self.up4_mode1 = Up(feature_num*2, feature_num * factor, bilinear)
        self.outc_mode1_out = OutConv(feature_num, out_channels)
    def forward(self, x, share_model):
            #with autocast():
        x1 = self.inc_mode1(x)
        x2 = self.down1_mode1(x1)     
        x_up3= share_model(x2)
        x_up4 = self.up4_mode1(x_up3, x1)
        logits = self.outc_mode1_out(x_up4)
        out = torch.sigmoid(logits)
        return out
class UNet_mode2_3d3u(nn.Module):
    def __init__(self, in_channels=1, out_channels=1,init_feature_num=32, bilinear=False):
        super(UNet_mode2_3d3u, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        feature_num = init_feature_num
        self.bilinear = bilinear
        self.inc = DoubleConv(in_channels, feature_num)
        self.down1 = Down(feature_num, feature_num*2)
        factor = 2 if bilinear else 1
        self.up4 = Up(feature_num*2, feature_num * factor, bilinear)
        self.outc_out = OutConv(feature_num, out_channels)
    def forward(self, x, share_model):
        x1 = self.inc(x)
        x2 = self.down1(x1)     
        x_up3= share_model(x2)
        x_up4 = self.up4(x_up3, x1)
        logits = self.outc_out(x_up4)
        out = torch.sigmoid(logits)
        return out
class UNet(nn.Module):
    def __init__(self, in_channels, out_channels,init_feature_num=32, bilinear=False):
        super(UNet, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        feature_num = init_feature_num
        self.bilinear = bilinear

        self.inc = DoubleConv(in_channels, feature_num)
        self.down1 = Down(feature_num, feature_num*2)
        self.down2 = Down(feature_num*2, feature_num*4)
        self.down3 = Down(feature_num*4, feature_num*8)
        factor = 2 if bilinear else 1
        self.down4 = Down(feature_num*8, feature_num*16 // factor)
        self.up1 = Up(feature_num*16, feature_num*8, bilinear)
        self.up2 = Up(feature_num*8, feature_num*4, bilinear)
        self.up3 = Up(feature_num*4, feature_num*2, bilinear)
        self.up4 = Up(feature_num*2, feature_num * factor, bilinear)
        self.outc_out = OutConv(feature_num, out_channels)
    # @autocast()
    def forward(self, x):
        #with autocast():
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        x = self.up1(x5, x4)
        x = self.up2(x, x3)
        x = self.up3(x, x2)
        x = self.up4(x, x1)
        out = self.outc_out(x)
        out = torch.sigmoid(out)
        return out
class UNet_m1(nn.Module):
    def __init__(self, in_channels=1, out_channels=1,init_feature_num=32, bilinear=False):
        super(UNet_m1, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        feature_num = init_feature_num
        self.bilinear = bilinear

        self.UNet_share = UNet_share(init_feature_num=32)
        self.UNet_mode1 = UNet_mode1(in_channels=self.in_channels, out_channels=self.out_channels, init_feature_num=32)
        
    def forward(self, x):
        out = self.UNet_mode1(x, self.UNet_share)
        return out

class UNet_m2(nn.Module):
    def __init__(self, in_channels=1, out_channels=1,init_feature_num=32, bilinear=False):
        super(UNet_m2, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        feature_num = init_feature_num
        self.bilinear = bilinear

        self.UNet_share = UNet_share(init_feature_num=32)
        self.UNet_mode2 = UNet_mode2(in_channels=self.in_channels, out_channels=self.out_channels, init_feature_num=32)

    def forward(self, x):
        out = self.UNet_mode2(x, self.UNet_share)
        return out
class UNet_m1_1d1u(nn.Module):
    def __init__(self, in_channels=1, out_channels=1,init_feature_num=32, bilinear=False):
        super(UNet_m1_1d1u, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        feature_num = init_feature_num
        self.bilinear = bilinear

        self.UNet_share = UNet_share_1d1u(init_feature_num=32)
        self.UNet_mode1 = UNet_mode1_1d1u(in_channels=self.in_channels, out_channels=self.out_channels, init_feature_num=32)
        
    def forward(self, x):
        out = self.UNet_mode1(x, self.UNet_share)
        return out

class UNet_m2_1d1u(nn.Module):
    def __init__(self, in_channels=1, out_channels=1,init_feature_num=32, bilinear=False):
        super(UNet_m2_1d1u, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        feature_num = init_feature_num
        self.bilinear = bilinear

        self.UNet_share = UNet_share_1d1u(init_feature_num=32)
        self.UNet_mode2 = UNet_mode2_1d1u(in_channels=self.in_channels, out_channels=self.out_channels, init_feature_num=32)

    def forward(self, x):
        out = self.UNet_mode2(x, self.UNet_share)
        return out

class UNet_m1_3d3u(nn.Module):
    def __init__(self, in_channels=1, out_channels=1,init_feature_num=32, bilinear=False):
        super(UNet_m1_3d3u, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        feature_num = init_feature_num
        self.bilinear = bilinear

        self.UNet_share = UNet_share_3d3u(init_feature_num=32)
        self.UNet_mode1 = UNet_mode1_3d3u(in_channels=self.in_channels, out_channels=self.out_channels, init_feature_num=32)
        
    def forward(self, x):
        out = self.UNet_mode1(x, self.UNet_share)
        return out

class UNet_m2_3d3u(nn.Module):
    def __init__(self, in_channels=1, out_channels=1,init_feature_num=32, bilinear=False):
        super(UNet_m2_3d3u, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        feature_num = init_feature_num
        self.bilinear = bilinear

        self.UNet_share = UNet_share_3d3u(init_feature_num=32)
        self.UNet_mode2 = UNet_mode2_3d3u(in_channels=self.in_channels, out_channels=self.out_channels, init_feature_num=32)

    def forward(self, x):
        out = self.UNet_mode2(x, self.UNet_share)
        return out

if __name__ == '__main__':
    device = torch.device('cpu')  #cuda:0
    inputs = torch.rand(1, 144, 144).unsqueeze(0).to(device)
    net = UNet_m1(in_channels=1, out_channels=1,init_feature_num=64)
    res = net(inputs)
    print(summary(net, (1,144 , 144), device="cpu"))
    print('res shape:', res.shape)