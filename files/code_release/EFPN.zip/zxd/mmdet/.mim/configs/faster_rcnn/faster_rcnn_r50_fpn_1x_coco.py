_base_ = [
    '../_base_/models/faster_rcnn_r50_fpn.py',
    '../_base_/datasets/voc0712.py',
    '../_base_/schedules/schedule_2x.py', '../_base_/default_runtime.py'
]
#load_from = '/mnt/sdc/zhangxudong/work_dirs123/mine1/epoch_1.pth'
