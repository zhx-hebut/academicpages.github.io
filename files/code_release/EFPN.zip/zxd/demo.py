from mmdet.apis import init_detector, inference_detector
from mmdet.apis import show_result_pyplot
import os

imagepath = '/mnt/sdb_mount/zxd/mmdetection/data//VOCdevkit/VOC2007/JPEGImages'  # 需要加载的测试图片的文件路径
savepath = '/mnt/sdb_mount/zxd/mmdetection/results_img'  # 保存测试图片的路径
config_file = '/mnt/sdb_mount/zxd/mmdetection/configs/retinanet/retinanet_r50_fpn_1x_coco.py'  # 网络模型
checkpoint_file = '/mnt/sdb_mount/zxd/mmdetection/work_dirs/retinanet_r50_fpn_1x_coco/epoch_1.pth'  # 训练好的模型参数
device = 'cuda:0'
# init a detector
model = init_detector(config_file, checkpoint_file, device=device)
# inference the demo image

for filename in os.listdir(imagepath):
    img = os.path.join(imagepath, filename)
    result = inference_detector(model, img)
    out_file = os.path.join(savepath, filename)
    show_result_pyplot(model, img, result, out_file)
