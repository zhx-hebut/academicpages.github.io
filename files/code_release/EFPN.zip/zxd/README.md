# EFPN: Effective Medical Image Detection Using Feature Pyramid Fusion Enhancement

This repository is the official implementation of CIMB paper [EFPN: Effective Medical Image Detection Using Feature Pyramid Fusion Enhancement](https://www.sciencedirect.com/science/article/abs/pii/S0010482523006145?via%3Dihub). 



## Usage/Train/Test
     Refer to the use of MMdetecion(https://github.com/open-mmlab/mmdetection)


## Citation

If EFPN is useful for your research, please consider citing:
	
	@article{xu2023efpn,
  	title={EFPN: Effective medical image detection using feature pyramid fusion enhancement},
  	author={Xu, Zhenghua and Zhang, Xudong and Zhang, Hexiang and Liu, Yunxin and Zhan, Yuefu and Lukasiewicz, Thomas},
 	 journal={Computers in Biology and Medicine},
  	pages={107149},
  	year={2023},
  	publisher={Elsevier}
	}
  

 If you have some issues, please contact xudongzhang168@gmail.com