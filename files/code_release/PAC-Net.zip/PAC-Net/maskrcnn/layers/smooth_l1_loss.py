# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
import math
import torch
import numpy as np
from Overlaps import bbox_overlaps
# TODO maybe push this to nn?
def smooth_l1_loss(input, target, beta=1. / 9, size_average=True):
    """
    very similar to the smooth_l1_loss from pytorch, but with
    the extra beta parameter
    """

    """ smooth_l1_loss """
    # n = torch.abs(input - target)
    # cond = n < beta
    # smooth_l1_loss = torch.where(cond, 0.5 * n ** 2 / beta, n - 0.5 * beta)
    # if size_average:
    #     return smooth_l1_loss.mean()
    # return smooth_l1_loss.sum()

    """ iou_loss """

    xmin1 = input[:, 0]
    ymin1 = input[:, 1]
    xmax1 = input[:, 2]
    ymax1 = input[:, 3]
    xmin2 = target[:, 0]
    ymin2 = target[:, 1]
    xmax2 = target[:, 2]
    ymax2 = target[:, 3]

    # 获取矩形框交集对应的左上角和右下角的坐标（intersection）
    xx1 = torch.max(xmin1, xmin2)
    yy1 = torch.max(ymin1, ymin2)
    xx2 = torch.min(xmax1, xmax2)
    yy2 = torch.min(ymax1, ymax2)
    # 获取最小包围框(MEB)对应的左上角和右下角的坐标
    xxx1 = torch.min(xmin1, xmin2)
    yyy1 = torch.min(ymin1, ymin2)
    xxx2 = torch.max(xmax1, xmax2)
    yyy2 = torch.max(ymax1, ymax2)
    # 计算两个矩形框面积
    zero = torch.zeros(1, len(xmin1)).cuda()
    area1 = torch.mul(xmax1 - xmin1, ymax1 - ymin1+ 1e-7)
    area2 = torch.mul(xmax2 - xmin2, ymax2 - ymin2+ 1e-7)
    # 计算交集面积
    inter_area = torch.mul(torch.max(zero, xx2 - xx1), torch.max(zero, yy2 - yy1))
    # 计算交并比iou
    iou = inter_area / (area1 + area2 - inter_area + 1e-7)
    # # 计算最小包围框面积
    # area_meb = torch.mul(xxx2 - xxx1, yyy2 - yyy1+ 1e-7)
    # 计算最小包围框对角线长度
    # c2 = (yyy2 - yyy1)**2 + (xxx2 - xxx1)**2 + 1e-7
    # # 计算预测框和目标框中心点距离
    # rho2 = ((xmax2 + xmin2 - xmax1 - xmin1)**2 + (ymax2 + ymin2 - ymax1 - ymin1)**2) / 4
    # 计算预测框和目标框的长宽比一致性
    # v = (4 / (math.pi**2)) * torch.pow(torch.atan((xmax2 - xmin2)/(ymax2 - ymin2 + 1e-7)) - torch.atan((xmax1 - xmin1)/(ymax1 - ymin1 + 1e-7)),2)
    # with torch.no_grad():
    #     alpha = v / (v - iou + (1 + 1e-7))
    # # 计算顶点距离之和
    # vd = torch.pow((xmin2-xmin1),2) + torch.pow((xmax2-xmax1),2) + torch.pow((ymin2-ymin1),2) + torch.pow((ymax2-ymax1),2)

    # giou = iou - (area_meb - area1 - area2 + inter_area)/(area_meb + 1e-7)
    # diou = iou - rho2/c2
    # ciou = iou -(rho2/c2 + v * alpha)
    # vdiou = iou - vd / c2
    iou_loss = 1 - iou
    # giou_loss = 1 - giou
    # diou_loss = 1 - iou + rho2/c2
    # ciou_loss = 1 - ciou
    # vdiou_loss = 1 - vdiou
    # eps = 1e-6
    # iou = bbox_overlaps(input,target,is_aligned=True).clamp(min=eps)
    # loss = -iou.log()
    if size_average:
        return iou_loss.mean()
    return iou_loss.sum()

