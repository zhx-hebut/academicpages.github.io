## PAC-Net: Multi-pathway FPN with position attention guided connections and vertex distance IoU for 3D medical image detection  

This project contains the code of the paper: “PAC-Net: Multi-pathway FPN with position attention guided connections and vertex distance IoU for 3D medical image detection” (https://www.frontiersin.org/articles/10.3389/fbioe.2023.1049555/full)[1].
 

#### Requirements  
* PyTorch 1.1, torchvision 0.3.0  
* Python 3.6  
* If you want to train your own model, the DeepLesion dataset[2] is needed. Download it and modify the path in `paths_catalog.py`.

#### Setup
1. `./setup.sh`
1. `source venv/bin/activate`
1. check `config.yml` to set mode (see below) and parameters;
1. `python run.py`

#### Modes
* __demo__: Use a trained checkpoint, input the path of a nifti image file in terminal, get prediction results (overlaid images) in the `results` folder.
* __train__: Train and validate MULAN on a dataset. Currently the codes are designed for the DeepLesion dataset.
* __eval__: Evaluate a trained model on DeepLesion.
* __vis__: Visualize test results on DeepLesion.

#### References  
1. Zhenghua Xu, Tianrun Li, Yunxin Liu, Yuefu Zhan, Junyang Chen and Thomas Lukasiewicz. PAC-Net: Multi-pathway FPN with position attention guided connections and vertex distance IoU for 3D medical image detection[J]. Frontiers in Bioengineering and Biotechnology(2023). 11:1049555. doi: 10.3389/fbioe.2023.1049555.
2. The DeepLesion dataset. ([download](https://nihcc.box.com/v/DeepLesion))  

#### Citation

If PAC-Net is useful for your research, please consider citing:

    @ARTICLE{10.3389/fbioe.2023.1049555,
    AUTHOR={Xu, Zhenghua and Li, Tianrun and Liu, Yunxin and Zhan, Yuefu and Chen, Junyang and Lukasiewicz, Thomas},    
    TITLE={PAC-Net: Multi-pathway FPN with position attention guided connections and vertex distance IoU for 3D medical image detection},      	
    JOURNAL={Frontiers in Bioengineering and Biotechnology},      	
    VOLUME={11},           	
    YEAR={2023},      	  
    URL={https://www.frontiersin.org/articles/10.3389/fbioe.2023.1049555},       	
    DOI={10.3389/fbioe.2023.1049555},      	
    ISSN={2296-4185},   
    }

 If you have some issues, please contact litianrun1218@gmail.com
