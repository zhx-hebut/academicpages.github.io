# 𝜇-Net: Medical Image Segmentation using Efficient and Effective Deep Supervision

This repository is the official implementation of CIBM paper [𝜇-Net: Medical Image Segmentation using Efficient and Effective Deep Supervision](https://www.sciencedirect.com/science/article/abs/pii/S0010482523004286). 

## Usage
### Requirements

To install requirements:

```setup
pip install -r requirements.txt
```
### Datasets
To download datasets:
- [Medical Segmentation Decathlon](http://medicaldecathlon.com/dataaws/)
- [BraTS 2019](https://www.med.upenn.edu/cbica/brats-2019/)

### Training

To train the model, run this command:

```train
python Train_xxx.py
```

### Evaluation

To evaluate the model, run this command:
```eval
python Test_xxx.py 
```

## Citation

If 𝜇-Net is useful for your research, please cite the following papers:

@article{mu-net2023,
title = {$\mu$-Net: Medical image segmentation using efficient and effective deep supervision},
journal = {Computers in Biology and Medicine},
volume = {160},
pages = {106963},
year = {2023},
author = {Di Yuan and Zhenghua Xu and Biao Tian and Hening Wang and Yuefu Zhan and Thomas Lukasiewicz},
}

@article{ZHANG-MIA2022,
title = {Multi-modal contrastive mutual learning and pseudo-label re-learning for semi-supervised medical image segmentation},
journal = {Medical Image Analysis},
pages = {102656},
year = {2023},
volume = {83},
author = {Shuo Zhang and Jiaojiao Zhang and Biao Tian and Thomas Lukasiewicz and Zhenghua Xu}
}

@article{w-Net2022,
	title={$\omega$-Net: Dual Supervised Medical Image Segmentation with Multi-Dimensional Self-Attention and Diversely-Connected Multi-Scale Convolution},
	author={Xu, Zhenghua and Liu, Shijie and Yuan, Di and Wang, Lei and Chen, Junyang and Lukasiewicz, Thomas and Fu, Zhigang and Zhang, Rui},
	journal={Neurocomputing},
volume = {500},
pages = {177-190},
	year={2022}
}


 If you have any question, please contact yuandi.hn@gmail.com