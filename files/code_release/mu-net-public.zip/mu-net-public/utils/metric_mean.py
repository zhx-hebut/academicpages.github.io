import numpy as np
import os

root = './Results/nestedae_2020-06-09_22:02:02_4_100_0.0003_101/nestedae_epoch_38'

def devide(x):
    temp = np.load(os.path.join(root,'test_'+ str(x) +'_array.npy'))
    _wt = temp[:,0]
    _et = temp[:,1]
    _cy = temp[:,2]

    #print('{:.4f},{:.4f},{:.4f}'.format(1-sum(_wt)/4896,1-sum(_et/4896),1-sum(_cy/4896)))
    print('{:.4f},{:.4f},{:.4f}'.format(sum(_wt)/4896,sum(_et/4896),sum(_cy/4896)))

devide('dice')
devide('ppv')
devide('sensi')
devide('iou')
