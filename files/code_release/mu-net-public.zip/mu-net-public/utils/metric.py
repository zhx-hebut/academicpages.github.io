import numpy as np
import os
from PIL import Image
from pylab import *
import imageio
import time
from datetime import datetime, date, timedelta


def rewrite(x):
    y = (x > 127).astype('uint8')
    return y

def test(pic1,pic2):
    picc1 = pic1#[0,:,:,:]
    picc2 = pic2#[0,:,:,:]

    if picc1.shape[2] == picc2.shape[2]:
        N = picc1.shape[2]

        picc1 = rewrite(picc1)
        picc2 = rewrite(picc2)

        picc1_flat = picc1.reshape(-1,N)
        picc1_flat = picc1_flat.T
        picc2_flat = picc2.reshape(-1,N)
        picc2_flat = picc2_flat.T

        intersection = picc1_flat * picc2_flat
        T = picc2_flat.sum(1)

        P = picc1_flat.sum(1)
        TP = intersection.sum(1)
        FP = P-TP
        FN = T-TP

        dice = ((2*TP) +1) / (T+P+1)
        dice_loss = 1 - dice.sum()/N

        ppv = (TP+1) / (TP+FP+1)
        ppv_loss = 1 - ppv.sum()/N

        sensitivity = (TP+1) / (TP+FN+1)
        sensitivity_loss = 1 - sensitivity.sum()/N

        iou = (TP+1) / (T+P-TP +1)
        iou_loss = 1 - iou.sum()/N

    else:
        print('size dont match')

    return dice,dice_loss,ppv,ppv_loss,sensitivity,sensitivity_loss,iou,iou_loss

for b in range(1,2):
    dir = './Val/tw_2021-08-20_19:23:03_8_0.0003_1151012'
    root = './Val/tw_2021-08-20_19:23:03_8_0.0003_1151012/tw_epoch_{}'.format(b)

    dir1 = os.path.join(root, 'SEG_OUT')
    dir2 = os.path.join(root,'SEG_GT')

    dice_ = []
    ppv_ = []
    sensi_ = []
    iou_ = []
    dices_ = []
    ppvs_ = []
    sensis_ = []
    ious_ = []

    j = 0
    list = os.listdir(dir1)[:]

    for i in list:
        if i.endswith('.png'):
            path1 = os.path.join(dir1,i)
            path2 = os.path.join(dir2,i)

            pic1 = imageio.imread(path1)
            pic2 = imageio.imread(path2)
            dice_s,dice,ppv_s,ppv,sensi_s,sensi, iou_s,iou = test(pic1,pic2)

            dice_.append(dice)
            ppv_.append(ppv)
            sensi_.append(sensi)
            iou_.append(iou)
            dices_.append(dice_s)
            ppvs_.append(ppv_s)
            sensis_.append(sensi_s)
            ious_.append(iou_s)

            j += 1

            with open(os.path.join(root,'Log_metric.txt'), 'a') as log:
                log.write("Step: {}\n".format(j))
                log.write("Dice: {:.4f}, PPV:{:.4f}, Sensi:{:.4f}, IoU:{:.4f}\n".format((1-dice)*100,(1-ppv)*100,(1-sensi)*100,(1-iou)*100))

            if j%8 == 0:
                dice_a = sum(dice_)/j
                ppv_a = sum(ppv_)/j
                sensi_a = sum(sensi_)/j
                iou_a = sum(iou_)/j

                B = "Epoch[{}/{}],Step[{}/{}],Dice:{:.4f},PPV:{:.4f},Sensi:{:.4f},IoU:{:.4f}\n".format(b,100,j,len(list),(1-dice_a)*100,(1-ppv_a)*100,(1-sensi_a)*100,(1-iou_a)*100)
                print(B)
                with open(os.path.join(root,'Log_metric.txt'), 'a') as log:
                    log.write(B)

                if j == len(list):
                    Three = (1-dice_a)*100 + (1-ppv_a)*100 + (1-sensi_a)*100
                    Toal = Three + (1-iou_a)*100

                    C = "Epoch[{}/{}],Step[{}/{}],Dice:{:.4f},PPV:{:.4f},Sensi:{:.4f},IoU:{:.4f},Toal:{:.4f},Three:{:.4f}\n".format(b,100,j,len(list),(1-dice_a)*100,(1-ppv_a)*100,(1-sensi_a)*100,(1-iou_a)*100,Toal,Three)
                    print(C)
                    with open(os.path.join(dir,'metric.txt'), 'a') as log:
                        log.write(C)

            np.save(os.path.join(root,'test_dice_list.npy'),dice_)
            np.save(os.path.join(root,'test_ppv_list.npy'),ppv_)
            np.save(os.path.join(root,'test_sensi_list.npy'),sensi_)
            np.save(os.path.join(root,'test_iou_list.npy'),iou_)
            np.save(os.path.join(root,'test_dice_array'),dices_)
            np.save(os.path.join(root,'test_ppv_array.npy'),ppvs_)
            np.save(os.path.join(root,'test_sensi_array.npy'),sensis_)
            np.save(os.path.join(root,'test_iou_array.npy'),ious_)
