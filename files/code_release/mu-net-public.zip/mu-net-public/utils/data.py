import numpy as np
import torch
import torch.utils.data
import os
import torchvision
from PIL import Image
from torchvision import transforms
class med(torch.utils.data.Dataset):
    def __init__(self,img,anno,transform = None):
        # TODO
        self.img = img
        self.anno = anno
        self.transform = transform

    def __getitem__(self):
        # TODO
        # 1. Read one data from file (e.g. using numpy.fromfile, PIL.Image.open).
        # 2. Preprocess the data (e.g. torchvision.Transform).
        # 3. Return a data pair (e.g. image and label).
        img = self.img
        anno = self.anno
        imgi = Image.open(img).convert('L')
        imgi = imgi.resize((240,240))

        #img_apath = self.img_alist[index]
        imga = Image.open(anno).convert('L')
        imga = imga.resize((240,240))

        if self.transform is not None:
             imgi = self.transform(imgi)
             imga = self.transform(imga)
             imagei = imgi#.type(torch.FloatTensor)
             imagea = imga#.type(torch.FloatTensor)

        return imagei,imagea

    def __len__(self):
        # You should change 0 to the total size of your dataset.
        return len(self.img)
