import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
import model_wsl_only as model
from torch.autograd import Variable
import med_dataset_wsl as med_dataset
from torchvision.utils import save_image
import datetime
import os
import numpy as np
import sys
import time

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
num_epochs = 100
batch_size = 4
learning_rate = 0.0003
log_path = '/mnt/sdb/yd2tb/yd2tianbiao_checkpoints'
#格式化函数：设置时间文件夹
folder_name = "{0}_{1}_{2}_{3}_{4}_{5}".format('wsl_only',datetime.datetime.now().strftime("%Y-%m-%d_%H:%M:%S"),batch_size,num_epochs,learning_rate,'113')
#格式转换
trans = transforms.ToTensor()

custom_dataset = med_dataset.med('/mnt/sdb/yd2tb/yd2tianbiao/data/train/train',
                                '/mnt/sdb/yd2tb/yd2tianbiao/data/train/anno',
                                transform = trans)
train_dataset = torch.utils.data.DataLoader(dataset=custom_dataset,
                                            batch_size = batch_size,
                                            shuffle = True)

def denorm(x):
    out = (x + 1) / 2
    return out.clamp(0, 1)  #clamp，区间限定函数，返回的value介于0,1之间

def rewrite(x):
    y = (x > 0.5).astype('uint8')
    return y

def mergeout(x):
    ori_image = x.reshape(x.size(0),3,240,240)

    return ori_image

def mergepic(x):
    ori_image = x.reshape(x.size(0),1,240,240)

    return ori_image

net = model.UNet(3, merge_mode='concat').to(device)
#net = nn.DataParallel(net, device_ids=[0, 1])
net.load_state_dict(torch.load('/mnt/sdb/yd2tb/yd2tianbiao/checkpoints/wsl_only/5_unet_MODEL.pth', map_location='cuda:0'))
#net = nn.DataParallel(net, device_ids=[0, 1])

#net = torch.load('/media/yuandi/47284faf-4849-4681-925e-ac9a4e104d72/brats2018/data/data/all/Results/2_unet_MODEL.ckpt')
criterionbce = nn.BCELoss()
criterionmse = nn.MSELoss()

# training
try:
    for epoch in range(num_epochs):

        optimizer = torch.optim.Adam(net.parameters(), lr=learning_rate)

        if epoch%3 == 1:
            learning_rate = learning_rate*0.9
            print(learning_rate)

        time00 = time.time()
        for i, (imagei,imagea,imageal) in enumerate(train_dataset):
            #x = x.to(device)
            #y = y.to(device)
            time0 = time.time()
            #imagei = imagei.type(torch.FloatTensor)
            imagei = imagei.to(device)
            #imagea = imagea.type(torch.FloatTensor)
            imagea = imagea.to(device)
            imageal = imageal.to(device)

            out, ori_unet_outs = net(imagei)
            segout, seg_unet_outs = net(imageal)

            #创建文件夹保存运行结果
            if not os.path.exists(os.path.join(log_path,folder_name,'SEG_GT','epoch-{}'.format(epoch+1))):
                os.makedirs(os.path.join(log_path,folder_name,'SEG_GT','epoch-{}'.format(epoch+1)))
            if not os.path.exists(os.path.join(log_path,folder_name,'SEG_AE','epoch-{}'.format(epoch+1))):
                os.makedirs(os.path.join(log_path,folder_name,'SEG_AE','epoch-{}'.format(epoch+1)))
            if not os.path.exists(os.path.join(log_path,folder_name,'SEG_OUT','epoch-{}'.format(epoch+1))):
                os.makedirs(os.path.join(log_path,folder_name,'SEG_OUT','epoch-{}'.format(epoch+1)))
            #保存图像
            if not os.path.exists(os.path.join(log_path,folder_name,'AE_GT','epoch-{}'.format(epoch+1))):
                os.makedirs(os.path.join(log_path,folder_name,'AE_GT','epoch-{}'.format(epoch+1)))
            if not os.path.exists(os.path.join(log_path,folder_name,'AE_OUT','epoch-{}'.format(epoch+1))):
                os.makedirs(os.path.join(log_path,folder_name,'AE_OUT','epoch-{}'.format(epoch+1)))

            oriout_images = mergeout(imagea)
            save_image(oriout_images, os.path.join(log_path,folder_name,'SEG_GT','epoch-{}'.format(epoch+1),'images-{}.png'.format(i+1)))

            out_images = mergeout(out)
            save_image(out_images,os.path.join(log_path,folder_name,'SEG_OUT','epoch-{}'.format(epoch+1),'image-{}.png'.format(i+1)))

            seg_ae_images = mergeout(segout)
            save_image(seg_ae_images,os.path.join(log_path,folder_name,'SEG_AE','epoch-{}'.format(epoch+1),'image-{}.png'.format(i+1)))

            oripic_images = mergepic(imagei)
            save_image(oripic_images, os.path.join(log_path,folder_name,'AE_GT','epoch-{}'.format(epoch+1),'images-{}.png'.format(i+1)))

            loss_s = criterionbce(out, imagea)

            loss_m = []
            for ind in range(len(ori_unet_outs)-1):
                lossm = criterionmse(ori_unet_outs[ind],seg_unet_outs[ind])
                loss_m.append(lossm)
            lossm = sum(loss_m)

            loss_segae = criterionbce(segout,imagea)

            loss = 1*loss_s + 1*lossm + 3*loss_segae
            #loss = loss_s + 5*lossm + 2*loss_segae

            loss.backward()

            #优化
            optimizer.step()
            optimizer.zero_grad()

            time1 = time.time()
            timed = time1 - time0
            timea = time1 - time00

            #保存记录
            with open(os.path.join(log_path,folder_name,'Log.txt'), 'a') as log:
                log.write("Epoch: {}, iteration: {}\n".format(epoch+1, i+1))
                log.write("Loss: {:.4f}, Loss_s: {:.4f}, Loss_m:{:.4f}, Loss_sae:{:.4f}, time: {:.4f},timea:{:.4f}\n".format(loss.item(),loss_s.item(),lossm.item(), loss_segae.item(), timed, timea))

            #输出Epoch、step、loss、time
            if i%8 == 0:
                time11 = time.time()
                timedd = time11-time00
                B = "Epoch[{}/{}],step[{}/{}],loss:{:.4f},loss_s:{:.4f},loss_m:{:.4f}, loss_segae:{:.4f},time:{:.4f},timef:{:.4f}".format(epoch+1,num_epochs,i+1,len(train_dataset),loss.item(),loss_s.item(),lossm.item(),loss_segae.item(),timed,timedd)
                print(B)

        torch.save(net.state_dict(),os.path.join(log_path,folder_name,'{}_wslonly_MODEL.pth'.format(epoch+1)))

except KeyboardInterrupt:
    torch.save(net.state_dict(),os.path.join(log_path,folder_name,'interrupt_wslonly_MODEL.pth'.format(epoch+1)))
    print('Saved interrupt')
    try:
        sys.exit(0)
    except SystemExit:
        os._exit(0)
