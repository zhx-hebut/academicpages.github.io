import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from collections import OrderedDict
from torch.nn import init
import numpy as np

def rewrite(x):
    y = (x > 0.5).astype('uint8')
    return y

def conv3x3(in_channels, out_channels, stride=1,
            padding=1, bias=True, groups=1):
    return nn.Conv2d(
        in_channels,
        out_channels,
        kernel_size=3,
        stride=stride,
        padding=padding,
        bias=bias,
        groups=groups)

def upconv2x2(in_channels, out_channels, mode='transpose'):
    if mode == 'transpose':
        return nn.ConvTranspose2d(
            in_channels,
            out_channels,
            kernel_size=2,
            stride=2)
    else:
        return nn.Sequential(
            nn.Upsample(mode='bilinear', scale_factor=2),
            conv1x1(in_channels, out_channels))

def conv1x1(in_channels, out_channels, groups=1):
    return nn.Conv2d(
        in_channels,
        out_channels,
        kernel_size=1,
        groups=groups,
        stride=1)


class DownConv(nn.Module):

    def __init__(self, in_channels, out_channels, pooling=True):
        super(DownConv, self).__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.pooling = pooling

        self.conv1 = conv3x3(self.in_channels, self.out_channels)
        self.conv2 = conv3x3(self.out_channels, self.out_channels)

        if self.pooling:
            self.pool = nn.MaxPool2d(kernel_size=2, stride=2)

    def forward(self, x):
        x = self.conv1(x)
        x = F.relu(x)
        x = self.conv2(x)
        x = F.relu(x)
        before_pool = x     #for connecting directly
        if self.pooling:
            x = self.pool(x)
        return x, before_pool


class UpConv(nn.Module):

    def __init__(self, in_channels, out_channels,
                 merge_mode='concat', up_mode='transpose'):
        super(UpConv, self).__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.merge_mode = merge_mode
        self.up_mode = up_mode

        self.upconv = upconv2x2(self.in_channels, self.out_channels,
            mode=self.up_mode)

        if self.merge_mode == 'concat':
            self.conv1 = conv3x3(
                2*self.out_channels, self.out_channels)
        else:
            self.conv1 = conv3x3(self.out_channels, self.out_channels)
        self.conv2 = conv3x3(self.out_channels, self.out_channels)


    def forward(self, from_down, from_up):

        from_up = self.upconv(from_up)
        if self.merge_mode == 'concat':
            x = torch.cat((from_up, from_down), 1)
        else:
            x = from_up + from_down
        x = self.conv1(x)
        x = F.relu(x)
        x = self.conv2(x)
        x = F.relu(x)
        return x


class UpConv_noconcat(nn.Module):

    def __init__(self, in_channels, out_channels,
                 up_mode='transpose'):
        super(UpConv_noconcat, self).__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.up_mode = up_mode

        self.upconv = upconv2x2(self.in_channels, 2*self.out_channels,
            mode=self.up_mode)

        self.conv1 = conv3x3(2*self.out_channels, self.out_channels)
        self.conv2 = conv3x3(self.out_channels, self.out_channels)
        #self.bn = nn.BatchNorm2d(self.out_channels)


    def forward(self, from_up):

        from_up = self.upconv(from_up)
        x = self.conv1(from_up)
        #x = self.bn(x)
        x = F.relu(x)
        x = self.conv2(x)
        #x = self.bn(x)
        x = F.relu(x)
        return x
        

class UNet(nn.Module):

    def __init__(self, num_classes, in_channels=1, depth=5,
                 start_filts=64, up_mode='transpose',
                 merge_mode='concat'):

        super(UNet, self).__init__()

        if up_mode in ('transpose', 'upsample'):
            self.up_mode = up_mode
        else:
            raise ValueError("\"{}\" is not a valid mode for "
                             "upsampling. Only \"transpose\" and "
                             "\"upsample\" are allowed.".format(up_mode))

        if merge_mode in ('concat', 'add'):
            self.merge_mode = merge_mode
        else:
            raise ValueError("\"{}\" is not a valid mode for"
                             "merging up and down paths. "
                             "Only \"concat\" and "
                             "\"add\" are allowed.".format(up_mode))

        # NOTE: up_mode 'upsample' is incompatible with merge_mode 'add'
        if self.up_mode == 'upsample' and self.merge_mode == 'add':
            raise ValueError("up_mode \"upsample\" is incompatible "
                             "with merge_mode \"add\" at the moment "
                             "because it doesn't make sense to use "
                             "nearest neighbour to reduce "
                             "depth channels (by half).")

        self.num_classes = num_classes
        self.in_channels = in_channels
        self.start_filts = start_filts
        self.depth = depth

        self.down_convs = []
        self.up_convs = []
        self.up_convs_nocat = []

        for i in range(depth):
            ins = self.in_channels if i == 0 else outs
            outs = self.start_filts*(2**i)
            pooling = True if i < depth-1 else False

            down_conv = DownConv(ins, outs, pooling=pooling)
            self.down_convs.append(down_conv)

        outs_o = outs
        for i in range(depth-1):
            ins = outs
            outs = ins // 2
            up_conv = UpConv(ins, outs, up_mode=up_mode,
                merge_mode=merge_mode)
            self.up_convs.append(up_conv)

        outs = outs_o
        for i in range(depth-1):
            ins = outs
            outs = ins // 2
            up_conv_nocat = UpConv_noconcat(ins, outs, up_mode=up_mode)
            self.up_convs_nocat.append(up_conv_nocat)

        self.conv_final = conv1x1(outs, self.num_classes)
        self.conv_final_re = conv1x1(outs,self.in_channels)

        self.down_convs = nn.ModuleList(self.down_convs)
        self.up_convs = nn.ModuleList(self.up_convs)
        self.up_convs_nocat = nn.ModuleList(self.up_convs_nocat)

        self.reset_params()

    '''
    @staticmethod
    def weight_init(m):
        if isinstance(m, nn.Conv2d):
            nn.init.xavier_normal_(m.weight)
            nn.init.constant_(m.bias, 0)
    '''
    @staticmethod
    def weight_init(m):
        if isinstance(m, nn.Conv2d):
            nn.init.kaiming_normal_(m.weight)
            nn.init.constant_(m.bias, 0)
    

    def reset_params(self):
        for i, m in enumerate(self.modules()):
            self.weight_init(m)

    def reparameterize(self, mu, log_var):
        std = torch.exp(log_var/2)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x):
        encoder_outs = []
        decoder_outs_s = []
        decoder_outs_o = []

        for i, module in enumerate(self.down_convs):
            x, before_pool = module(x)
            encoder_outs.append(before_pool)

        seg = x
        for i, module in enumerate(self.up_convs):
            before_pool = encoder_outs[-(i+2)]
            seg = module(before_pool, seg)
            decoder_outs_s.append(seg)

        ori = x
        '''
        for i, module in enumerate(self.up_convs):
            before_pool = encoder_outs[-(i+2)]
            ori = module(before_pool, ori)
            decoder_outs_o.append(ori)
        '''
        for i, module in enumerate(self.up_convs_nocat):
            if i == 0:
                mu = encoder_outs[-(i+1)]
                log_var = encoder_outs[-(i + 1)]
                ori = self.reparameterize(mu, log_var)
            ori = module(ori)
            decoder_outs_o.append(ori)

        seg = self.conv_final(seg)
        seg = torch.sigmoid(seg)
        ori = self.conv_final_re(ori)
        ori = torch.sigmoid(ori)

        return seg, ori, decoder_outs_s, decoder_outs_o

'''
if __name__ == "__main__":
    """
    testing
    """

from torch.autograd import Variable
#device = torch.device('cpu')
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
model = UNet(1, merge_mode='concat', depth = 5).to(device)
#optimizer = torch.optim.Adam(model.parameters(), lr=0.0002)
l = 0.01
X = torch.zeros(3,3,240,240)
X = X.to(device)
Y = torch.ones(3,3,240,240)
Y = Y.to(device)
criterionbce = nn.BCELoss()
criterionmse = nn.MSELoss()
for epoch in range(100):
    optimizer = torch.optim.Adam(model.parameters(), lr=l)
    y, x, decoder_outs, _ = model(X)
    _, s, _, decoder_o = model(Y)
    if epoch%5 == 1:
        l = l*0.9
    #print(l)
    #print(x)
    #print(y)
    #print(x)
    loss_m = []
    #sou = torch.sigmoid(decoder_outs[0])
    #tar = torch.sigmoid(decoder_o[0])
    #tar = Variable(tar, requires_grad = False)
    #print(tar)
    #print(y)
    #print(x)
    #lossm = criterionbce(sou, tar)
    #print(lossm)
    #print(lossm)
    #print(decoder_o[0])

    for i in range(len(decoder_outs)):
        lossm = criterionmse(decoder_outs[i], decoder_o[i])
        loss_m.append(lossm)
    #print(loss_m)
    print(len(loss_m))
    lossm = sum(loss_m)
    print(lossm)

    #lossmm = criterionmse(decoder_outs, decoder_o)
    #print(lossmm)
    #lossmiddle = loss_m.sum()
    #print(decoder_o.size())
    #print(X.size())
    #loss_o = criterion(x, X)
    #print(loss_o)
    #loss_s = criterion(y, Y)
    #for i in range(decoder_o.size())
    #loss = loss_o + loss_s + lossmiddle
    #print(lossmiddle.item())
    #print(loss_o,loss_s)
    #print(loss)

    lossm.backward()
    optimizer.step()

    optimizer.zero_grad()
'''
'''
def mganno(x):
    ori_image = x.reshape(x.size(0),3,240,240)
    ori1 = ori_image[:,0,:,:]
    ori2 = ori_image[:,1,:,:]
    ori3 = ori_image[:,2,:,:]
    ori = torch.zeros(x.size(0),1,240,240)
    ori[:,0,:,:] = ori1 + ori2 + ori3
    return ori

x = torch.ones(3,3,240,240)
y = mganno(x)
print(x)
print(y.size())
'''
