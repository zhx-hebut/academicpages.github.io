import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
import model_uae as model
from torch.autograd import Variable
import med_dataset_wsl as med_dataset
from torchvision.utils import save_image
import datetime
import os
import numpy as np
import sys
import time
import argparse

from loss import BCEDiceLoss

# Device configuration
device = torch.device('cuda:3' if torch.cuda.is_available() else 'cpu')
num_epochs = 60
batch_size = 4
batch_size_val = 1
learning_rate=0.0003
train_path = '/mnt/sdd/yuandi'
log_path = '/mnt/sdd/yuandi'
a=4
b=1
c=1
d=1

#格式化函数：设置时间文件夹
folder_name = "{0}_{1}_{2}_{3}_{4}{5}{6}{7}".format('uae',datetime.datetime.now().strftime("%Y-%m-%d_%H:%M:%S"),batch_size,learning_rate,a,b,c,d)

#格式转换
trans = transforms.ToTensor()

custom_dataset = med_dataset.med('./data/train/train',
                                './data/train/anno',
                                transform = trans)
train_dataset = torch.utils.data.DataLoader(dataset=custom_dataset,
                                            batch_size = batch_size,
                                            shuffle = True)


def denorm(x):
    out = (x + 1) / 2
    return out.clamp(0, 1)  #clamp，区间限定函数，返回的value介于0,1之间

def rewrite(x):
    y = (x > 0.5).astype('uint8')#*255
    return y

def mergeout(x):
    ori_image = x.reshape(x.size(0),3,240,240)
    return ori_image

def mergepic(x):
    ori_image = x.reshape(x.size(0),1,240,240)
    return ori_image

net_u = model.UNet(3, merge_mode='concat').to(device)
net_ae = model.AE(3).to(device)
#net = nn.DataParallel(net, device_ids=[0, 1])
net_u.load_state_dict(torch.load('/mnt/sdb/yd2tb/yd2tianbiao/checkpoints/uae_2020-10-22_09:30:22_4_0.0003_4111/8_ua_MODEL.pth', map_location='cuda:3'))
net_ae.load_state_dict(torch.load('/mnt/sdb/yd2tb/yd2tianbiao/checkpoints/uae_2020-10-22_09:30:22_4_0.0003_4111/8_uae_MODEL.pth', map_location='cuda:3'))
criterionbce = nn.BCELoss()
criterionbcedice = BCEDiceLoss()
criterionmse = nn.MSELoss()

try:
    for epoch in range(num_epochs):
        optimizer = torch.optim.Adam(net_u.parameters(), lr=learning_rate)
        optimizer1 = torch.optim.Adam(net_ae.parameters(), lr=learning_rate)

        if epoch%3 == 1:
            learning_rate = learning_rate*0.9

        time00 = time.time()
        for i, (imagei,imagel,imagea) in enumerate(train_dataset):
            #print(imagea.shape)
            #x = x.to(device)
            #y = y.to(device)
            #imagel 3-channel
            time0 = time.time()
            #imagei = imagei.type(torch.FloatTensor)
            imagei = imagei.to(device)
            #imagea = imagea.type(torch.FloatTensor)
            imagea = imagea.to(device)
            imagel = imagel.to(device)

            out, interout = net_u(imagei)
            _, _, ori = net_ae(imagei)
            mask, intermask, _ = net_ae(imagea)

            #创建文件夹保存运行结果
            if not os.path.exists(os.path.join(log_path,folder_name,'SEG_GT','epoch-{}'.format(epoch+1))):
                os.makedirs(os.path.join(log_path,folder_name,'SEG_GT','epoch-{}'.format(epoch+1)))
            if not os.path.exists(os.path.join(log_path,folder_name,'SEG_OUT','epoch-{}'.format(epoch+1))):
                os.makedirs(os.path.join(log_path,folder_name,'SEG_OUT','epoch-{}'.format(epoch+1)))
            if not os.path.exists(os.path.join(log_path,folder_name,'ORI_GT','epoch-{}'.format(epoch+1))):
                os.makedirs(os.path.join(log_path,folder_name,'ORI_GT','epoch-{}'.format(epoch+1)))
            if not os.path.exists(os.path.join(log_path,folder_name,'ORI_OUT','epoch-{}'.format(epoch+1))):
                os.makedirs(os.path.join(log_path,folder_name,'ORI_OUT','epoch-{}'.format(epoch+1)))
            if not os.path.exists(os.path.join(log_path,folder_name,'MASK_OUT','epoch-{}'.format(epoch+1))):
                os.makedirs(os.path.join(log_path,folder_name,'MASK_OUT','epoch-{}'.format(epoch+1)))

            oriout_images = mergeout(imagel)
            save_image(oriout_images, os.path.join(log_path,folder_name,'SEG_GT','epoch-{}'.format(epoch+1),'images-{}.png'.format(i+1)))
            out_images = mergeout(out)
            save_image(out_images,os.path.join(log_path,folder_name,'SEG_OUT','epoch-{}'.format(epoch+1),'image-{}.png'.format(i+1)))
            ori_images = mergepic(imagei)
            save_image(ori_images, os.path.join(log_path,folder_name,'ORI_GT','epoch-{}'.format(epoch+1),'images-{}.png'.format(i+1)))
            oriae_images = mergepic(ori)
            save_image(oriae_images,os.path.join(log_path,folder_name,'ORI_OUT','epoch-{}'.format(epoch+1),'image-{}.png'.format(i+1)))
            outae_images = mergeout(mask)
            save_image(outae_images, os.path.join(log_path,folder_name,'MASK_OUT','epoch-{}'.format(epoch+1),'images-{}.png'.format(i+1)))

            loss_u = criterionbcedice(out, imagel)
            loss_segae = criterionbcedice(mask, imagel)
            loss_oriae = criterionbcedice(ori, imagei)
            
            loss_m = []
            for ind in range(len(interout)-1):
                lossm = criterionmse(interout[ind],intermask[ind])
                loss_m.append(lossm)
            lossm = sum(loss_m)
            
            loss = a*loss_u + b*loss_segae + c*loss_oriae + d*lossm
            loss.backward()

            #优化
            optimizer.step()
            optimizer.zero_grad()
            optimizer1.step()
            optimizer1.zero_grad()

            time1 = time.time()
            timed = time1 - time0
            timea = time1 - time00
            #保存记录
            if (i+1)==len(train_dataset):
                with open(os.path.join(log_path,folder_name,'Log.txt'), 'a') as log:
                    log.write("Epoch: {}, ".format(epoch+1))
                    log.write("Loss: {:.4f}, Time:{:.4f}, Loss_u:{:.4f}, Loss_segae:{:.4f}, Loss_oriae:{:.4f}, Lossm:{:.4f}\n".format(loss.item(), timea, loss_u.item(), loss_segae.item(), loss_oriae.item(), lossm.item()))

            if i%8 == 0:
                time11 = time.time()
                timedd = time11-time00
                B = "Epoch[{}/{}],step[{}/{}],Loss: {:.4f}, Time:{:.4f}, Loss_u:{:.4f}, Loss_segae:{:.4f}, Loss_oriae:{:.4f}, Lossm:{:.4f},timed:{:.4f},timedd:{:.4f}".format(epoch+1,num_epochs,i+1,len(train_dataset),loss.item(), timea, loss_u.item(), loss_segae.item(), loss_oriae.item(), lossm.item(),timed,timedd)
                print(B)
            # if (i+1)==len(train_dataset):
            #     with open(os.path.join(log_path,folder_name,'Log.txt'), 'a') as log:
            #         log.write("Epoch: {}, ".format(epoch+1))
            #         log.write("Loss: {:.4f}, Time:{:.4f}, Loss_u:{:.4f}, Loss_segae:{:.4f}, Loss_oriae:{:.4f}\n".format(loss.item(), timea, loss_u.item(), loss_segae.item(), loss_oriae.item()))

            # if i%5 == 0:
            #     time11 = time.time()
            #     timedd = time11-time00
            #     B = "Epoch[{}/{}],step[{}/{}],Loss: {:.4f}, Time:{:.4f}, Loss_u:{:.4f}, Loss_segae:{:.4f}, Loss_oriae:{:.4f}".format(epoch+1,num_epochs,i+1,len(train_dataset),loss.item(), timea, loss_u.item(), loss_segae.item(), loss_oriae.item())
            #     print(B)


        torch.save(net_u.state_dict(),os.path.join(log_path,folder_name,'{}_ua_MODEL.pth'.format(epoch+1)))
        torch.save(net_ae.state_dict(),os.path.join(log_path,folder_name,'{}_uae_MODEL.pth'.format(epoch+1)))

except KeyboardInterrupt:
    torch.save(net_u.state_dict(),os.path.join(log_path,folder_name,'interrupt_ua_MODEL.pth'.format(epoch+1)))
    torch.save(net_ae.state_dict(),os.path.join(log_path,folder_name,'interrupt_uae_MODEL.pth'.format(epoch+1)))
    print('Saved interrupt')
    try:
        sys.exit(0)
    except SystemExit:
        os._exit(0)
