import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from collections import OrderedDict
from torch.nn import init
import numpy as np

def rewrite(x):
    y = (x > 0.5).astype('uint8')
    return y

def conv3x3(in_channels, out_channels, stride=1,
            padding=1, bias=True, groups=1):
    conv = nn.Sequential(nn.Conv2d(in_channels, out_channels,
        kernel_size=3, stride=stride,
        padding=padding, bias=bias, groups=groups),
        nn.ReLU())
    return conv    #F.relu(conv)

def upconv2x2(in_channels, out_channels):
    return nn.ConvTranspose2d(in_channels, out_channels,
        kernel_size=2, stride=2)

def upconv4x4(in_channels, out_channels):
    return nn.ConvTranspose2d(in_channels, out_channels,
        kernel_size=4, stride=4)

def upconv8x8(in_channels, out_channels):
    return nn.ConvTranspose2d(in_channels, out_channels,
        kernel_size=8, stride=8)

def conv1x1(in_channels, out_channels, groups=1):
    return nn.Conv2d(in_channels, out_channels,
        kernel_size=1, groups=groups, stride=1)

def DoubleConv(in_channels, out_channels):
    return nn.Sequential(
        conv3x3(in_channels, out_channels),
        conv3x3(out_channels, out_channels)
    )

class DeepModel(nn.Module):
    def __init__(self, num_classes, in_channels=1, merge_mode='concat'):
        super(DeepModel, self).__init__()

        self.num_classes = num_classes
        self.in_channels = in_channels
        self.merge_mode = merge_mode

        # self.input1 = conv3x3(self.in_channels, 32)
        self.input2 = conv3x3(self.in_channels, 64)
        self.input3 = conv3x3(self.in_channels, 128)
        self.input4 = conv3x3(self.in_channels, 256)

        self.avgpool = nn.AvgPool2d(kernel_size=2, stride=2)
        self.maxpool = nn.MaxPool2d(kernel_size=2, stride=2)

        self.conv1 = DoubleConv(self.in_channels, 32)
        # self.conv1 = nn.Conv2d(1, 32,
        # kernel_size=3)
        self.conv2 = DoubleConv(96, 64)
        self.conv3 = DoubleConv(192, 128)
        self.conv4 = DoubleConv(384, 256)
        self.conv5 = DoubleConv(256, 512)

        self.up4 = upconv2x2(512, 512)
        self.up3 = upconv2x2(256, 256)
        self.up2 = upconv2x2(128, 128)
        self.up1 = upconv2x2(64, 64)

        # self.de5 = DoubleConv(256, 512)
        self.de4 = DoubleConv(768, 256)
        self.de3 = DoubleConv(384, 128)
        self.de2 = DoubleConv(192, 64)
        self.de1 = DoubleConv(96, 32)

        self.final1 = conv1x1(32, self.num_classes)
        self.final2 = upconv2x2(64, self.num_classes)
        self.final3 = upconv4x4(128, self.num_classes)
        self.final4 = upconv8x8(256, self.num_classes)


    def forward(self, x):
        img1 = x
        img2 = self.avgpool(img1)
        img3 = self.avgpool(img2)
        img4 = self.avgpool(img3)

        # input1 = self.input1(img1)
        input2 = self.input2(img2)
        input3 = self.input3(img3)
        input4 = self.input4(img4)

        conv1 = self.conv1(img1)
        conv1_pool = self.maxpool(conv1)
        merge2 = torch.cat((conv1_pool, input2), 1)
        conv2 = self.conv2(merge2)
        conv2_pool = self.maxpool(conv2)
        merge3 = torch.cat((conv2_pool, input3), 1)
        conv3 = self.conv3(merge3)
        conv3_pool = self.maxpool(conv3)
        merge4 = torch.cat((conv3_pool, input4), 1)
        conv4 = self.conv4(merge4)
        conv4_pool = self.maxpool(conv4)
        conv5 = self.conv5(conv4_pool)

        conv4_de = self.up4(conv5) # 512
        cat4 = torch.cat((conv4, conv4_de), 1) # 512 256
        up4 = self.de4(cat4) # 768 - 256
        conv3_de = self.up3(up4) # 256
        cat3 = torch.cat((conv3, conv3_de), 1)  # 384

        up3 = self.de3(cat3) # 128
        conv2_de = self.up2(up3) # 128
        cat2 = torch.cat((conv2, conv2_de), 1) # 192
        up2 = self.de2(cat2) # 64
        conv1_de = self.up1(up2) # 64
        cat1 = torch.cat((conv1, conv1_de), 1) # 96
        up1 = self.de1(cat1) # 32

        out1 = self.final1(up1)
        out2 = self.final2(up2)
        out3 = self.final3(up3)
        out4 = self.final4(up4)
        out1 = torch.sigmoid(out1)
        out2 = torch.sigmoid(out2)
        out3 = torch.sigmoid(out3)
        out4 = torch.sigmoid(out4)
        # print(out1.shape, out2.shape, out3.shape, out4.shape)

        out = (out1 + out2 + out3 + out4) / 4
        # print('out:', out.shape)

        return out

# from torchsummary import summary
# net = DeepModel(3)
# # print(net)
# summary(net, (3, 240, 240), batch_size=4)