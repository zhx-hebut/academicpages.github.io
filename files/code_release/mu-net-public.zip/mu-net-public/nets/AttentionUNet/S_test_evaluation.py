from torch.autograd import Variable
from Attention_UNet import AttentionUNet
from torch.utils.data import DataLoader
from torchvision.utils import save_image
import data_load_get
import torchvision
import torchvision.transforms as transforms
import torch
import torch.nn as nn
import numpy as np
import os
import time
import datetime
from PIL import Image


class Option:
    def __init__(self):
        self.cuda = True  # use cuda
        self.testBatchSize = 1  # testing batch size
        self.threads = 4
        self.size = 512
        self.runing_mode = 'test'
        self.target_mode = 'anno'
        self.test_out_path = "/mnt/b/MICCAI_BraTS_2019_Data_Training/data/test/"
        self.pretrain_net = "/mnt/b/MICCAI_BraTS_2019_Data_Training/attentionunet/checkpoints/1_Attention_UNet_MODEL.pth"


opt = Option()

out_test_folder_name = "{}_{}_{}".format(opt.runing_mode, datetime.datetime.now().strftime("%Y-%m-%d_%H:%M:%S"),
                                              opt.testBatchSize)

trans = transforms.ToTensor()

print('===> Loading datasets')
custom_dataset = data_load_get.DataGet('{}/train'.format(opt.runing_mode),
                                       '{}/anno'.format(opt.runing_mode), transform=trans)
test_dataset = torch.utils.data.DataLoader(dataset=custom_dataset, batch_size=opt.testBatchSize, shuffle=False)

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
"""
jia gpu
"""
net = AttentionUNet(3, merge_mode='concat')
if torch.cuda.device_count() > 1:
    net = nn.DataParallel(net)

print('===> starting test')
net.to(device)

if torch.cuda.is_available():
    device = torch.device('cuda:0')
else:
    device = torch.device('cpu')


def denorm(x):
    out = (x + 1) / 2
    return out.clamp(0, 1)


def rewrite(x):
    y = (x > 0.5).astype('uint8')
    return y


def mergeout(x):
    ori_image = x.reshape(x.size(0), 3, 240, 240)
    return ori_image


def mergepic(x):
    ori_image = x.reshape(x.size(0), 1, 240, 240)
    return ori_image


net.load_state_dict(torch.load(opt.pretrain_net))

criterion = nn.BCELoss()

time00 = time.time()


def evaluation(output, target):
    output = output[0, :, :, :]
    target = target[0, :, :, :]
    if output.shape[0] == target.shape[0]:
        N = output.shape[0]
        output = rewrite(output)
        target = rewrite(target)
        output_flat = output.reshape(N, -1)
        target_flat = target.reshape(N, -1)

        intersection = output_flat * target_flat
        T = target_flat.sum(1)
        P = output_flat.sum(1)
        TP = intersection.sum(1)
        FP = P-TP
        FN = T-TP

        dice = ((2*TP) + 1) / (T+P+1)
        dice_mean = dice.sum()/N

        ppv = (TP+1) / (TP+FP+1)
        ppv_mean = ppv.sum()/N

        sensitivity = (TP+1) / (TP+FN+1)
        sensitivity_mean = sensitivity.sum()/N


        iou = (TP+1) / (T+P-TP +1)
        iou_loss = iou.sum()/N

    else:
        print('size not match')

    return dice, dice_mean, ppv, ppv_mean, sensitivity, sensitivity_mean, iou, iou_mean


def add_background(number):
    output_chun_path = os.path.join(opt.test_out_path, out_test_folder_name, 'output_chun')
    input_path = os.path.join(opt.test_out_path, out_test_folder_name, 'input')
    # img = io.imread(os.path.join(input_path, 'image-{}.png'.format(number)))
    # seg = io.imread(os.path.join(output_chun_path, 'segmentation-{}.png'.format(number)))
    img = Image.open(os.path.join(input_path, 'image-{}.png'.format(number)))
    seg = Image.open(os.path.join(output_chun_path, 'segmentation-{}.png'.format(number)))
    img = np.array(img)
    seg = np.array(seg)

    img = torch.from_numpy(img)
    seg = torch.from_numpy(seg)
    #
    # print(img.shape)
    # print(seg.shape)

    segbin = torch.add(seg[:, :, 0], seg[:, :, 2])

    segbin = np.greater(segbin, 10)
    # print(segbin.shape)
    repeated_segbin = np.stack((segbin, segbin, segbin), axis=-1)
    # print(repeated_segbin.shape)

    alpha = 0.8
    seg = np.array(seg).astype(np.int32)
    img = np.array(img).astype(np.int32)
    prediction_hecheng = np.where(repeated_segbin, np.array(np.round(alpha * seg + (1 - alpha) * img)).astype(np.uint8),
                         np.array(np.round(img)).astype(np.uint8))

    # os.makedirs(os.path.join(opt.test_out_path, out_test_folder_name))
    '''
    scipy.misc.imsave(os.path.join(opt.test_out_path, out_test_folder_name, 'prediction/prediction-{}.png'
                                   .format(number)), prediction_hecheng)
    '''
    save_image(prediction_hecheng, os.path.join(opt.test_out_path, out_test_folder_name, 'prediction/prediction-{}.png'
                                                .format(number)))


def test():
    net.eval()
    total_loss = 0
    for number, (image, label) in enumerate(test_dataset, 1):
        # print('number is:', number)
        # x = x.to(device)
        # y = y.to(device)
        time0 = time.time()
        # imagei = imagei.type(torch.FloatTensor)
        image = image.to(device)
        # imagea = imagea.type(torch.FloatTensor)
        # print('label.shape is:', label.shape)
        label = label.to(device)

        # out, opic = net(imagei)
        prediction_seg = net(image)
        # prediction_seg, prediction_img_re = net(image)
        # print("prediction_seg is:", prediction_seg)
        # print("prediction_seg_type is:", type(prediction_seg))
        prediction_seg = prediction_seg.data
        # print("prediction_seg is:", prediction_seg)
        # print("prediction_seg.shape is:", prediction_seg.shape)
        # print("prediction_img_re.shape is:", prediction_img_re.shape)
        # print('opt.seg.shape is:', seg.shape)
        # print('opt.img_re.shape is:', img_re.shape)

        label_chun_path = os.path.join(opt.test_out_path, out_test_folder_name, 'label_chun')
        if not os.path.exists(label_chun_path):
            os.makedirs(label_chun_path)
        output_chun_path = os.path.join(opt.test_out_path, out_test_folder_name, 'output_chun')
        if not os.path.exists(output_chun_path):
            os.makedirs(output_chun_path)
        input_path = os.path.join(opt.test_out_path, out_test_folder_name, 'input')
        if not os.path.exists(input_path):
            os.makedirs(input_path)
        # prediction_seg_decode_path = os.path.join(opt.test_out_path, out_test_folder_name, 'prediction_seg_decode')
        # if not os.path.exists(prediction_seg_decode_path):
        #     os.makedirs(prediction_seg_decode_path)
        # prediction_hecheng_path = os.path.join(opt.test_out_path, out_test_folder_name, 'prediction')
        # if not os.path.exists(prediction_hecheng_path):
        #     os.makedirs(prediction_hecheng_path)

        seg_liver = prediction_seg[:, 0, :, :]
        seg_tumor = prediction_seg[:, 1, :, :]

        label_liver = label[:, 0, :, :]
        label_tumor = label[:, 2, :, :]
        seg_green = torch.zeros(prediction_seg.shape[0], 240, 240)
        bi_label = torch.stack((label_liver.cuda(), label_tumor.cuda()), 1)

        output_prediction_seg = torch.stack((seg_liver.cuda(), seg_green.cuda(), seg_tumor.cuda()), 1)
        # prediction_decode = torch.stack((seg_de_liver.cuda(), seg_green.cuda(), seg_de_tumor.cuda()), 1)
        # print('output_image.shape is:', output_image.shape)
        # print(type(output_image))
        # print(output_image.size())
        # img = torch.from_numpy(img)
        # seg = torch.from_numpy(seg)

        if number % 10 == 0:
            label = mergeout(label)
            save_image(label, os.path.join(label_chun_path, 'label-{}.png'.format(number)))
            output_chun = mergeout(output_prediction_seg)
            save_image(output_chun, os.path.join(output_chun_path, 'segmentation-{}.png'.format(number)))
            image = mergepic(image)
            save_image(image, os.path.join(input_path, 'image-{}.png'.format(number)))
            # prediction_decode = mergeout(prediction_decode)
            # save_image(prediction_decode, os.path.join(prediction_seg_decode_path, 'prediction_seg_decode-{}.png'
            # .format(number)))

            '''
            add_background(number)
            '''
        loss_seg = criterion(prediction_seg, bi_label)
        loss = loss_seg

        # loss_de = criterion(prediction_img_re, image)
        # loss_seg = criterion(prediction_seg, bi_label)
        # loss = loss_re + 10 * loss_seg
        # print('loss.size is:', loss.size())
        # print(type(loss))
        # print(loss)
        total_loss = total_loss + float(loss)
        # print('total_loss is:', total_loss.size())
        # print('total_loss_type is:', type(total_loss))
        # print(total_loss)

        time1 = time.time()
        timed = time1 - time0

        with open(os.path.join(opt.test_out_path, out_test_folder_name, 'Loss.txt'), 'a') as log:
            log.write('number: {}\n'.format(number))
            log.write("Loss: {}, Loss_seg: {}, time: {}\n"
                      .format(loss.item(), loss_seg.item(), timed))

        # if number % 5 == 0:
        #     print("图像测试{},loss:{:.4f},loss_re:{:4f},loss_seg:{:4f},timef:{:.4f}"
        #           .format(number, loss.item(), loss_re.item(), loss_seg.item(), timed))

        bi_label_np = np.array(bi_label.cpu())
        prediction_seg_np = np.array(prediction_seg.cpu())
        # print('target_np.size is:', np.size(target_np))
        # print('target_np is:', target_np)
        # print('prediction_np.size is:', np.size(prediction_np))
        # print('prediction_np. is:', prediction_np)
        bi_label_np_path = os.path.join(opt.test_out_path, out_test_folder_name, 'bi_label_npy')
        if not os.path.exists(bi_label_np_path):
            os.makedirs(bi_label_np_path)
        prediction_seg_np_path = os.path.join(opt.test_out_path, out_test_folder_name, 'prediction_seg_npy')
        if not os.path.exists(prediction_seg_np_path):
            os.makedirs(prediction_seg_np_path)
        np.save(os.path.join(bi_label_np_path, 'bi_label_array_{}.npy'.format(number)), bi_label_np)
        np.save(os.path.join(prediction_seg_np_path, 'prediction_seg_array_{}.npy'.format(number)), prediction_seg_np)
    dir_prediction_seg = prediction_seg_np_path
    dir_bi_label = bi_label_np_path
    print('\t')
    print('\t')

    print("===> 测试的平均loss为: {:.6f} dB".format(total_loss / len(test_dataset)),
          "该患者的测试CT影像共有:{}张".format(len(test_dataset)))
    print('\t')
    return dir_prediction_seg, dir_bi_label


with torch.no_grad():
    dir_prediction_seg, dir_bi_label = test()

dice = []
ppv = []
sensi = []
iou = []
dice_mean = []
ppv_mean = []
sensi_mean = []
iou_mean = []

# dice_average_list = []
# ppv_average_list = []
# sensi_average_list = []

j = 0
total_dice = 0
total_ppv = 0
total_sensi = 0
total_iou = 0

list_pre = os.listdir(dir_prediction_seg)
# list_lab = os.listdir(dir_bi_label)
# print(list_pre)
# print(list_lab)
#
# c = [list_pre, list_lab]
# for s in c:
#     for i, j in s.items():

# for i in list_pre, j in list_lab:
for i in range(len(list_pre)):
    path_prediction_seg = os.path.join(dir_prediction_seg, 'prediction_seg_array_{}.npy'.format(i + 1))
    # print(path_prediction)
    path_bi_label = os.path.join(dir_bi_label, 'bi_label_array_{}.npy'.format(i + 1))
    # print(path_target)
    Prediction = np.load(path_prediction_seg)
    Target = np.load(path_bi_label)
    # print('Prediction is:', Prediction)
    # print('Target is:', Target)
    DICE, DICE_mean, PPV, PPV_mean, SENSI, SENSI_mean, IOU, IOU_mean = evaluation(Prediction, Target)
    # print('DICE is:', DICE, 'DICE_mean is:', DICE_mean, 'PPV is:', PPV, 'PPV_mean is:', PPV_mean,
    #       'SENSI is:', SENSI, 'SENSI_mean is:', SENSI_mean)
    dice.append(DICE)
    # print(type(dice_mean))
    dice_mean.append(DICE_mean)
    ppv.append(PPV)
    ppv_mean.append(PPV_mean)
    sensi.append(SENSI)
    sensi_mean.append(SENSI_mean)
    iou.append(IOU)
    iou_mean.append(IOU_mean)
    # print('dice.len is:', len(dice), 'dice is:', dice)
    # print('dice_mean.len is:', len(dice_mean), 'dice_mean is:', dice_mean)
    # print('ppv.len is:', len(ppv), 'ppv is:', ppv)
    # print('ppv_mean.len is:', len(ppv_mean), 'ppv_mean is:', ppv_mean)
    # print('sensi.len is:', len(sensi), 'sensi is:', sensi)
    # print('sensi_mean.len is:', len(sensi_mean), 'sensi_mean is:', sensi_mean)
    #
    # print('dice_mean[0] is:', dice_mean[0])
    # print('ppv_mean[0] is:', ppv_mean[0])
    # print('sensi_mean[0] is:', sensi_mean[0])

    with open(os.path.join(opt.test_out_path, out_test_folder_name, 'Log_metric.txt'), 'a') as log:
        log.write("Step: {}\n".format(j))
        log.write("Dice: {:.4f}, PPV:{:.4f}, Sensi:{:.4f}, IoU:{:.4f}\n".format(dice_mean[j], ppv_mean[j], sensi_mean[j], iou_mean[j]))

    total_dice += dice_mean[j]
    total_ppv += ppv_mean[j]
    total_sensi += sensi_mean[j]
    total_iou += iou_mean[j]

    j += 1

    if j % 10 == 0:
        # dice_average = sum(total_dice) / j
        dice_average = total_dice / j
        ppv_average = total_ppv / j
        sensi_average = total_sensi / j
        iou_average = total_iou / j
        B = "Step[{}/{}],Dice_average:{:.4f}, PPV_average:{:.4f}, Sensi_average:{:.4f}, IoU_average:{:.4f}"\
            .format(j, len(list_pre), dice_average, ppv_average, sensi_average, iou_average)
        print(B)
        with open(os.path.join(opt.test_out_path, out_test_folder_name, 'Log_metric.txt'), 'a') as log:
            log.write(B)
        print('\t')

#        dice_average_list.append(dice_average)
#        ppv_average_list.append(ppv_average)
#        sensi_average_list.append(sensi_average)

    np.save(os.path.join(opt.test_out_path, out_test_folder_name, 'test_dice_array.npy'), dice_mean)
    np.save(os.path.join(opt.test_out_path, out_test_folder_name, 'test_ppv_array.npy'), ppv_mean)
    np.save(os.path.join(opt.test_out_path, out_test_folder_name, 'test_sensi_array.npy'), sensi_mean)
    np.save(os.path.join(opt.test_out_path, out_test_folder_name, 'test_iou_array.npy'), iou_mean)
#   np.save(os.path.join(root, 'test_dice_average_list.npy'), dice_average_list)
#   np.save(os.path.join(root, 'test_ppv_average_list.npy'), ppv_average_list)
#   np.save(os.path.join(root, 'test_sensi_average_list.npy'), sensi_average_list)


def devide(x):
    eval = np.load(os.path.join(opt.test_out_path, out_test_folder_name, 'test_' + str(x) + '_array.npy'))
    # b = np.load(os.path.join(root, 'test_' + str(x) + '_list.npy'))

    # print('eval is :', eval)
    # print('j is:', j)
    # print('eval.number is:', eval.size)
    print('===> 评估影像数为:', eval.size)
    print('\t')
    # print('eval.shape is:', eval.shape)
    # print('eval.type is:', type(eval))

    print('===> {}均值为:'.format(x), sum(eval)/j)
    print('\t')
    # print('{}_average is:'.format(x), b)
    with open(os.path.join(opt.test_out_path, out_test_folder_name, 'Log_metric.txt'), 'a') as log:
        log.write('{}均值为: {}'.format(x, sum(eval)/j))


devide('dice')
# print('===> 相似性系数均值为：', dice_mean)
devide('ppv')
# print('===> 阳性预测准确率均值为：', ppv_mean)
devide('sensi')
# print('===> 敏感度均值为：', sensitivity_mean)
device('iou')
# print('===> IoU均值为：', iou_mean)
print('\t')

# print('诊断结束，谢谢使用，祝您健康')
