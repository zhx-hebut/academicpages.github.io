import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from torch.nn import init
import numpy as np
from torch.nn import BatchNorm2d  as SynchronizedBatchNorm2d

def rewrite(x):
    y = (x > 0.5).astype('uint8')
    return y


def conv3x3(in_channels, out_channels, stride=1, padding=1, bias=True, groups=1):
    return nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=padding, bias=bias, groups=groups)


def conv1x1(in_channels, out_channels, groups=1):
    return nn.Conv2d(in_channels, out_channels, kernel_size=1, groups=groups, stride=1)


def upconv2x2(in_channels, out_channels, mode='transpose'):
    if mode == 'transpose':
        return nn.ConvTranspose2d(in_channels, out_channels, kernel_size=2, stride=2)
    else:
        return nn.Sequential(nn.Upsample(mode='bilinear', scale_factor=2), conv1x1(in_channels, out_channels))


class _GridAttentionBlockND(nn.Module):
    def __init__(self, in_channels, gating_channels, inter_channels=None, dimension=2, mode='concatenation',
                 sub_sample_factor=(2, 2, 2)):
        super(_GridAttentionBlockND, self).__init__()

        assert dimension in [2, 3]
        assert mode in ['concatenation', 'concatenation_debug', 'concatenation_residual']

        # Downsampling rate for the input featuremap
        if isinstance(sub_sample_factor, tuple):
            self.sub_sample_factor = sub_sample_factor
        elif isinstance(sub_sample_factor, list):
            self.sub_sample_factor = tuple(sub_sample_factor)
        else:
            self.sub_sample_factor = tuple([sub_sample_factor]) * dimension
        # print('self.sub_sample_factor is:', self.sub_sample_factor)

        # Default parameter set
        self.mode = mode
        self.dimension = dimension
        self.sub_sample_kernel_size = self.sub_sample_factor
        # print('self.sub_sample_kernel_size is:', self.sub_sample_kernel_size)

        # Number of channels (pixel dimensions)
        self.in_channels = in_channels
        self.gating_channels = gating_channels
        self.inter_channels = inter_channels
        # print('self.in_channels is:', self.in_channels)
        # print('self.gating_channels is:', self.gating_channels)
        # print('self.inter_channels is:', self.inter_channels)

        if self.inter_channels is None:
            self.inter_channels = in_channels // 2
            if self.inter_channels == 0:
                self.inter_channels = 1
        # print('self.inter_channels is:', self.inter_channels)
        # print('dimension is:', dimension)

        if dimension == 3:
            conv_nd = nn.Conv3d
            bn = nn.BatchNorm3d
            self.upsample_mode = 'trilinear'
        elif dimension == 2:
            conv_nd = nn.Conv2d
            bn = SynchronizedBatchNorm2d
            self.upsample_mode = 'bilinear'
        else:
            raise NotImplemented

        # Output transform
        # print("output transform place here !")
        self.W = nn.Sequential(
            conv_nd(in_channels=self.in_channels, out_channels=self.in_channels, kernel_size=1, stride=1, padding=0),
            bn(self.in_channels),
        )

        # Theta^T * x_ij + Phi^T * gating_signal + bias
        self.theta = conv_nd(in_channels=self.in_channels, out_channels=self.inter_channels,
                             kernel_size=self.sub_sample_kernel_size, stride=self.sub_sample_factor, padding=0, bias=False)
        self.phi = conv_nd(in_channels=self.gating_channels, out_channels=self.inter_channels,
                           kernel_size=1, stride=1, padding=0, bias=True)
        self.psi = conv_nd(in_channels=self.inter_channels, out_channels=1, kernel_size=1, stride=1, padding=0, bias=True)

        # print("plan to mode here !")
        # # Initialise weights
        # for m in self.children():
        #     init_weights(m, init_type='kaiming')

        # Define the operation
        if mode == 'concatenation':
            self.operation_function = self._concatenation
            # print("plan to concatenation here !")
        elif mode == 'concatenation_debug':
            self.operation_function = self._concatenation_debug
            # print("plan to concatenation_debug here !")
        elif mode == 'concatenation_residual':
            self.operation_function = self._concatenation_residual
        else:
            raise NotImplementedError('Unknown operation function.')

    def _concatenation(self, x, g):
        input_size = x.size()
        batch_size = input_size[0]

        # print("input_size is:", input_size)
        # print("batch_size is:", batch_size)
        assert batch_size == g.size(0)

        # theta => (b, c, h, w) -> (b, i_c, h, w) -> (b, i_c, hw)
        # phi   => (b, g_d) -> (b, i_c)
        theta_x = self.theta(x)
        theta_x_size = theta_x.size()

        # g (b, c, h', w') -> phi_g (b, i_c, h', w')
        #  Relu(theta_x + phi_g + bias) -> f = (b, i_c, hw) -> (b, i_c, h/s1, w/s2)
        phi_g = F.upsample(self.phi(g), size=theta_x_size[2:], mode=self.upsample_mode)
        f = F.relu(theta_x + phi_g, inplace=True)
        # print("f.size is :", f.size())

        #  psi^T * f -> (b, psi_i_c, t/s1, h/s2, w/s3)
        sigm_psi_f = F.sigmoid(self.psi(f))
        # print("sigm_psi_f.size is :", sigm_psi_f.size())

        # upsample the attentions and multiply
        sigm_psi_f = F.upsample(sigm_psi_f, size=input_size[2:], mode=self.upsample_mode)
        y = sigm_psi_f.expand_as(x) * x
        # print("y.size is :", y.size())
        W_y = self.W(y)

        # print("W_y.size is :", W_y.size())
        return W_y, sigm_psi_f

    def forward(self, x, g):
        '''
        :param x: (b, c, t, h, w)
        :param g: (b, g_d)
        :return:
        '''
        def _concatenation(self, x, g):
            input_size = x.size()
            batch_size = input_size[0]

            # print("input_size is:", input_size)
            # print("batch_size is:", batch_size)
            assert batch_size == g.size(0)

            # theta => (b, c, h, w) -> (b, i_c, h, w) -> (b, i_c, hw)
            # phi   => (b, g_d) -> (b, i_c)
            theta_x = self.theta(x)
            theta_x_size = theta_x.size()

            # g (b, c, h', w') -> phi_g (b, i_c, h', w')
            #  Relu(theta_x + phi_g + bias) -> f = (b, i_c, hw) -> (b, i_c, h/s1, w/s2)
            phi_g = F.upsample(self.phi(g), size=theta_x_size[2:], mode=self.upsample_mode)
            f = F.relu(theta_x + phi_g, inplace=True)
            # print("f.size is :", f.size())

            #  psi^T * f -> (b, psi_i_c, t/s1, h/s2, w/s3)
            sigm_psi_f = torch.sigmoid(self.psi(f))
            # print("sigm_psi_f.size is :", sigm_psi_f.size())

            # upsample the attentions and multiply
            sigm_psi_f = F.upsample(sigm_psi_f, size=input_size[2:], mode=self.upsample_mode)
            y = sigm_psi_f.expand_as(x) * x
            # print("y.size is :", y.size())
            W_y = self.W(y)

            # print("W_y.size is :", W_y.size())
            return W_y, sigm_psi_f

        # print("wan cheng GridAttentionBlock2D")
        output = self._concatenation(x, g)
        # output_1, output_2 = self._concatenation(x, g)

        # print("wan cheng GridAttentionBlock2D")
        return output


class GridAttentionBlock2D(_GridAttentionBlockND):
    def __init__(self, in_channels, gating_channels, inter_channels=None, dimension=2, mode='concatenation',
                 sub_sample_factor=(2, 2)):
        super(GridAttentionBlock2D, self).__init__(in_channels, inter_channels=inter_channels,
                                                   gating_channels=gating_channels, dimension=2, mode=mode,
                                                   sub_sample_factor=sub_sample_factor)


class DownConv(nn.Module):
    """
    A helper Module that performs 2 convolutions and 1 MaxPool.
    A ReLU activation follows each convolution.
    """

    def __init__(self, in_channels, out_channels, pooling=True):
        super(DownConv, self).__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.pooling = pooling

        self.conv1 = conv3x3(self.in_channels, self.out_channels)
        self.conv2 = conv3x3(self.out_channels, self.out_channels)
        self.batchnorm = SynchronizedBatchNorm2d(self.out_channels)
        if self.pooling:
            self.pool = nn.MaxPool2d(kernel_size=2, stride=2)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.relu(self.batchnorm(self.conv2(x)))
        before_pool = x
        if self.pooling:
            x = self.pool(x)
        return x, before_pool


class UpConv(nn.Module):
    def __init__(self, in_channels, out_channels, merge_mode='concat', up_mode='transpose'):
        super(UpConv, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.merge_mode = merge_mode
        self.up_mode = up_mode

        self.upconv = upconv2x2(self.in_channels, self.out_channels, mode=self.up_mode)
        self.batchnorm = SynchronizedBatchNorm2d(self.out_channels)
        # self.batchnorm = SynchronizedBatchNorm2d(self.out_channels)
        self.attention = GridAttentionBlock2D(in_channels=self.out_channels, inter_channels=None,
                                              gating_channels=self.in_channels, dimension=2, mode='concatenation',
                                              sub_sample_factor=(2, 2))

        if self.merge_mode == 'concat':
            self.conv1 = conv3x3(2 * self.out_channels, self.out_channels)
        else:
            self.conv1 = conv3x3(self.out_channels, self.out_channels)
        self.conv2 = conv3x3(self.out_channels, self.out_channels)

    def forward(self, from_down, from_up):
        W_y, sigm_psi_f = self.attention(from_down, from_up)
        from_up_upconv = self.upconv(from_up)
        if self.merge_mode == 'concat':
            x = torch.cat((from_up_upconv, W_y), 1)
        else:
            x = from_up + from_down
        x = F.relu(self.conv1(x))
        x = F.relu(self.batchnorm(self.conv2(x)))
        return x


class AttentionUNet(nn.Module):
    def __init__(self, num_classes, in_channels=1, depth=5, start_filts=64, up_mode='transpose', merge_mode='concat'):
        super(AttentionUNet, self).__init__()
        self.up_mode = up_mode
        self.merge_mode = merge_mode

        self.num_classes = num_classes
        self.in_channels = in_channels
        self.start_filts = start_filts
        self.depth = depth

        self.down_convs = []
        self.up_convs = []

        for i in range(depth):
            if i == 0:
                input_channels = self.in_channels
            else:
                input_channels = output_channels
            output_channels = self.start_filts * (2 ** i)

            if i < (depth - 1):
                pooling = True
            else:
                pooling = False

            down_conv = DownConv(input_channels, output_channels, pooling=pooling)
            self.down_convs.append(down_conv)

        output_de_channels = output_channels
        for i in range(depth - 1):
            input_de_channels = output_de_channels
            output_de_channels = input_de_channels // 2
            up_conv = UpConv(input_de_channels, output_de_channels, up_mode=up_mode, merge_mode=merge_mode)
            self.up_convs.append(up_conv)

        self.conv_final = conv1x1(output_de_channels, self.num_classes)

        # add the list of modules to current module
        self.down_convs = nn.ModuleList(self.down_convs)
        self.up_convs = nn.ModuleList(self.up_convs)

        # self.reset_params()

    @staticmethod
    def weight_init(m):
        if isinstance(m, nn.Conv2d):
            nn.init.xavier_normal_(m.weight)
            nn.init.constant_(m.bias, 0)
    
    def reset_params(self):
        for i, m in enumerate(self.modules()):
            self.weight_init(m)

    def forward(self, x):
        encoder_outs = []
        # encoder pathway, save outputs for merging
        for i, module in enumerate(self.down_convs):
            x, before_pool = module(x)
            encoder_outs.append(before_pool)

        del before_pool

        before_attention = x

        del x
        # del self.down_convs  # ###########################################del########################

        for i, module in enumerate(self.up_convs):
            del encoder_outs[-1]
            before_pool = encoder_outs[-1]
            before_attention = module(before_pool, before_attention)

        del encoder_outs

        seg = self.conv_final(before_attention)
        seg = torch.sigmoid(seg)
        # print(x.shape)
        return seg
