import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
import model_fcn as model
from torch.autograd import Variable
import med_dataset as med_dataset
from torchvision.utils import save_image
import datetime
import os
import numpy as np
import sys
import time
import argparse

# Device configuration
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
num_epochs = 100
batch_size = 4
learning_rate = 0.0003
log_path = '/mnt/DATA/tianbiao/yd2tianbiao_checkpoints'

if not os.path.exists(log_path):
    os.makedirs(log_path)

#格式化函数：设置时间文件夹
folder_name = "{0}_{1}_{2}_{3}_{4}".format('fcn',datetime.datetime.now().strftime("%Y-%m-%d_%H:%M:%S"),batch_size,num_epochs,learning_rate)
#格式转换
trans = transforms.ToTensor()

custom_dataset = med_dataset.med('./data/train/train',
                                './data/train/anno',
                                transform = trans)
train_dataset = torch.utils.data.DataLoader(dataset=custom_dataset,
                                            batch_size = batch_size,
                                            shuffle = True)

def denorm(x):
    out = (x + 1) / 2
    return out.clamp(0, 1)  #clamp，区间限定函数，返回的value介于0,1之间

def rewrite(x):
    y = (x > 0.5).astype('uint8')
    return y

def mergeout(x):
    ori_image = x.reshape(x.size(0),3,240,240)
    return ori_image

def mergepic(x):
    ori_image = x.reshape(x.size(0),1,240,240)
    return ori_image

net = model.FCN().to(device)
#net = nn.DataParallel(net, device_ids=[0, 1])
#net.load_state_dict(torch.load('./checkpoints/1_unet_MODEL.pth/1_unet_MODEL.pth', map_location='cuda:0'))
criterion = nn.MSELoss()
try:
    for epoch in range(num_epochs):
        optimizer = torch.optim.Adam(net.parameters(), lr=learning_rate)

        if epoch%3 == 1:
            learning_rate = learning_rate*0.9
            print(learning_rate)

        time00 = time.time()
        for i, (imagei,imagea) in enumerate(train_dataset):
            #x = x.to(device)
            #y = y.to(device)
            time0 = time.time()
            #imagei = imagei.type(torch.FloatTensor)
            imagei = imagei.to(device)
            #imagea = imagea.type(torch.FloatTensor)
            imagea = imagea.to(device)

            out = net(imagei)

            #创建文件夹保存运行结果
            if not os.path.exists(os.path.join(log_path,folder_name,'SEG_GT','epoch-{}'.format(epoch+1))):
                os.makedirs(os.path.join(log_path,folder_name,'SEG_GT','epoch-{}'.format(epoch+1)))
            if not os.path.exists(os.path.join(log_path,folder_name,'SEG_OUT','epoch-{}'.format(epoch+1))):
                os.makedirs(os.path.join(log_path,folder_name,'SEG_OUT','epoch-{}'.format(epoch+1)))

            oriout_images = mergeout(imagea)
            save_image(oriout_images, os.path.join(log_path,folder_name,'SEG_GT','epoch-{}'.format(epoch+1),'images-{}.png'.format(i+1)))
            out_images = mergeout(out)
            save_image(out_images,os.path.join(log_path,folder_name,'SEG_OUT','epoch-{}'.format(epoch+1),'image-{}.png'.format(i+1)))

            loss_s = criterion(out, imagea)
            loss = loss_s
            loss.backward()

            #优化
            optimizer.step()
            optimizer.zero_grad()

            time1 = time.time()
            timed = time1 - time0
            timea = time1 - time00
            #保存记录
            with open(os.path.join(log_path,folder_name,'Log.txt'), 'a') as log:
                log.write("Epoch: {}, iteration: {}\n".format(epoch+1, i+1))
                log.write("Loss: {}, time: {}, timea:{}\n".format(loss.item(), timed, timea))

            if i%5 == 0:
                time11 = time.time()
                timedd = time11-time00
                B = "Epoch[{}/{}],step[{}/{}],loss:{:.4f},time:{:.4f},timef:{:.4f}".format(epoch+1,num_epochs,i+1,len(train_dataset),loss.item(),timed,timedd)
                print(B)

        torch.save(net.state_dict(),os.path.join(log_path,folder_name,'{}_fcn_MODEL.pth'.format(epoch+1)))

except KeyboardInterrupt:
    torch.save(net.state_dict(),os.path.join(log_path,folder_name,'interrupt_fcn_MODEL.pth'.format(epoch+1)))
    print('Saved interrupt')
    try:
        sys.exit(0)
    except SystemExit:
        os._exit(0)
