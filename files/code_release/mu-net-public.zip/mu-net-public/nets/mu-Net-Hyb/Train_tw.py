import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
import model_wsl as model
from torch.autograd import Variable
import med_dataset_wsl
from torchvision.utils import save_image
import datetime
import os
import numpy as np
import sys
import time

from loss import BCEDiceLoss

import med_dataset#_wsl as med_dataset
from torchvision.utils import save_image
from PIL import Image
from pylab import *
import imageio

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
num_epochs = 2
batch_size = 4
bs = 1
log_path = './checkpoints'

for f in range(3,4):
    learning_rate = 0.0003
    a = 1
    b = 1
    c = 1
    d = 1
    e = 1
    #f = 1
    folder_name = "{0}_{1}_{2}_{3}_{4}{5}{6}{7}{8}{9}".format('tw',datetime.datetime.now().strftime("%Y-%m-%d_%H:%M:%S"),batch_size,learning_rate,a,b,c,d,e,f)
    #folder_name = './checkpoints/uaeshare_2020-11-12_10:50:26_2_0.0003_1211'
    #格式转换
    trans = transforms.ToTensor()

    custom_dataset = med_dataset_wsl.med('./data/train/train',
                                    './data/train/anno',
                                    transform = trans)
    train_dataset = torch.utils.data.DataLoader(dataset=custom_dataset,
                                                batch_size = batch_size,
                                                shuffle = True)#,
                                                #num_workers = 32)

    custom_dataset_val = med_dataset.med('./data/val/train',
                                    './data/val/anno',
                                    transform = trans)
    test_dataset = torch.utils.data.DataLoader(dataset=custom_dataset_val,
                                                batch_size = bs,
                                                shuffle = True)
                                
    def denorm(x):
        out = (x + 1) / 2
        return out.clamp(0, 1)  #clamp，区间限定函数，返回的value介于0,1之间

    def rewrite(x):
        y = (x > 0.5).astype('uint8')
        return y

    def mergeout(x):
        ori_image = x.reshape(x.size(0),3,240,240)
        return ori_image

    def mergepic(x):
        ori_image = x.reshape(x.size(0),1,240,240)
        return ori_image

    def test(pic1,pic2):
        picc1 = pic1#[0,:,:,:]
        picc2 = pic2#[0,:,:,:]
        if picc1.shape[2] == picc2.shape[2]:
            N = picc1.shape[2]

            picc1 = rewrite(picc1)
            picc2 = rewrite(picc2)

            picc1_flat = picc1.reshape(-1,N)
            picc1_flat = picc1_flat.T
            picc2_flat = picc2.reshape(-1,N)
            picc2_flat = picc2_flat.T

            intersection = picc1_flat * picc2_flat
            T = picc2_flat.sum(1)

            P = picc1_flat.sum(1)
            TP = intersection.sum(1)
            FP = P-TP
            FN = T-TP

            dice = ((2*TP) +1) / (T+P+1)
            dice_loss = 1 - dice.sum()/N

            ppv = (TP+1) / (TP+FP+1)
            ppv_loss = 1 - ppv.sum()/N

            sensitivity = (TP+1) / (TP+FN+1)
            sensitivity_loss = 1 - sensitivity.sum()/N

            iou = (TP+1) / (T+P-TP +1)
            iou_loss = 1 - iou.sum()/N

        else:
            print('size dont match')

        return dice,dice_loss,ppv,ppv_loss,sensitivity,sensitivity_loss,iou,iou_loss

    net = model.UNet(3, merge_mode='concat').to(device)
    #net = nn.DataParallel(net, device_ids=[0, 1])
    #net.load_state_dict(torch.load('./checkpoints/uaeshare_2020-11-12_10:50:26_2_0.0003_1211/15_wsl_MODEL.pth', map_location='cuda:0'))
    #criterionbce = nn.BCELoss()
    criterionbce = BCEDiceLoss()
    criterionmse = nn.MSELoss()

    # training
    try:
        for epoch in range(num_epochs):

            optimizer = torch.optim.Adam(net.parameters(), lr=learning_rate)
            if epoch%3 == 0:
                learning_rate = learning_rate*0.8
                #print(learning_rate)

            time00 = time.time()
            for i, (imagei,imagea,imageal) in enumerate(train_dataset):
                time0 = time.time()
                #imagei = imagei.type(torch.FloatTensor)
                imagei = imagei.to(device)
                #imagea = imagea.type(torch.FloatTensor)
                imagea = imagea.to(device)
                imageal = imageal.to(device)

                out, opic, ori_unet_outs, _ = net(imagei)
                segout, mask, seg_unet_outs, seg_ae_outs = net(imageal)

                #创建文件夹保存运行结果
                if not os.path.exists(os.path.join(log_path,folder_name,'SEG_GT','epoch-{}'.format(epoch+1))):
                    os.makedirs(os.path.join(log_path,folder_name,'SEG_GT','epoch-{}'.format(epoch+1)))
                if not os.path.exists(os.path.join(log_path,folder_name,'SEG_AE','epoch-{}'.format(epoch+1))):
                    os.makedirs(os.path.join(log_path,folder_name,'SEG_AE','epoch-{}'.format(epoch+1)))
                if not os.path.exists(os.path.join(log_path,folder_name,'SEG_OUT','epoch-{}'.format(epoch+1))):
                    os.makedirs(os.path.join(log_path,folder_name,'SEG_OUT','epoch-{}'.format(epoch+1)))
                if not os.path.exists(os.path.join(log_path,folder_name,'AE_GT','epoch-{}'.format(epoch+1))):
                    os.makedirs(os.path.join(log_path,folder_name,'AE_GT','epoch-{}'.format(epoch+1)))
                if not os.path.exists(os.path.join(log_path,folder_name,'AE_OUT','epoch-{}'.format(epoch+1))):
                    os.makedirs(os.path.join(log_path,folder_name,'AE_OUT','epoch-{}'.format(epoch+1)))
                if not os.path.exists(os.path.join(log_path,folder_name,'SEG_MASK','epoch-{}'.format(epoch+1))):
                    os.makedirs(os.path.join(log_path,folder_name,'SEG_MASK','epoch-{}'.format(epoch+1)))

                oriout_images = mergeout(imagea)
                save_image(oriout_images, os.path.join(log_path,folder_name,'SEG_GT','epoch-{}'.format(epoch+1),'images-{}.png'.format(i+1)))

                out_images = mergeout(out)
                save_image(out_images,os.path.join(log_path,folder_name,'SEG_OUT','epoch-{}'.format(epoch+1),'image-{}.png'.format(i+1)))

                seg_ae_images = mergeout(segout)
                save_image(seg_ae_images,os.path.join(log_path,folder_name,'SEG_AE','epoch-{}'.format(epoch+1),'image-{}.png'.format(i+1)))

                oripic_images = mergepic(imagei)
                save_image(oripic_images, os.path.join(log_path,folder_name,'AE_GT','epoch-{}'.format(epoch+1),'images-{}.png'.format(i+1)))

                o_images = mergepic(opic)
                save_image(o_images, os.path.join(log_path,folder_name,'AE_OUT','epoch-{}'.format(epoch+1),'images-{}.png'.format(i+1)))

                o_mask = mergepic(mask)
                save_image(o_mask, os.path.join(log_path,folder_name,'SEG_MASK','epoch-{}'.format(epoch+1),'images-{}.png'.format(i+1)))

                loss_image = criterionbce(out, imagea)
                loss_rei = criterionbce(opic, imagei)
                loss_rem = criterionbce(mask, imageal)
                loss_mask = criterionbce(segout, imagea)

                loss_i = []
                loss_s = []
                for ind in range(len(ori_unet_outs)-1):
                    lossi = criterionmse(ori_unet_outs[ind],seg_ae_outs[ind])
                    losss = criterionmse(ori_unet_outs[ind],seg_unet_outs[ind])
                    loss_i.append(lossi)
                    loss_s.append(losss)
                lossi = sum(loss_i)
                losss = sum(loss_s)

                loss = a*loss_rei + b*loss_rem + c*loss_image + d*loss_mask + e*lossi + f*losss
                loss.backward()

                #优化
                optimizer.step()
                optimizer.zero_grad()

                time1 = time.time()
                timed = time1 - time0
                timea = time1 - time00

                #保存记录
                if (i+1) == len(train_dataset):
                    with open(os.path.join(log_path,folder_name,'Log.txt'), 'a') as log:
                        log.write("Epoch: {}, iteration: {}, Loss:{:.4f}, Time:{:.4f} \n".format(epoch+1, i+1, loss.item(), timea))
                        log.write("Loss_rei: {:.2f},Loss_rem: {:.2f},Loss_image:{:.2f},Loss_mask:{:.2f},lossi:{:.2f},losss:{:.2f}\n".format(loss_rei.item(),loss_rem.item(),loss_image.item(), loss_mask.item(),lossi.item(),losss.item()))

                #输出Epoch、step、loss、time
                if i%8 == 0:
                    time11 = time.time()
                    timedd = time11-time00
                    B = "Epoch[{}/{}],step[{}/{}],Loss:{:.4f},Loss_rei: {:.2f},Loss_rem: {:.2f},Loss_image:{:.2f},Loss_mask:{:.2f},lossi:{:.2f},losss:{:.2f},timed:{:.4f},timedd:{:.4f}".format(epoch+1,num_epochs,i+1,len(train_dataset),loss.item(),loss_rei.item(),loss_rem.item(),loss_image.item(), loss_mask.item(),lossi.item(),losss.item(),timed,timedd)
                    print(B)
            torch.save(net.state_dict(),os.path.join(log_path,folder_name,'{}_wsl_MODEL.pth'.format(epoch+1)))

    except KeyboardInterrupt:
        torch.save(net.state_dict(),os.path.join(log_path,folder_name,'interrupt_wsl_MODEL.pth'.format(epoch+1)))
        print('Saved interrupt')
        try:
            sys.exit(0)
        except SystemExit:
            os._exit(0)

'''
    log_path_val = './Val/{}'.format(folder_name)
    #logg = log.split('/')[-1]
    #folder_name = "{0}_{1}_{2}".format(datetime.datetime.now().strftime("%Y-%m-%d_%H:%M:%S"),'wsl','20epoch')

    for b in range(1,num_epochs+1):
        pth_filepath = './checkpoints/{}/{}_wsl_MODEL.pth'.format(folder_name,b)
        folder_name_val = "{0}_{1}".format('tw','epoch_{}'.format(b))
        net.load_state_dict(torch.load(pth_filepath, map_location='cuda:1'))

        for i, (imagei,imagea) in enumerate(test_dataset):

            imagei = imagei.type(torch.FloatTensor)
            imagei = imagei.to(device)
            imagea = imagea.type(torch.FloatTensor)
            imagea = imagea.to(device)

            out,opic, _, _ = net(imagei)

            #创建文件夹保存运行结果
            if not os.path.exists(os.path.join(log_path_val,folder_name_val,'SEG_GT')):
                os.makedirs(os.path.join(log_path_val,folder_name_val,'SEG_GT'))
            if not os.path.exists(os.path.join(log_path_val,folder_name_val,'SEG_OUT')):
                os.makedirs(os.path.join(log_path_val,folder_name_val,'SEG_OUT'))
            #保存图像
            if not os.path.exists(os.path.join(log_path_val,folder_name_val,'AE_GT')):
                os.makedirs(os.path.join(log_path_val,folder_name_val,'AE_GT'))
            if not os.path.exists(os.path.join(log_path_val,folder_name_val,'AE_OUT')):
                os.makedirs(os.path.join(log_path_val,folder_name_val,'AE_OUT'))

            oriout_images = mergeout(imagea)
            save_image(oriout_images, os.path.join(log_path_val,folder_name_val,'SEG_GT','images-{}.png'.format(i+1)))

            out_images = mergeout(out)
            save_image(out_images,os.path.join(log_path_val,folder_name_val,'SEG_OUT','images-{}.png'.format(i+1)))

            oripic_images = mergepic(imagei)
            save_image(oripic_images, os.path.join(log_path_val,folder_name_val,'AE_GT','images-{}.png'.format(i+1)))

            o_images = mergepic(opic)
            save_image(o_images, os.path.join(log_path_val,folder_name_val,'AE_OUT','images-{}.png'.format(i+1)))

            if i%10 == 0:
                B = "Epoch[{}/{}],Step[{}/{}]".format(b,100,i+1,len(test_dataset))
                print(B)

        print('metric')
        root = os.path.join(log_path_val,folder_name_val)
        dir1 = os.path.join(root,'SEG_OUT')
        dir2 = os.path.join(root,'SEG_GT')

        dice_ = []
        ppv_ = []
        sensi_ = []
        iou_ = []
        dices_ = []
        ppvs_ = []
        sensis_ = []
        ious_ = []

        j = 0
        new = 0
        list = os.listdir(dir1)[:]

        for i in list:
            if i.endswith('.png'):
                path1 = os.path.join(dir1,i)
                path2 = os.path.join(dir2,i)

                pic1 = imageio.imread(path1)
                pic2 = imageio.imread(path2)
                dice_s,dice,ppv_s,ppv,sensi_s,sensi, iou_s,iou = test(pic1,pic2)

                dice_.append(dice)
                ppv_.append(ppv)
                sensi_.append(sensi)
                iou_.append(iou)
                dices_.append(dice_s)
                ppvs_.append(ppv_s)
                sensis_.append(sensi_s)
                ious_.append(iou_s)

                j += 1

                with open(os.path.join(root,'Log_metric.txt'), 'a') as log:
                    log.write("Step: {}\n".format(j))
                    log.write("Dice: {:.4f}, PPV:{:.4f}, Sensi:{:.4f}, IoU:{:.4f}\n".format((1-dice)*100,(1-ppv)*100,(1-sensi)*100,(1-iou)*100))

                if j%8 == 0:
                    dice_a = sum(dice_)/j
                    ppv_a = sum(ppv_)/j
                    sensi_a = sum(sensi_)/j
                    iou_a = sum(iou_)/j

                    B = "Epoch[{}/{}],Step[{}/{}],Dice:{:.4f},PPV:{:.4f},Sensi:{:.4f},IoU:{:.4f}\n".format(b,100,j,len(list),(1-dice_a)*100,(1-ppv_a)*100,(1-sensi_a)*100,(1-iou_a)*100)
                    print(B)
                    with open(os.path.join(root,'Log_metric.txt'), 'a') as log:
                        log.write(B)

                    if j == len(list):
                        Three = (1-dice_a)*100 + (1-ppv_a)*100 + (1-sensi_a)*100
                        Toal = Three + (1-iou_a)*100
                        if new < Toal:
                            new = Toal
                            with open(os.path.join(log_path_val,'metric.txt'), 'a') as log:
                                log.write("Best epoch:{}, metrics:{}".format(b, new))

                        C = "Epoch[{}/{}],Step[{}/{}],Dice:{:.4f},PPV:{:.4f},Sensi:{:.4f},IoU:{:.4f},Toal:{:.4f},Three:{:.4f}\n".format(b,100,j,len(list),(1-dice_a)*100,(1-ppv_a)*100,(1-sensi_a)*100,(1-iou_a)*100,Toal,Three)
                        print(C)
                        with open(os.path.join(log_path_val,'metric.txt'), 'a') as log:
                            log.write(C)

                np.save(os.path.join(root,'test_dice_list.npy'),dice_)
                np.save(os.path.join(root,'test_ppv_list.npy'),ppv_)
                np.save(os.path.join(root,'test_sensi_list.npy'),sensi_)
                np.save(os.path.join(root,'test_iou_list.npy'),iou_)
                np.save(os.path.join(root,'test_dice_array'),dices_)
                np.save(os.path.join(root,'test_ppv_array.npy'),ppvs_)
                np.save(os.path.join(root,'test_sensi_array.npy'),sensis_)
                np.save(os.path.join(root,'test_iou_array.npy'),ious_)
'''
