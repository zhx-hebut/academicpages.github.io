# Multi-Modal Contrastive Mutual Learning and Pseudo-Label Re-Learning for Semi-Supervised Medical Image Segmentation

This repository is the official implementation of MedIA paper [Multi-Modal Contrastive Mutual Learning and Pseudo-Label Re-Learning for Semi-Supervised Medical Image Segmentation](https://www.sciencedirect.com/science/article/pii/S1361841522002845?dgcid=author). 

## Usage
### Requirements

To install requirements:

```setup
pip install -r requirements.txt
```
### Datasets
To download datasets:
- [MICCAI 2020: HECKTOR](https://www.aicrowd.com/challenges/hecktor)
- [BraTS 2019](https://www.med.upenn.edu/cbica/brats-2019/)

### Training

To train the model, run this command:

```train
python train-semiCML.py
```

### Evaluation

To evaluate the model, run this command:
```eval
python predict.py 
```

## Citation

If Semi-CML is useful for your research, please consider citing:

    @article{zhang2022multi,
    title={Multi-modal contrastive mutual learning and pseudo-label re-learning for semi-supervised medical image segmentation},
    author={Zhang, Shuo and Zhang, Jiaojiao and Tian, Biao and Lukasiewicz, Thomas and Xu, Zhenghua},
    journal={Medical Image Analysis},
    pages={102656},
    year={2022},
    publisher={Elsevier}
    }


 If you have some issues, please contact szhang5566@gmail.com