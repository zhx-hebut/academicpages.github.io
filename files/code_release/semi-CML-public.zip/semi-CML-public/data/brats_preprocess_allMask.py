import os
import pandas as pd
import numpy as np
import SimpleITK as sitk
from PIL import Image
import skimage.io as io
import warnings
warnings.filterwarnings("ignore")
flair_name = "_flair.nii.gz"
t1_name = "_t1.nii.gz"
t1ce_name = "_t1ce.nii.gz"
t2_name = "_t2.nii.gz"
mask_name = "_seg.nii.gz"

root_dir = "./BraTs_2019/BraTS2019_Training/HGG/"
out_root = "./data/BraTS_slice/"
outputFlair_path  = out_root + "imgs_flair"
outputT1_path  = out_root + "imgs_t1"
outputT2_path  = out_root + "imgs_t2"
outputT1ce_path  = out_root + "imgs_t1ce"
outputMaskWT_path = out_root + "masks"
outputMaskAll_path = out_root + "masks_all"
if not os.path.exists(outputFlair_path):
    os.makedirs(outputFlair_path)
if not os.path.exists(outputT1_path):
    os.makedirs(outputT1_path)
if not os.path.exists(outputT2_path):
    os.makedirs(outputT2_path)
if not os.path.exists(outputT1ce_path):
    os.makedirs(outputT1ce_path)
if not os.path.exists(outputMaskWT_path):
    os.makedirs(outputMaskWT_path)
if not os.path.exists(outputMaskAll_path):
    os.makedirs(outputMaskAll_path)

train_hgg_path = './BraTS_2019/BraTS2019_Training/HGG'
# train_lgg_path = './BraTs_2019/BraTS2019_Training/LGG'

def file_name_path(file_dir):
    """
    get root path,sub_dirs,all_sub_files
    :param file_dir:
    :return: dir or file
    """
    path_list = []
    name_list = []
    for root, dirs, files in os.walk(file_dir):
        if len(dirs) and dir:
            name_list = dirs
        for f in files:
            path = os.path.join(root,f)
            path_list.append(path)
    return name_list,path_list
train_hgg_list,train_hgg_path_list = file_name_path(root_dir)
# train_lgg_list,train_lgg_path_list = file_name_path(train_lgg_path)
# val_list,val_path_list = file_name_path(val_path)

print("train_hgg_list:",len(train_hgg_list),train_hgg_list,'\n')        


all_list = train_hgg_list
print("\n all_list:",len(all_list),all_list)

def resize_img(data):
    img = Image.fromarray(data)
#     print(img.size)
    img_res = img.resize((144, 144), Image.NEAREST)
    img_np = np.array(img_res)
    return img_np
def show_max_min(img_data):
    min = np.min(img_data)
    max = np.max(img_data)
    print('min is {}'.format(min))
    print('max is {}'.format(max))
    print('dtype is {}'.format(img_data.dtype))
def show_info(np_data=[],name="nparry"):
#     print("{} 's shape is {}".format(name,np_data.shape))
#     print('{} dtype is {}'.format(name,np_data.dtype))
    min_v = np.min(np_data)
    max_v = np.max(np_data)
    print('{} min value is {:.4f}'.format(name,min_v))
    print('{} max value is {:.4f}'.format(name,max_v))
def normalize(slice):

    b = np.percentile(slice, 99)
    t = np.percentile(slice, 1)
    slice = np.clip(slice, t, b)
    
    image_nonzero = slice[np.nonzero(slice)]
    if np.std(slice) == 0 or np.std(image_nonzero) == 0:
        return slice
    else:
        tmp = (slice - np.mean(image_nonzero)) / np.std(image_nonzero)
        return tmp
def move(mask, croph):
    probe = 0
    height,width = mask[0].shape   
    for probe in range (height//2-(croph//2)):
        bottom = height//2 + (croph//2) + probe
        if np.max(mask[:, bottom, :]) == 0:
            break;
    if probe == 0:
        for probe in range(height//2-(croph//2)):
            up = height//2 - (croph//2) - probe
            if np.max(mask[:, up, :]) == 0 or np.max(mask[:, up+croph, :]) == 1:
                probe = 0-probe
                break;
#     print("probe: ",probe)
    return probe
def crop_ceter(img,croph,cropw,move_value=0):   
    #for n_slice in range(img.shape[0]):
    height,width = img[0].shape      
    starth = height//2-(croph//2) + move_value
    startw = width//2-(cropw//2)        
    return img[:,starth:starth+croph,startw:startw+cropw]


# print(all_list)
for subsetindex in range(len(all_list)):
#     if subsetindex == 1:
#         break
    flair_image = root_dir + all_list[subsetindex] + '/' + all_list[subsetindex] + flair_name
    t1_image = root_dir + all_list[subsetindex] + '/' + all_list[subsetindex] + t1_name
    t2_image = root_dir + all_list[subsetindex] + '/' + all_list[subsetindex] + t2_name
    t1ce_image = root_dir + all_list[subsetindex] + '/' + all_list[subsetindex] + t1ce_name
    mask_image = root_dir + all_list[subsetindex] + '/' + all_list[subsetindex] + mask_name
    print(subsetindex)
#     print(Mask_path)

    flair_src = sitk.ReadImage(flair_image, sitk.sitkInt16)
    t1_src = sitk.ReadImage(t1_image, sitk.sitkInt16)
    t1ce_src = sitk.ReadImage(t1ce_image, sitk.sitkInt16)
    t2_src = sitk.ReadImage(t2_image, sitk.sitkInt16)
    mask = sitk.ReadImage(mask_image, sitk.sitkUInt8)
    flair_array = sitk.GetArrayFromImage(flair_src)
    t1_array = sitk.GetArrayFromImage(t1_src)
    t1ce_array = sitk.GetArrayFromImage(t1ce_src)
    t2_array = sitk.GetArrayFromImage(t2_src)
    mask_array = sitk.GetArrayFromImage(mask)
    
    # 3. normalization
#     show_info(np_data=flair_array,name="flair no nor")
    flair_array_nor = normalize(flair_array)
#     show_info(np_data=flair_array_nor,name="flair nor")
#     show_info(np_data=t1_array,name="t1 no nor")
    t1_array_nor = normalize(t1_array)
#     show_info(np_data=t1_array_nor,name="t1 nor")
#     show_info(np_data=t1ce_array,name="t1ce no nor")
    t1ce_array_nor = normalize(t1ce_array)
#     show_info(np_data=t1ce_array_nor,name="t1ce nor")
#     show_info(np_data=t2_array,name="t2 no nor")
    t2_array_nor = normalize(t2_array)
#     show_info(np_data=t2_array_nor,name="t2 nor")

    # 4. cropping
    move_value = move(mask_array, 160)
    will_up = False
    if move_value != 0 :
        print((all_list[subsetindex]))
        print("move value: ", move_value)
        will_up = True
    flair_crop = crop_ceter(flair_array_nor,160,160, move_value)
    t1_crop = crop_ceter(t1_array_nor,160,160, move_value)
    t1ce_crop = crop_ceter(t1ce_array_nor,160,160, move_value)
    t2_crop = crop_ceter(t2_array_nor,160,160, move_value)
    mask_crop = crop_ceter(mask_array,160,160, move_value) 
    
    n_sum = 0
    for n_slice in range(mask_crop.shape[0]):
#         print(n_slice)
        
        mask_np = mask_crop[n_slice,:,:]
#         print("*"*20)
#         print("mask np",mask_np.shape)
#         show_max_min(mask_np)
        mask_np_wt = mask_np.copy()
        mask_np_all = mask_np.copy()
        all_label3 = np.empty((3,160, 160),np.uint8)
        if np.max(mask_np) != 0:
            # for one class
            mask_np_wt[mask_np_wt>1] = 1
            # for three classes
            WT_Label = mask_np_all.copy()
            WT_Label[mask_np_all == 1] = 1.
            WT_Label[mask_np_all == 2] = 1.
            WT_Label[mask_np_all == 4] = 1.
            TC_Label = mask_np_all.copy()
            TC_Label[mask_np_all == 1] = 1.
            TC_Label[mask_np_all == 2] = 0.
            TC_Label[mask_np_all == 4] = 1.
            ET_Label = mask_np_all.copy()
            ET_Label[mask_np_all == 1] = 0.
            ET_Label[mask_np_all == 2] = 0.
            ET_Label[mask_np_all == 4] = 1.
            all_label3[0,:, :] = WT_Label
            all_label3[1,:, :] = TC_Label
            all_label3[2,:, :] = ET_Label
            # true_mask_all = all_label3.transpose((2, 0, 1))
        else:
            all_label3[0,:, :] = mask_np_all
            all_label3[1,:, :] = mask_np_all
            all_label3[2,:, :] = mask_np_all

        
        #flair
        flair_np = flair_crop[n_slice,:,:]        
        flair_np = flair_np.astype(np.float32)
#         print("*"*20)
#         print("flair np",flair_np.shape)
#         show_max_min(flair_np)

        #t1
        t1_np = t1_crop[n_slice,:,:]
        t1_np = t1_np.astype(np.float32)
#         print("*"*20)
#         print("t1 np",t1_np.shape)
#         show_max_min(t1_np)
    
        #t2
        t2_np = t2_crop[n_slice,:,:]
        t2_np = t2_np.astype(np.float32)
#         print("*"*20)
#         print("t2 np",t2_np.shape)
#         show_max_min(t2_np)
   
        #t1ce
        t1ce_np = t1ce_crop[n_slice,:,:]
        t1ce_np = t1ce_np.astype(np.float32)
#         print("*"*20)
#         print("t1ce np",t1ce_np.shape)
#         show_max_min(t1ce_np)
        
        slice_num = n_slice + 1
        if len(str(slice_num)) == 1:
            new_slice_num = '00' + str(slice_num)
        elif len(str(slice_num)) == 2:
            new_slice_num = '0' + str(slice_num)
        else:
            new_slice_num = str(slice_num)
#         print(new_slice_num)

        flair_imagepath = outputFlair_path + "/" + (all_list[subsetindex])  + "_" + str(new_slice_num) + ".npy"
        t1_imagepath = outputT1_path + "/" + (all_list[subsetindex])  + "_" + str(new_slice_num) + ".npy"
        t2_imagepath = outputT2_path + "/" + (all_list[subsetindex])  + "_" + str(new_slice_num) + ".npy"
        t1ce_imagepath = outputT1ce_path + "/" + (all_list[subsetindex])  + "_" + str(new_slice_num) + ".npy"
        maskpath_wt = outputMaskWT_path + "/" + (all_list[subsetindex])  + "_" + str(new_slice_num) + ".npy"
        maskpath_all = outputMaskAll_path + "/" + (all_list[subsetindex])  + "_" + str(new_slice_num) + ".npy"

        np.save(flair_imagepath, flair_np)
        np.save(t1_imagepath, t1_np)
        np.save(t2_imagepath, t2_np)
        np.save(t1ce_imagepath, t1ce_np)
        np.save(maskpath_wt, mask_np_wt)
        np.save(maskpath_all, all_label3)
        
#         flair_imagepath = outputFlair_path + "/" + (all_list[subsetindex])  + "_" + str(new_slice_num) + ".png"
#         t1_imagepath = outputT1_path + "/" + (all_list[subsetindex])  + "_" + str(new_slice_num) + ".png"
#         t2_imagepath = outputT2_path + "/" + (all_list[subsetindex])  + "_" + str(new_slice_num) + ".png"
#         t1ce_imagepath = outputT1ce_path + "/" + (all_list[subsetindex])  + "_" + str(new_slice_num) + ".png"
#         maskpath_wt = outputMaskWT_path + "/" + (all_list[subsetindex])  + "_" + str(new_slice_num) + ".png"
#         maskpath_all = outputMaskAll_path + "/" + (all_list[subsetindex])  + "_" + str(new_slice_num) + ".png"
#         if will_up : 
#             io.imsave(flair_imagepath, flair_np)
#             io.imsave(t1_imagepath, t1_np)
#             io.imsave(t2_imagepath, t2_np)
#             io.imsave(t1ce_imagepath, t1ce_np)
#             io.imsave(maskpath_wt, mask_np_wt)
#             io.imsave(maskpath_all, true_mask_3c)

print("Done！")