import os
import pandas as pd
import numpy as np
import SimpleITK as sitk
from PIL import Image
import skimage.io as io
import warnings
warnings.filterwarnings("ignore")
ct_name = "ct.nii.gz"
pt_name = "pt.nii.gz"
mask_name = "ct_gtvt.nii.gz"
root_dir = "hecktor_resampled/"

outputCt_path   = "./data/slice_all/imgs_ct"
outputPet_path  = "./data/slice_all/imgs_pet"
outputMask_path = "./data/slice_all/masks"
if not os.path.exists(outputCt_path):
    os.mkdir(outputCt_path)
if not os.path.exists(outputPet_path):
    os.mkdir(outputPet_path)
if not os.path.exists(outputMask_path):
    os.mkdir(outputMask_path)
df = pd.read_csv('dataset_split.csv', header=None)
print(df.shape)
# print(df[1]=="inference")
patient_id = df.to_dict(orient='list')[0]
tranin_infer = df.to_dict(orient='list')[1]
train_list = []
inference_list = []

for i in range(len(tranin_infer)):
    if tranin_infer[i] == 'inference':
        inference_list.append(patient_id[i])
    else:
        train_list.append(patient_id[i])
print("train_list:",train_list,len(train_list))        
print("\n inference_list:",inference_list,len(inference_list))
all_list = patient_id
print("\n all_list:",all_list,len(all_list))

def transform_PETdata(image):
    min_hu = np.min(image)
    max_hu = np.max(image)
    
    newimg = (image - min_hu) * (255/(max_hu-min_hu))
    newimg[newimg < 0] = 0
    newimg[newimg > 255] = 255
    newimg = newimg.astype('uint8')
    return newimg
def transform_ctdata(image, windowWidth, windowCenter, normal=False):
    minWindow = float(windowCenter) - 0.5*float(windowWidth)
    newimg = (image - minWindow) / float(windowWidth)
    newimg[newimg < 0] = 0
    newimg[newimg > 1] = 1
    if not normal:
        newimg = (newimg * 255).astype('uint8')
    return newimg

def resize_img(data):
    img = Image.fromarray(data)
#     print(img.size)
    img_res = img.resize((144, 144), Image.NEAREST)
    img_np = np.array(img_res)
    return img_np
def show_max_min(img_data):
    min = np.min(img_data)
    max = np.max(img_data)
    print('min is {}'.format(min))
    print('max is {}'.format(max))
    print('dtype is {}'.format(img_data.dtype))


# print(all_list)
for subsetindex in range(len(all_list)):
#     if subsetindex == 1:
#         break
    ct_path = root_dir + (all_list[subsetindex]) + ct_name
    pet_path = root_dir + (all_list[subsetindex]) + pt_name
    mask_path = root_dir + (all_list[subsetindex]) + mask_name
    
    ct_image = sitk.ReadImage(ct_path)
    pet_image = sitk.ReadImage(pet_path)
    mask = sitk.ReadImage(mask_path,sitk.sitkUInt8)

    ct_array = sitk.GetArrayFromImage(ct_image)
    pet_array = sitk.GetArrayFromImage(pet_image)
    mask_array = sitk.GetArrayFromImage(mask)

    """ window_center=0,window_width=300,Hu:[-150,150] """
    windowCenter = 0
    windowWidth  = 300
    ct_array_nor = transform_ctdata(ct_array, windowWidth, windowCenter, normal=True)
    pet_array_nor = transform_PETdata(pet_array)

    pet_array_nor = (pet_array_nor - pet_array_nor.min()) / (pet_array_nor.max() - pet_array_nor.min())
    # resize (144,144,144)
    print((all_list[subsetindex]))
    
    for n_slice in range(mask_array.shape[0]):
#         print(n_slice)
        mask_np = mask_array[n_slice,:,:]
        if mask_np.shape != (144,144):
            mask_np = resize_img(mask_np)
#             mask_np = mask_np.astype(np.uint8)
#             mask_np[mask_np == 1] = 255
        # print("mask np",mask_np.shape)
        # show_max_min(mask_np)

        #pet
        pet_np = pet_array_nor[n_slice,:,:]
        if pet_np.shape != (144,144):
            pet_np = resize_img(pet_np)
        # print("pet np",pet_np.shape)
        # show_max_min(pet_np)
#             pet_np = pet_np.astype(np.uint8)

        #ct
        ct_np = ct_array_nor[n_slice,:,:]
        if ct_np.shape != (144,144):
            ct_np = resize_img(ct_np)
        # print("ct np",ct_np.shape)
        # show_max_min(ct_np)
#             ct_np = ct_np.astype(np.uint8)
        slice_num = n_slice + 1
        if len(str(slice_num)) == 1:
            new_slice_num = '00' + str(slice_num)
        elif len(str(slice_num)) == 2:
            new_slice_num = '0' + str(slice_num)
        else:
            new_slice_num = str(slice_num)
#         print(new_slice_num)
        ct_imagepath = outputCt_path + "/" + (all_list[subsetindex])  + "slice_" + str(new_slice_num) + ".npy"
        pet_imagepath = outputPet_path + "/" + (all_list[subsetindex])  + "slice_" + str(new_slice_num) + ".npy"
        maskpath = outputMask_path + "/" + (all_list[subsetindex])  + "slice_" + str(new_slice_num) + ".npy"
        # print(ct_imagepath)
        # print(pet_imagepath)
        # print(maskpath)
        np.save(ct_imagepath, ct_np)
        np.save(pet_imagepath, pet_np)
        np.save(maskpath, mask_np)

print("Done！")