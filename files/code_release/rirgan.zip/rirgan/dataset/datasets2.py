import glob
import random
import os
from matplotlib import image
import numpy as np
from PIL import Image
import cv2
from skimage import util

import torch
from torch.utils.data import Dataset
import torchvision.transforms as transforms
from torchvision.transforms.transforms import CenterCrop

# Normalization parameters for pre-trained PyTorch models归一化参数以预训练pytorch模型
mean = np.array([0.485, 0.485, 0.485])
std = np.array([0.370, 0.370, 0.370])


class ImageDataset(Dataset):
    def __init__(self, root, hr_shape):
        hr_height, hr_width = hr_shape#获得图像的尺寸，高和宽
        # Transforms for low resolution images and high resolution images低分辨率图像和高分辨率图像的变换
        #获得低分辨率的图像
        self.lr_transform = transforms.Compose(
            [
                transforms.CenterCrop(96),
                transforms.Resize((hr_height // 4, hr_width // 4
                ), Image.BICUBIC),#进行图像放大，并插值，降低分辨率
                transforms.ToTensor(),
                transforms.Normalize(mean, std)
            ]
        )
        #获得高分辨率的图像
        self.hr_transform = transforms.Compose(
            [
                transforms.CenterCrop(96),
                transforms.Resize((hr_height, hr_width), Image.BICUBIC),
                transforms.ToTensor(),
                transforms.Normalize(mean, std)#归一化
            ]
        
        )

        self.files = sorted(glob.glob(root + "/*.*"))
    


    def __getitem__(self, index):
        img = Image.open(self.files[index % len(self.files)]).convert('RGB')
        img_lr = self.lr_transform(img)
        img_hr = self.hr_transform(img)
        img_lr_noise= util.random_noise(img_lr,mode='gaussian')
        #img_lr_noise2 = util.random_noise(img_lr_noise,mode='s&p')
        #print(img_lr_noise)
        #im.save("images/input/%d.png")


        return {"lr": img_lr,"lr_noise":img_lr_noise, "hr": img_hr}

    def __len__(self):
        return len(self.files)

#im.save()
#im.show()