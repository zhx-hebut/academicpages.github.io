# RIRGAN: AN end-to-end lightweight multi-task learning method for brain MRI super-resolution and denoising

This repository is the official implementation of CIMB paper [RIRGAN: AN end-to-end lightweight multi-task learning method for brain MRI super-resolution and denoising](https://www.sciencedirect.com/science/article/pii/S0010482523010971?dgcid=author). 


##The SRResNet in our experiments is the model that SRGAN with out using discriminator.
## Citation

If RIRGAN is useful for your research, please consider citing:
	
	@article{rirgan,
  	title={RIRGAN: AN end-to-end lightweight multi-task learning method for brain MRI super-resolution and denoising},
  	author={Miao，Yu and Miaomiao，Guo and Shuai, Zhang and Yuefu, Zhan and Mingkang, Zhao and Lukasiewicz, Thomas, Zhenghua, Xu},
 	 journal={Computers in Biology and Medicine},
  	pages={107632},
  	year={2023},
  	publisher={Elsevier}
	}
  

 If you have some issues, please contact yumiao.1@qq.com