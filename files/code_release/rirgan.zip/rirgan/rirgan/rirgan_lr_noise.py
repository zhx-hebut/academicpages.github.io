# -*- coding: utf-8 -*-
import argparse
import os
import PIL
import numpy as np
import math
import itertools
import sys
from PIL import Image
import torchvision.transforms as transforms
from torchvision.utils import save_image, make_grid
from tqdm import tqdm #进度条
from torch.utils.data import DataLoader
from torch.autograd import Variable

from models2 import *
from datasets2 import *
from psnr_ssim import *
import time
import torch.nn as nn
import torch.nn.functional as F
import torch
import torchvision.transforms as transforms
#import cv

#from tensorboardX import SummaryWriter
import matplotlib.pyplot as plt
start = time.clock()
os.makedirs("images", exist_ok=True)
os.makedirs("saved_models", exist_ok=True)

parser = argparse.ArgumentParser()
parser.add_argument("--epoch", type=int, default=0, help="epoch to start training from")
parser.add_argument("--n_epochs", type=int, default=120, help="number of epochs of training")#默认值为200
parser.add_argument("--dataset_name", type=str, default="img_3C", help="name of the dataset")
parser.add_argument("--batch_size", type=int, default=16, help="size of the batches")
parser.add_argument("--lrg", type=float, default=1e-4, help="adam: learning rate")#auto decay of G
parser.add_argument("--lrd", type=float, default=1e-6, help="adam: learning rate")#auto decay of D
parser.add_argument("--b1", type=float, default=0.5, help="adam: decay of first order momentum of gradient")#momentum
parser.add_argument("--b2", type=float, default=0.999, help="adam: decay of first order momentum of gradient")
parser.add_argument("--decay_epoch", type=int, default=50, help="epoch from which to start lr decay")#默认值为100
parser.add_argument("--n_cpu", type=int, default=8, help="number of cpu threads to use during batch generation")
parser.add_argument("--hr_height", type=int, default=256, help="high res. image height")
parser.add_argument("--hr_width", type=int, default=256, help="high res. image width")
parser.add_argument("--channels", type=int, default=3, help="number of image channels")
parser.add_argument("--sample_interval", type=int, default=4000, help="interval between saving image samples")
parser.add_argument("--checkpoint_interval", type=int, default=1000, help="interval between model checkpoints")
parser.add_argument("--warmup_batches", type=int, default=500, help="number of batch")
parser.add_argument("--lambda_pixel", type=float, default=1e-2, help="pixel-wise loss weight")
opt = parser.parse_args()
print(opt)
torch.cuda.empty_cache()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
if __name__ == '__main__':

    cuda = torch.cuda.is_available()

    hr_shape = (opt.hr_height, opt.hr_width)
    # Initialize generator and discriminator初始化生成器和鉴别器
    generator = GeneratorRIRNet()
    print('# generator parameters:', sum(param.numel() for param in generator.parameters()))
    discriminator = Discriminator(input_shape=(opt.channels, *hr_shape))
    print('# discriminator parameters:', sum(param.numel() for param in discriminator.parameters()))
    feature_extractor = FeatureExtractor()

    # Set feature extractor to inference mode将特征提取器设置为推断模式
    feature_extractor.eval()

    # Losses损失
    criterion_GAN = torch.nn.BCEWithLogitsLoss()
    #criterion_GAN = torch.nn.MSELoss()
    criterion_content = torch.nn.L1Loss()
    criterion_pixel = torch.nn.L1Loss()
    criterion_tv = TVLoss()

    if cuda:
        generator = generator.cuda()
        discriminator = discriminator.cuda()
        feature_extractor = feature_extractor.cuda()
        criterion_GAN = criterion_GAN.cuda()
        criterion_content = criterion_content.cuda()
        criterion_tv = criterion_tv.cuda()
    if opt.epoch != 0:
        # Load pretrained models加载预训练模型
        generator(torch.load("./saved_models/CIBM/10/rirg_%d.pth"%opt.epoch))
        discriminator(torch.load("./saved_models/CIBM/10/rirD_%d.pth"%opt.epoch))

    # Optimizers优化器
    optimizer_G = torch.optim.Adam(generator.parameters(), lr=opt.lrg, betas=(opt.b1, opt.b2))
    optimizer_D = torch.optim.Adam(discriminator.parameters(), lr=opt.lrd, betas=(opt.b1, opt.b2))

    Tensor = torch.cuda.FloatTensor if cuda else torch.Tensor
   
    dataloader = DataLoader(
        ImageDataset("../../data/%s" % opt.dataset_name, hr_shape=hr_shape),
        batch_size=opt.batch_size,
        shuffle=True,
        num_workers=opt.n_cpu
        )

        
    for epoch in range(opt.epoch, opt.n_epochs):
        for i, imgs in enumerate(dataloader):
            
            # Configure model input
            imgs_lr = Variable(imgs["lr"].type(Tensor))
            imgs_lr_noise = Variable(imgs["lr_noise"].type(Tensor))
            imgs_hr = Variable(imgs["hr"].type(Tensor))

            # Adversarial ground truths
            #valid_lr = Variable(Tensor(np.ones((imgs_lr.size(0), *discriminator.output_shape))), requires_grad=False)
            valid = Variable(Tensor(np.ones((imgs_lr_noise.size(0), *discriminator.output_shape))), requires_grad=False)
            #fake_lr = Variable(Tensor(np.zeros((imgs_lr.size(0), *discriminator.output_shape))), requires_grad=False)
            fake = Variable(Tensor(np.zeros((imgs_lr_noise.size(0), *discriminator.output_shape))), requires_grad=False)

            # ------------------
            
            #  Train Generator  训练生成器
            # ------------------

            optimizer_G.zero_grad()

           # Generate a high resolution image from low resolution input
            gen_hr = generator(imgs_lr_noise)
            pred_real =discriminator(imgs_hr).detach()
            pred_fake = discriminator(gen_hr)
            # Adversarial loss(RaD GAN)
            #loss_GAN = criterion_GAN(discriminator(gen_hr), valid)
            loss_GAN = criterion_GAN(pred_fake-pred_real.mean(0,keepdim=True),valid)
            # Content loss
            gen_features = feature_extractor(gen_hr)
            real_features = feature_extractor(imgs_hr).detach()
            loss_content = criterion_content(gen_features, real_features)

            # Pixel loss
            loss_pixel = criterion_pixel(gen_hr,imgs_hr)

            # Total Validation Loss
            loss_tv = criterion_tv(gen_hr)

            # Total loss
            loss_G = 1*loss_content + 5e-3 * loss_GAN+0.006*loss_pixel+2e-9*loss_tv
            #loss_G = loss_content+1e-3*loss_GAN
            loss_G.backward()
            optimizer_G.step()

            # ---------------------
            #  Train Discriminator
            # ---------------------

            optimizer_D.zero_grad()
            pred_real =discriminator(imgs_hr)
            pred_fake = discriminator(gen_hr.detach())
            #adversarial loss for real and fake images (RaD)
            loss_real=criterion_GAN(pred_real-pred_fake.mean(0,keepdim=True),valid)
            loss_fake=criterion_GAN(pred_fake-pred_real.mean(0,keepdim=True),fake)


            '''# Loss of real and fake images
            loss_real = criterion_GAN(discriminator(imgs_hr), valid)
            loss_fake = criterion_GAN(discriminator(gen_hr.detach()), fake)'''
            
            # Total loss
            loss_D = (loss_real + loss_fake) / 2
            loss_D.backward()
            optimizer_D.step()#return sitk.GetA
            #把训练结果输出到result.txt中，按字节为数去取数字结果
            list_psnr = []
            list_ssim = []
            
            fakes=gen_hr.cpu().detach().numpy()
            targets=imgs_hr.cpu().detach().numpy()
            #gen=convert_rgb_to_y(denormalize(gen_hr.cpu()))
            #gt = convert_rgb_to_y(denormalize(imgs_hr.cpu()))
            #list_mse =[]
            #for j in range(0,len(dataloader)):
            psnr_num = psnr(fakes,targets)
            ssim_num = ssim(fakes,targets)
            list_ssim.append(ssim_num)
            list_psnr.append(psnr_num)
                ###file.write('ssim_num,{:.5f}'.format(ssim_num)+'\n')

            #print("PSNR:",np.mean(list_psnr))
            #print("SSIM:",np.mean(list_ssim))
            #elapsed = (time.clock()-start)
            #print("Time used:",elapsed)
            

            #list_mse.append(mse_num)

            # --------------
            #  Log Progress
            # --------------

            sys.stdout.write(
                "[Epoch %d/%d] [Batch %d/%d] [D loss: %f] [G loss:%8f,content:%f,adv:%f,pixel:%f,TV:%f]"
                % (epoch, opt.n_epochs, i, len(dataloader), loss_D.item(), loss_G.item(),loss_content.item(),loss_GAN.item(),loss_pixel.item(),loss_tv.item())
            )
            '''
            sys.stdout.write(
                "[Epoch %d/%d] [Batch %d/%d] "
                % (epoch, opt.n_epochs, i, len(dataloader))
            )'''
            #print("mean MSE:",np.mean(list_mse))
          

            batches_done = epoch * len(dataloader) + i
            if batches_done % opt.sample_interval == 0:
                # Save image grid with upsampled inputs and SRGAN outputs
                #imgs_hr = nn.functional.interpolate(imgs_lr, scale_factor=4)

                gen_hr = make_grid(gen_hr, nrow=1, normalize=True)
                imgs_hr = make_grid(imgs_hr, nrow=1, normalize=True)
                img_grid = torch.cat((imgs_hr, gen_hr), -1)
                save_image(img_grid, "images/training/%d.png" % batches_done, normalize=False)  

                print("mean PSNR:",np.mean(list_psnr))
                print("mean SSIM:",np.mean(list_ssim))
    
                #imgs_lr_noise = make_grid(imgs_lr_noise,nrow=1,normalize=True)
                #save_image(imgs_lr_noise, "images/input_s&p/%d.png" % batches_done, normalize=False) 


            if epoch!=opt.n_epochs+1:
                # Save model checkpoints
                torch.save(generator, "saved_models/CIBM/10/rirg_%d.pth" % epoch)
                torch.save(discriminator, "saved_models/CIBM/10/rirD_%d.pth" % epoch)



#迭代多少次，新的取值范围就是多少

            #optimizer.zero_grad()

#    return 1

#if __name__ == '__main__':
  #  main()