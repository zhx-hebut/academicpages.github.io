from typing import Any
import torch.nn as nn
import torch.nn.functional as F
import torch
from torchvision.models import vgg19
from torch.nn.utils import spectral_norm
import math
#from basicsr.utils.registry import ARCH_REGISTRY
#定义特征提取
class FeatureExtractor(nn.Module):
    def __init__(self):
        super(FeatureExtractor, self).__init__()
        vgg19_model = vgg19(pretrained=True)
        self.vgg19_54 = nn.Sequential(*list(vgg19_model.features.children())[:35])

    def forward(self, img):
        return self.vgg19_54(img)
#定义残差块
class ResidualBlock(nn.Module):
    def __init__(self, in_features):
        super(ResidualBlock, self).__init__()
        self.conv_block = nn.Sequential(
            nn.Conv2d(in_features, in_features, kernel_size=3, stride=1, padding=1),
            nn.PReLU(),
            nn.Conv2d(in_features, in_features, kernel_size=3, stride=1, padding=1),
        )

    def forward(self, x):
        return x + self.conv_block(x)


#定义残差块
class ResidualBlock2(nn.Module):
    def __init__(self, in_features):
        super(ResidualBlock2, self).__init__()
        self.conv_block = nn.Sequential(
            nn.Conv2d(in_features, in_features, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(in_features, 0.8),
            nn.PReLU(),
            nn.Conv2d(in_features, in_features, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(in_features, 0.8),
        )

    def forward(self, x):
        return x + self.conv_block(x)

#定义生成器
class GeneratorResNet(nn.Module):
    def __init__(self, in_channels=3, out_channels=3, n_residual_blocks=8):
        super(GeneratorResNet, self).__init__()

        # First layer
        self.conv1 = nn.Sequential(nn.Conv2d(in_channels, 64, kernel_size=9, stride=1, padding=4), nn.PReLU())

        # Residual blocks
        res_blocks = []
        for _ in range(n_residual_blocks):
            res_blocks.append(ResidualBlock2(64))
        self.res_blocks = nn.Sequential(*res_blocks)


        # Second conv layer post residual blocks
        self.conv2 = nn.Sequential(nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1), nn.BatchNorm2d(64, 0.8))

        # Upsampling layers
        upsampling = []
        for out_features in range(2):
            upsampling += [
                # nn.Upsample(scale_factor=2),
                nn.Conv2d(64, 256, 3, 1, 1),
                nn.BatchNorm2d(256),
                nn.PixelShuffle(upscale_factor=2),
                nn.PReLU(),
            ]
        self.upsampling = nn.Sequential(*upsampling)

        # Final output layer
        self.conv3 = nn.Sequential(nn.Conv2d(64, out_channels, kernel_size=9, stride=1, padding=4), nn.Tanh())

    def forward(self, x):
        out1 = self.conv1(x)
        out = self.res_blocks(out1)
        out2 = self.conv2(out)
        out = torch.add(out1, out2)
        out = self.upsampling(out)
        out = self.conv3(out)
        return out



class RIRBlock(nn.Module):
    def __init__(self):
      super(RIRBlock,self).__init__()
      self.residual_group()

    def residual_group(self):
      self.block2 = ResidualBlock(64)
      self.block3 = ResidualBlock(64)
      self.block4 = ResidualBlock(64)
      self.block5 = ResidualBlock(64)
      self.block6 = ResidualBlock(64)
      
    def forward(self,x):
      out1=self.block2(x)
      out2=self.block3(out1)
      out3=self.block4(out2)
      out4=self.block5(out3)
      out5=self.block6(out4)
      return x+out5*0.2
 

#定义生成器
class GeneratorRIRNet(nn.Module):
    def __init__(self, in_channels=3, out_channels=3, n_residual_blocks=6):
        super(GeneratorRIRNet, self).__init__()
        # First layer,abstract low-features
        self.conv1 = nn.Sequential(nn.Conv2d(in_channels, 64, kernel_size=9, stride=1, padding=4), nn.PReLU())

        # Residual blocks,abstract high-features
        res_blocks = []
        for _ in range(n_residual_blocks):
            res_blocks.append(RIRBlock())
        self.res_blocks = nn.Sequential(*res_blocks)


        # Second conv layer post residual blocks
        self.conv2 = nn.Sequential(nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1))
        
        # Upsampling layers
        upsampling = []
        for out_features in range(2):
            upsampling += [
                # nn.Upsample(scale_factor=2),
                nn.Conv2d(64, 256, 3, 1, 1),
                nn.BatchNorm2d(256),
                nn.PixelShuffle(upscale_factor=2),
                nn.PReLU(),
            ]
        self.upsampling = nn.Sequential(*upsampling)

        # Final output layer
        self.conv3 = nn.Sequential(nn.Conv2d(64, out_channels, kernel_size=9, stride=1, padding=4), nn.Tanh())

    def update_scale(self, new_scale):
      """
      Updates the scale used by the Meta-Upscale Module. Allows for on-demand changing of scaling factor.
      :param new_scale: new scale.
      """
      self.MetaUpscaleModule.update_scale(new_scale)

    def forward(self, x):
        out1 = self.conv1(x)
        out = self.res_blocks(out1)
        out2 = self.conv2(out)
        out = torch.add(out1, out2)
        out = self.upsampling(out)
        out = self.conv3(out)
        return out

class Discriminator(nn.Module):
    def __init__(self, input_shape):
        super(Discriminator, self).__init__()

        self.input_shape = input_shape
        in_channels,in_height, in_width = self.input_shape
        patch_h, patch_w = int(in_height / 2 ** 4), int(in_width / 2 ** 4)
        self.output_shape = (1, patch_h, patch_w)

        def discriminator_block(in_filters, out_filters, first_block=False):
            layers = []
            layers.append(nn.Conv2d(in_filters, out_filters, kernel_size=3, stride=1, padding=1))
            if not first_block:
                layers.append(nn.BatchNorm2d(out_filters))
            layers.append(nn.LeakyReLU(0.2, inplace=True))
            layers.append(nn.Conv2d(out_filters, out_filters, kernel_size=3, stride=2, padding=1))
            layers.append(nn.BatchNorm2d(out_filters))
            layers.append(nn.LeakyReLU(0.2, inplace=True))
            return layers

        layers = []
        in_filters = in_channels
        for i, out_filters in enumerate([64, 128, 256, 512]):
            layers.extend(discriminator_block(in_filters, out_filters, first_block=(i == 0)))
            in_filters = out_filters

        layers.append(nn.Conv2d(out_filters, 1, kernel_size=3, stride=1, padding=1))

        self.model = nn.Sequential(*layers)

    def forward(self, img):
        return self.model(img)

class TVLoss(nn.Module):
    def __init__(self, tv_loss_weight=1):
        super(TVLoss, self).__init__()
        self.tv_loss_weight = tv_loss_weight

    def forward(self, x):
        batch_size = x.size()[0]
        h_x = x.size()[2]
        w_x = x.size()[3]
        count_h = self.tensor_size(x[:, :, 1:, :])
        count_w = self.tensor_size(x[:, :, :, 1:])
        h_tv = torch.pow((x[:, :, 1:, :] - x[:, :, :h_x - 1, :]), 2).sum()
        w_tv = torch.pow((x[:, :, :, 1:] - x[:, :, :, :w_x - 1]), 2).sum()
        return self.tv_loss_weight * 2 * (h_tv / count_h + w_tv / count_w) / batch_size

    @staticmethod
    def tensor_size(t):
        return t.size()[1] * t.size()[2] * t.size()[3]   
    

class UnetD(nn.Module):
    def __init__(self,num_in_ch,num_feat=64,skip_connection=True):
        super(UnetD,self).__init__()
        norm=spectral_norm
        self.skip_connection=skip_connection
        #the first convolution
        self.conv0=nn.Conv2d(num_in_ch,num_feat,kernel_size=3,stride=1,padding=1)
        #downsample
        self.conv1=norm(nn.Conv2d(num_feat,num_feat*2,4,2,1,bias=False))
        self.conv2=norm(nn.Conv2d(num_feat*2,num_feat*4,4,2,1,bias=False))
        self.conv3=norm(nn.Conv2d(num_feat*4,num_feat*8,4,2,1,bias=False))
        #upsample
        self.conv4=norm(nn.Conv2d(num_feat*8,num_feat*4,3,1,1,bias=False))
        self.conv5=norm(nn.Conv2d(num_feat*4,num_feat*2,3,1,1,bias=False))
        self.conv6=norm(nn.Conv2d(num_feat*2,num_feat*3,1,1,bias=False))
        #extra convolutions
        self.conv7=norm(nn.Conv2d(num_feat,num_feat,3,1,1,bias=False))
        self.conv8=norm(nn.Conv2d(num_feat,num_feat,3,1,1,bias=False))
        self.conv9=nn.Conv2d(num_feat,1,3,1,1)
    def forward(self, x):
        #downsample
        x0=F.leaky_relu(self.conv0(x),negative_slope=0.2,inplace=True)
        x1=F.leaky_relu(self.conv1(x0),negative_slope=0.2,inplace=True)
        x2=F.leaky_relu(self.conv2(x1),negative_slope=0.2,inplace=True)
        x3=F.leaky_relu(self.conv3(x2),negative_slope=0.2,inplace=True)
        #upsample
        x3=F.interpolate(x3,scale_factor=2,mode='bilinear',align_corners=False)
        x4=F.leaky_relu(self.conv4(x3),negative_slope=0.2,inplace=True)

        if self.skip_connection:
            x5=x5+x1
        x5=F.interpolate(x5,scale_factor=2,mode='bilinear',align_corners=False)
        x6=F.leaky_relu(self.conv6(x5),negative_slope=0.2,inplace=True)
        if self.skip_connection:
            x6=x6+x0
        
        #extra convolution
        out=F.leaky_relu(self.conv7(x6),negative_slope=0.2,inplace=True)
        out=F.leaky_relu(self.conv8(out),negative_slope=0.2,inplace=True)
        out=self.conv9(out)
        
        return out