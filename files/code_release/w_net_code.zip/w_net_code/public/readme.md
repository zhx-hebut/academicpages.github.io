## Introduction
In this repo, we supply the w-net model and train script.

### Data prepare
You should download the data and slice it to png format, the file as flow:

```
├liver
├── test
│   ├── image
│   └── label
├── train
│   ├── image
│   └── label
└── val
    ├── image
    └── label
```

### Config the path and param in train_opt.py, then:
```shell
python train_opt.py
```

## Citation

If w-net is useful for your research, please cite the following article in your papers:

@article{w-Net2022,
	title={$\omega$-Net: Dual Supervised Medical Image Segmentation with Multi-Dimensional Self-Attention and Diversely-Connected Multi-Scale Convolution},
	author={Xu, Zhenghua and Liu, Shijie and Yuan, Di and Wang, Lei and Chen, Junyang and Lukasiewicz, Thomas and Fu, Zhigang and Zhang, Rui},
	journal={Neurocomputing},
volume = {500},
pages = {177-190},
	year={2022}
}
