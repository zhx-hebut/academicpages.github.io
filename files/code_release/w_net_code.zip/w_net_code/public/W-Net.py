import torch.nn.functional as F
from math import sqrt
import torch
import torch.nn as nn


def rewrite(x):
    y = (x > 0.5).astype('uint8')
    return y


def conv5x5(in_channels, out_channels, stride=1, padding=2, bias=True, groups=1):
    return nn.Conv2d(in_channels, out_channels, kernel_size=5, stride=stride, padding=padding, bias=bias, groups=groups)


def conv3x3(in_channels, out_channels, stride=1, padding=1, bias=True, groups=1):
    return nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=padding, bias=bias, groups=groups)


def conv1x1(in_channels, out_channels, groups=1):
    return nn.Conv2d(in_channels, out_channels, kernel_size=1, groups=groups, stride=1)


def upconv2x2(in_channels, out_channels, mode='transpose'):
    if mode == 'transpose':
        return nn.ConvTranspose2d(in_channels, out_channels, kernel_size=2, stride=2)
    else:
        return nn.Sequential(nn.Upsample(mode='bilinear', scale_factor=2), conv1x1(in_channels, out_channels))


def square_conv(in_channels, out_channels, stride=1, padding=1, bias=True, groups=1):
    return nn.Conv2d(in_channels, out_channels, kernel_size=(3, 3), stride=stride, padding=padding, bias=bias, groups=groups)


def ver_conv(in_channels, out_channels, stride=1, padding=(1, 0), bias=True, groups=1):
    return nn.Conv2d(in_channels, out_channels, kernel_size=(3, 1), stride=stride, padding=padding, bias=bias, groups=groups)


def hor_conv(in_channels, out_channels, stride=1, padding=(0, 1), bias=True, groups=1):
    return nn.Conv2d(in_channels, out_channels, kernel_size=(1, 3), stride=stride, padding=padding, bias=bias, groups=groups)


def maxpooling_4(stride=4, padding=0):
    return nn.MaxPool1d(kernel_size=4, stride=stride, padding=padding)


def conv1x7_1(in_channels, out_channels, stride=7, padding=3, bias=True):
    return nn.Conv1d(in_channels, out_channels, kernel_size=3, stride=stride, padding=padding, dilation=3, bias=bias, groups=in_channels)


def conv1x7_2(in_channels, out_channels, stride=7, padding=2, bias=True):
    return nn.Conv1d(in_channels, out_channels, kernel_size=3, stride=stride, padding=padding, dilation=3, bias=bias, groups=in_channels)


def conv1x5(in_channels, out_channels, stride=5, padding=0, bias=True):
    return nn.Conv1d(in_channels, out_channels, kernel_size=3, stride=stride, padding=padding, dilation=2, bias=bias, groups=in_channels)


def conv1x9_1(in_channels, out_channels, stride=9, padding=4, bias=True):
    return nn.Conv1d(in_channels, out_channels, kernel_size=5, stride=stride, padding=padding, dilation=2, bias=bias, groups=in_channels)


def conv1x9_2(in_channels, out_channels, stride=9, padding=2, bias=True):
    return nn.Conv1d(in_channels, out_channels, kernel_size=5, stride=stride, padding=padding, dilation=2, bias=bias, groups=in_channels)


def conv1x9_3(in_channels, out_channels, stride=9, padding=3, bias=True):
    return nn.Conv1d(in_channels, out_channels, kernel_size=5, stride=stride, padding=padding, dilation=2, bias=bias, groups=in_channels)


def conv1x9_4(in_channels, out_channels, stride=9, padding=1, bias=True):
    return nn.Conv1d(in_channels, out_channels, kernel_size=5, stride=stride, padding=padding, dilation=2, bias=bias, groups=in_channels)


def conv1x9_5(in_channels, out_channels, stride=9, padding=0, bias=True):
    return nn.Conv1d(in_channels, out_channels, kernel_size=5, stride=stride, padding=padding, dilation=2, bias=bias, groups=in_channels)


class DownConv(nn.Module):
    def __init__(self, in_channels, out_channels, pooling=True):
        super(DownConv, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.pooling = pooling

        self.conv1_1 = square_conv(self.in_channels, self.out_channels)
        self.conv1_2 = square_conv(self.out_channels, self.out_channels)
        self.conv2 = ver_conv(self.out_channels, self.out_channels)
        self.conv3 = hor_conv(self.out_channels, self.out_channels)

        if self.pooling:
            self.pool = nn.MaxPool2d(kernel_size=2, stride=2)

    def forward(self, x):
        x_1_1 = F.relu(self.conv1_1(x), inplace=True)
        x_1_2 = F.relu(self.conv1_2(x_1_1))
        x_2 = F.relu(self.conv2(x_1_1), inplace=True)
        x_3 = F.relu(self.conv3(x_1_1), inplace=True)
        x = x_1_2 + x_2 + x_3
        before_pool = x  # for going on directly
        if self.pooling:
            x = self.pool(x)
        return x, before_pool


class MultiConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(MultiConv, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        # self.bn = nn.BatchNorm2d(3 * self.out_channels)
        self.bn = nn.BatchNorm2d(self.out_channels)

        self.multi_conv1 = conv5x5(self.in_channels, self.out_channels)
        self.multi_conv2 = conv3x3(self.in_channels, self.out_channels)
        self.multi_conv3 = conv1x1(self.in_channels, self.out_channels)
        self.multi_conv4 = conv1x1(4 * self.out_channels, self.out_channels)

    def forward(self, x):

        x_1 = F.relu(self.multi_conv1(x), inplace=True)
        x_2 = F.relu(self.multi_conv2(x + x_1), inplace=True)
        x_3 = F.relu(self.multi_conv3(x + x_2), inplace=True)
        x_cat = torch.cat((x, x_1, x_2, x_3), 1)
        out_multiconv = F.relu(self.bn(self.multi_conv4(x_cat)), inplace=True)

        return out_multiconv


class UpConv(nn.Module):
    def __init__(self, in_channels, out_channels, merge_mode='concat', up_mode='transpose'):
        super(UpConv, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.merge_mode = merge_mode
        self.up_mode = up_mode

        self.upconv = upconv2x2(self.in_channels, self.out_channels, mode=self.up_mode)

        if self.merge_mode == 'concat':
            self.conv1 = conv3x3(2 * self.out_channels, self.out_channels)
        else:
            self.conv1 = conv3x3(self.out_channels, self.out_channels)
        self.conv2 = conv3x3(self.out_channels, self.out_channels)

    def forward(self, from_down, from_up):
        from_up = self.upconv(from_up)
        if self.merge_mode == 'concat':
            x = torch.cat((from_up, from_down), 1)
        else:
            x = from_up + from_down
        x = F.relu(self.conv1(x), inplace=True)
        x = F.relu(self.conv2(x), inplace=True)
        return x


class PamModule(nn.Module):
    """ Position attention module"""
    def __init__(self, in_dim):
        super(PamModule, self).__init__()
        self.in_channels = in_dim

        self.query_conv = conv1x1(self.in_channels, self.in_channels // 8)
        self.key_conv = conv1x1(self.in_channels, self.in_channels // 8)
        self.value_conv = conv1x1(self.in_channels, self.in_channels)
        self.gamma = nn.Parameter(torch.zeros(1))

        self.conv1 = conv1x7_1(self.in_channels // 8, self.in_channels // 8)
        self.conv2 = conv1x5(self.in_channels // 8, self.in_channels // 8)
        self.conv3 = conv1x9_1(self.in_channels // 8, self.in_channels // 8)
        self.conv4 = conv1x9_2(self.in_channels // 8, self.in_channels // 8)
        self.conv5 = conv1x9_3(self.in_channels // 8, self.in_channels // 8)

        self.conv6 = conv1x9_4(self.in_channels // 8, self.in_channels // 8)
        self.conv7 = conv1x9_5(self.in_channels // 8, self.in_channels // 8)

        self.maxpool4 = maxpooling_4()
        self.conv8 = conv1x7_2(self.in_channels // 8, self.in_channels // 8)

        # pro_value:
        self.conv1_v = conv1x7_1(self.in_channels, self.in_channels)
        self.conv2_v = conv1x5(self.in_channels, self.in_channels)
        self.conv3_v = conv1x9_1(self.in_channels, self.in_channels)
        self.conv4_v = conv1x9_2(self.in_channels, self.in_channels)
        self.conv5_v = conv1x9_3(self.in_channels, self.in_channels)

        self.conv6_v = conv1x9_4(self.in_channels, self.in_channels)
        self.conv7_v = conv1x9_5(self.in_channels, self.in_channels)

        self.maxpool4_v = maxpooling_4()
        self.conv8_v = conv1x7_2(self.in_channels, self.in_channels)

        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        """
            inputs :
                x : input feature maps( B X C X H X W)
            returns :
                out : attention value + input feature
                attention: B X (HxW) X (HxW)
        """
        m_batchsize, c, height, width = x.size()

        proj_query = self.query_conv(x).view(m_batchsize, -1, width * height).permute(0, 2, 1)
        proj_key = self.key_conv(x).view(m_batchsize, -1, width * height)
        if proj_key.size()[1] == 8:
            proj_key = F.relu(self.conv5(F.relu(self.conv4(F.relu(self.conv3(F.relu(self.conv2(F.relu(self.conv1(proj_key))))))))))

        if proj_key.size()[1] == 16:
            proj_key = F.relu(self.conv7(F.relu(self.conv7(F.relu(self.conv3(F.relu(self.conv6(proj_key))))))))

        if proj_key.size()[1] == 32:
            proj_key = F.relu(self.conv8(F.relu(self.conv1(F.relu(self.conv3(self.maxpool4(proj_key)))))))

        if proj_key.size()[1] == 64:
            proj_key = F.relu(self.conv8(F.relu(self.conv1(F.relu(self.conv3(proj_key))))))

        energy = torch.bmm(proj_query, proj_key)
        attention = self.softmax(energy)


        """# proj_query = x.view(m_batchsize, -1, width * height).permute(0, 2, 1)
        # proj_key = x.view(m_batchsize, -1, width * height)

        # energy = torch.bmm(proj_query, proj_key)
        # attention = self.softmax(energy)
        """
        proj_value = self.value_conv(x).view(m_batchsize, -1, width * height)

        if proj_value.size()[1] == 64:
            proj_value = F.relu(self.conv5_v(F.relu(self.conv4_v(F.relu(self.conv3_v(F.relu(self.conv2_v(F.relu(self.conv1_v(proj_value))))))))))

        if proj_value.size()[1] == 128:
            proj_value = F.relu(self.conv7_v(F.relu(self.conv7_v(F.relu(self.conv3_v(F.relu(self.conv6_v(proj_value))))))))

        if proj_value.size()[1] == 256:
            proj_value = F.relu(self.conv8_v(F.relu(self.conv1_v(F.relu(self.conv3_v(self.maxpool4_v(proj_value)))))))

        if proj_value.size()[1] == 512:
            proj_value = F.relu(self.conv8_v(F.relu(self.conv1_v(F.relu(self.conv3_v(proj_value))))))


        energy_ca = torch.bmm(proj_value, attention.permute(0, 2, 1))
        out = energy_ca.view(m_batchsize, c, height, width)
        out = self.gamma * out + x
        return out


class CamModule(nn.Module):
    """ Channel attention module"""

    def __init__(self, in_dim):
        super(CamModule, self).__init__()
        self.in_channels = in_dim

        self.gamma = nn.Parameter(torch.zeros(1))
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        """
            inputs :
                x : input feature maps( B X C X H X W)
            returns :
                out : attention value + input feature
                attention: B X C X C
        """
        m_batchsize, c, height, width = x.size()
        proj_query = x.view(m_batchsize, c, -1)
        proj_key = x.view(m_batchsize, c, -1).permute(0, 2, 1)

        energy = torch.bmm(proj_query, proj_key)
        attention = self.softmax(energy)
        proj_value = x.view(m_batchsize, c, -1)

        out = torch.bmm(attention, proj_value)
        out = out.view(m_batchsize, c, height, width)

        out = self.gamma * out + x
        return out


class MSCANet(nn.Module):
    def __init__(self, num_classes, in_channels=1, depth=5, start_filts=64, up_mode='transpose', merge_mode='concat'):
        super(MSCANet, self).__init__()
        self.up_mode = up_mode
        self.merge_mode = merge_mode
        self.num_classes = num_classes

        self.in_channels = in_channels
        self.start_filts = start_filts
        self.depth = depth

        self.down_convs = []
        self.up_convs = []
        self.multi_convs = []
        self.multi_attentions = []

        # create the encoder pathway and add to a list
        for i in range(depth):
            if i == 0:
                input_channels = self.in_channels
            else:
                input_channels = output_channels
            output_channels = self.start_filts * (2 ** i)

            if i < (depth - 1):
                pooling = True
            else:
                pooling = False

            down_conv = DownConv(input_channels, output_channels, pooling=pooling)
            self.down_convs.append(down_conv)

        for i in range(depth - 1):
            input_channels = self.start_filts * (2 ** i)
            multi_conv = MultiConv(input_channels, input_channels)
            self.multi_convs.append(multi_conv)

        # create the decoder pathway and add to a list
        # print('output_channels is:', output_channels)
        output_de_channels = output_channels
        for i in range(depth - 1):
            input_de_channels = output_de_channels
            output_de_channels = input_de_channels // 2
            up_conv = UpConv(input_de_channels, output_de_channels, up_mode=up_mode, merge_mode=merge_mode)
            # print('up_conv is:', up_conv)
            # print('up_conv.size is:', up_conv.size)
            self.up_convs.append(up_conv)
            # print('up_conv is:', up_conv)
            # print('up_conv.size is:', up_conv.size)

        input_atten_channels = output_channels

        for i in range(1, depth):
            in_atten_channels = input_atten_channels // (2 ** i)
            pattention = PamModule(in_atten_channels)
            multi_conv = MultiConv(in_atten_channels, in_atten_channels)
            cattention = CamModule(in_atten_channels)
            attention = nn.Sequential(pattention, multi_conv, cattention)

            self.multi_attentions.append(attention)

        self.conv_final = conv1x1(output_de_channels, self.num_classes)

        self.down_convs = nn.ModuleList(self.down_convs)
        self.multi_convs = nn.ModuleList(self.multi_convs)
        self.up_convs = nn.ModuleList(self.up_convs)
        self.multi_attentions = nn.ModuleList(self.multi_attentions)
        self.reset_params()

    @staticmethod
    def weight_init(m):
        if isinstance(m, nn.Conv2d):
            nn.init.xavier_normal_(m.weight)
            nn.init.constant_(m.bias, 0)

    def reset_params(self):
        for i, m in enumerate(self.modules()):
            self.weight_init(m)

    def forward(self, x):
        encoder_outs = []

        # encoder pathway, save outputs for merging
        for i, module in enumerate(self.down_convs):
            x, before_pool = module(x)
            encoder_outs.append(before_pool)

        del before_pool

        before_attention = x

        del x
        # del self.down_convs  # ###########################################del########################
        # print('before_attention.shape is:', before_attention.size())

        for i, module in enumerate(self.up_convs):
            del encoder_outs[-1]
            before_pool = encoder_outs[-1]

            multi_module = list(list(enumerate(self.multi_convs))[3 - i])[1]
            before_pool = multi_module(before_pool)

            before_attention = module(before_pool, before_attention)

            attention_module = list(list(enumerate(self.multi_attentions))[i])[1]
            attention = attention_module(before_attention)

            del attention_module

            if i == 0:
                attention_out = attention

            if i > 0:
                attention_out = module(attention, attention_out)

        del encoder_outs

        # No softmax is used. This means you need to use
        # nn.CrossEntropyLoss is your training script,
        # as this module includes a softmax already.
        seg_decode = self.conv_final(before_attention)
        seg = self.conv_final(attention_out)
        seg_decode = torch.sigmoid(seg_decode)
        seg = torch.sigmoid(seg)
        return seg_decode, seg
