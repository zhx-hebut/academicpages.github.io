# from pylab import *
from torch.utils.data import DataLoader
from W-Net import MSCANet
import data_load_get
import torch
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable
import torchvision
import numpy as np
import os
import torch.nn.functional as F
import torchvision
import torchvision.transforms as transforms
from torch.autograd import Variable
from torchvision.utils import save_image
import datetime
import sys
import time
import argparse


class Option:
    def __init__(self):
        self.cuda = True  # use cuda?
        self.batchSize = 4  # training batch size
        self.Epochs = 100  # umber of epochs to train for
        self.lr = 0.0001  # Learning Rate. Default=0.0001
        self.threads = 4
        self.out_images_path ="./pancreas"
        self.runing_mode_1 = 'training'
        self.runing_mode_2 = 'validation'
        self.size = 512
        self.target_mode = 'label'
        self.model_out_path = "./pancreas"


opt = Option()

out_images_folder_name = "{}_{}_{}_{}".format(opt.runing_mode_1, datetime.datetime.now().strftime("%Y-%m-%d_%H:%M:%S"),
                                              opt.batchSize, opt.lr)

trans = transforms.ToTensor()


def cus_dataset(runing_mode):
    custom_dataset = data_load_get.DataGet('{}/image'.format(runing_mode),
                                           '{}/label'.format(runing_mode), transform=trans)
    return custom_dataset


device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
"""
jia gpu
"""
net = MSCANet(2, merge_mode='concat')
if torch.cuda.device_count() > 1:
    net = nn.DataParallel(net)

net.to(device)

train_dataset = torch.utils.data.DataLoader(dataset=cus_dataset(opt.runing_mode_1),
                                            batch_size=opt.batchSize, shuffle=True)

validation_dataset = torch.utils.data.DataLoader(dataset=cus_dataset(opt.runing_mode_2),
                                                 batch_size=opt.batchSize, shuffle=False)

validation_path = os.path.join(opt.out_images_path, out_images_folder_name, 'validation')
if not os.path.exists(validation_path):
    os.makedirs(validation_path)


"""
if torch.cuda.is_available():
    device = torch.device('cuda:0')
else:
    device = torch.device('cpu')
"""


def denorm(x):
    out = (x + 1) / 2
    return out.clamp(0, 1)


def rewrite(x):
    y = (x > 0.5).astype('uint8')
    return y


def mergeout(x):
    ori_image = x.reshape(x.size(0), 3, 512, 512)
    return ori_image


def mergepic(x):
    ori_image = x.reshape(x.size(0), 1, 512, 512)
    return ori_image


"""
net = MultiScaleSegNet(2, merge_mode='concat').to(device)
"""

pretrained = False
if pretrained:
    net.load_state_dict(torch.load('/home/wangbo/IC/MDA_U_Net/kidney/training_2020-07-29_17:55:33_2_1e-09/8_Multi-Scale Attention SegNet_MODEL.pth'))
    """
    net.load_state_dict(torch.load('/mnt/DATA/wangbo/project/multi_attention/kidney/'
                                   'training_2019-12-05_22_23_24_1_0.0001/3_Multi-Scale Attention SegNet_MODEL.pth',
                                   map_location='cuda:0'))
    """
criterion = nn.BCELoss()
accumulation_steps = 2


def train(epoch):
    optimizer = torch.optim.Adam(net.parameters(), lr=opt.lr, weight_decay=0.00015)
    if 3 < epoch < 11:
        if epoch % 2 == 0:
            opt.lr = opt.lr * 0.8
            print('learning_rate is:', opt.lr)
    if epoch > 10:
        if epoch % 2 == 0:
            opt.lr = opt.lr * 0.6
            print('learning_rate is:', opt.lr)

    total_loss = 0
    for i, (image, label) in enumerate(train_dataset):
        time0 = time.time()
        image = image.to(device)
        label = label.to(device)
        seg_decode, seg = net(image)

        label_chun_path = os.path.join(opt.out_images_path, out_images_folder_name, 'label_chun',
                                       'epoch-{}'.format(epoch))
        if not os.path.exists(label_chun_path):
            os.makedirs(label_chun_path)
        output_chun_path = os.path.join(opt.out_images_path, out_images_folder_name, 'output_chun',
                                        'epoch-{}'.format(epoch))
        if not os.path.exists(output_chun_path):
            os.makedirs(os.path.join(output_chun_path))
        input_path = os.path.join(opt.out_images_path, out_images_folder_name, 'input', 'epoch-{}'.format(epoch))
        if not os.path.exists(input_path):
            os.makedirs(input_path)

        # print('seg.size is:', seg.size())

        seg_pancreas = seg[:, 0, :, :]
        seg_tumor = seg[:, 1, :, :]
        label_pancreas = label[:, 0, :, :]
        label_tumor = label[:, 2, :, :]
        seg_green = torch.zeros(seg.shape[0], 512, 512)
        bi_label = torch.stack((label_pancreas.cuda(), label_tumor.cuda()), 1)
        # print('153 bi_label.type is:', type(bi_label))
        # print('154 seg.type is:', type(seg))

        output_seg = torch.stack((seg_pancreas.cuda(), seg_green.cuda(), seg_tumor.cuda()), 1)

        if (i+1) % 500 is 0:
            label = mergeout(label)
            save_image(label, os.path.join(label_chun_path, 'label-{}.png'.format(i+1)))
            output_chun = mergeout(output_seg)
            save_image(output_chun, os.path.join(output_chun_path, 'segmentation-{}.png'.format(i+1)))
            image = mergepic(image)
            save_image(image, os.path.join(input_path, 'image-{}.png'.format(i+1)))

        loss_seg_decode = criterion(seg_decode, bi_label)
        loss_seg = criterion(seg, bi_label)
        loss = 0.1 * loss_seg_decode + loss_seg


        total_loss = total_loss + float(loss)

        loss = loss / accumulation_steps
        loss.backward()

        if ((i + 1) % accumulation_steps) == 0:
            optimizer.step()
            optimizer.zero_grad()

        time1 = time.time()
        timed = time1 - time0

        with open(os.path.join(opt.out_images_path, out_images_folder_name, 'Loss.txt'), 'a') as log:
            log.write("Epoch: {}, iteration: {}\n".format(epoch, i+1))
            log.write("Loss: {}, time: {}\n".format(loss.item(), timed))

        if (i + 1) % 5 == 0:
            print("Epoch[{}/{}],step[{}/{}],loss:{:.8f},timef:{:.8f}".format(epoch, Epochs, i+1, len(train_dataset),
                                                                             loss.item(), timed))

    torch.save(net.state_dict(), os.path.join(opt.model_out_path, out_images_folder_name,
                                              '{}_Multi-Scale Attention SegNet_MODEL.pth'.format(epoch)))

    print("Epoch: {}, Average_loss: {}".format(epoch, total_loss / len(train_dataset)))
    with open(os.path.join(opt.out_images_path, out_images_folder_name, 'Loss.txt'), 'a') as log:
        log.write("Epoch: {}, Average_loss: {}".format(epoch, total_loss / len(train_dataset)))

    print("{}_Multi-Scale Attention SegNet_MODEL.pth is saved to {}".
          format(epoch, os.path.join(opt.model_out_path, out_images_folder_name, '{}_Multi-Scale Attention SegNet_'
                                                                                 'MODEL.pth'.format(epoch))))


def validation(epoch):
    total_loss = 0
    time0 = time.time()
    for number, (image, label) in enumerate(validation_dataset, 1):
        # time0 = time.time()
        image = image.to(device)
        label = label.to(device)
        seg_decode, seg = net(image)
        seg = seg.data
        seg_decode =seg_decode.data

        label_pancreas = label[:, 0, :, :]
        label_tumor = label[:, 2, :, :]
        bi_label = torch.stack((label_pancreas.cuda(), label_tumor.cuda()), 1)


        loss_seg_decode = criterion(seg_decode, bi_label)
        loss_seg = criterion(seg, bi_label)
        loss = 0.1 * loss_seg_decode + loss_seg
        total_loss = total_loss + float(loss)

    va_aver_loss = total_loss / len(validation_dataset)
    time1 = time.time()
    timed = time1 - time0
    with open(os.path.join(validation_path, 'Loss.txt'), 'a') as log:
        log.write("Epoch: {}\n".format(epoch))
        log.write("Average validation loss: {}, time: {}\n".format(va_aver_loss, timed))
    print("===> Epoch {} Average validation loss: {:.6f} dB".format(epoch, va_aver_loss))
    return va_aver_loss


Epochs = opt.Epochs
try:
    validation_average_loss = 1
    n = 0
    epoch = 1
    while epoch < Epochs + 1:
        for epoch in range(n + 1, Epochs + 1):
            train(epoch)
            va_aver_loss = validation(epoch)
            if va_aver_loss < validation_average_loss:
                validation_average_loss = va_aver_loss
                best_epoch = epoch
                if epoch > 2:
                    Epochs = epoch * 2
                    n = epoch
                    break
        if epoch == Epochs:
            break
    with open(os.path.join(validation_path, 'Loss.txt'), 'a') as log:
        log.write("The best model epoch is: {}_Multi-Scale Attention SegNet_MODEL.pth\n".format(best_epoch))

except KeyboardInterrupt:
    torch.save(net.state_dict(), os.path.join(opt.model_out_path, out_images_folder_name,
                                              '{}_Multi-Scale Attention SegNet_MODEL.pth'.format(epoch)))
    print('Saved interrupt')
    try:
        sys.exit(0)
    except SystemExit:
        os.exit(0)
