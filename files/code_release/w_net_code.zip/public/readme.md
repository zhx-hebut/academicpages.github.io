## Introduction
In this repo, we supply the w-net model and train script.

### Data prepare
You should download the data and slice it to png format, the file as flow:

```
├liver
├── test
│   ├── image
│   └── label
├── train
│   ├── image
│   └── label
└── val
    ├── image
    └── label
```

### Config the path and param in train_opt.py, then:
```shell
python train_opt.py
```