import os
import sys
sys.path.append('..')
import time
import logging
import argparse
import torch.nn as nn
import torch.nn.parallel
import torch.optim
import torch.utils.data
import torch
from utils import dataset, transform
from utils.util import AverageMeter
from model.Unet_1pc_conv_cat_aspp_organ import UNet
from tensorboardX import SummaryWriter
from torchvision.utils import save_image


parser = argparse.ArgumentParser(description='Training')
parser.add_argument('--evaluate', default=None)
parser.add_argument('--base_lr', default=0.0001, type=float, help='Basic learning rate')
parser.add_argument('--epochs', default=20, type=int)
parser.add_argument('--start_epoch', default=0)
parser.add_argument('--threshold', default=0.5, type=float, help='Threshold')
parser.add_argument('--data_root', default='.../Dataset/pancreas_TCIA')
parser.add_argument('--train_list', default='.../Dataset/pancreas_TCIA/list/train.txt')
parser.add_argument('--val_list', default='.../Dataset/pancreas_TCIA/list/val.txt')
parser.add_argument('--test_list', default='.../Dataset/pancreas_TCIA/list/test.txt')
parser.add_argument('--momentum', default=0.09)
parser.add_argument('--weight_decay', default=0, type=float)
parser.add_argument('--save_path', default='./exp_final')
parser.add_argument('--checkpoint_path', default='./trained/exp_le')
parser.add_argument('--batch_size', default=2, type=int)
parser.add_argument('--batch_size_val', default=2, type=int)
parser.add_argument('--save_freq', default=2, type=int)
parser.add_argument('--print_freq', default=5)
parser.add_argument('--rank', default=0)
parser.add_argument('--workers', default=16, type=int)
parser.add_argument('--rotate_min', default=-10)
parser.add_argument('--rotate_max', default=10)
parser.add_argument('--power', default=0.9)
parser.add_argument('--classes', default=2, help='num_classes')
args = parser.parse_args()


def get_logger():
    logger_name = "main-logger"
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    fmt = "[%(asctime)s %(levelname)s %(filename)s line %(lineno)d %(process)d] %(message)s"
    handler.setFormatter(logging.Formatter(fmt))
    logger.addHandler(handler)
    return logger


logger = get_logger()
# if not os.path.exists(os.path.join(args.save_path, 'train')):
#     os.makedirs(os.path.join(os.path.join(args.save_path, 'train')))
# if not os.path.exists(os.path.join(args.save_path, 'val')):
#     os.makedirs(os.path.join(os.path.join(args.save_path, 'val')))

writer = SummaryWriter(args.save_path)


def metric(tensorpr,tensorgt):
    ttensorpr = tensorpr.float()
    ttensorgt = tensorgt.float()

    intersection = ttensorpr * ttensorgt
    T = ttensorgt.sum((2, 3)).float()  # shape: b*c
    P = ttensorpr.sum((2, 3)).float()  # shape: b*c
    TP = intersection.sum((2, 3)).float()  # shape: b*c

    return T, P, TP


def get_metric(T, P, TP):
    dice = ((2*TP) + 1e-10) / (T+P+1e-10)
    ppv = (TP+1e-10) / (P+1e-10)
    sensitivity = (TP+1e-10) / (T+1e-10)
    return dice, ppv, sensitivity


class DiceLoss(nn.Module):
    def __init__(self):
        super(DiceLoss, self).__init__()

    def forward(self, input, target):
        N = target.size(0)
        smooth = 1

        input_flat = input.view(N, -1)
        target_flat = target.view(N, -1)

        intersection = input_flat * target_flat

        loss = (2 * intersection.sum(1) + smooth) / (input_flat.sum(1) + target_flat.sum(1) + smooth)
        loss = 1 - loss.sum() / N

        return loss


def train(train_loader, model, optimizer, epoch, criterion_main, criterion_aux, epoch_log):
    logger.info('>>>>>>>>>>>>>>>> Start Train >>>>>>>>>>>>>>>>')
    batch_time = AverageMeter()
    data_time = AverageMeter()
    intersection_meter = AverageMeter()
    main_loss_meter = AverageMeter()
    aux_loss_meter = AverageMeter()
    loss_meter = AverageMeter()
    union_meter = AverageMeter()
    target_meter = AverageMeter()

    model.train()
    end = time.time()
    max_iter = args.epochs * len(train_loader)
    for i, (image, label) in enumerate(train_loader):
        h = label.shape[2]
        w = label.shape[3]
        data_time.update(time.time() - end)
        image_in = image[:, 0, :, :].unsqueeze(1)
        image_in = image_in.cuda()
        label[:, 0, :, :] = label[:, 0, :, :] + label[:, 2, :, :]
        label[:, 2, :, :] = 0
        label = label.cuda()
        label_to_loss = label[:, 0, :, :].unsqueeze(1) / 255

        if (i + 1) % 50 == 0:
            if not os.path.exists(os.path.join(args.save_path, 'train/label', 'Epoch_{}'.format(epoch_log))):
                os.makedirs(os.path.join(args.save_path, 'train/label', 'Epoch_{}'.format(epoch_log)))
            label_path = os.path.join(args.save_path, 'train/label', 'Epoch_{}'.format(epoch_log))
            save_image(label.float(), os.path.join(label_path, '{}.png'.format(i)), nrow=args.batch_size)

        output_to_loss1, output_to_loss2 = model(image_in)
        zero = torch.zeros((args.batch_size, 2, h, w)).cuda()
        output_to_save = torch.cat((output_to_loss1, zero), dim=1)
        # output_to_save[output_to_save >= 0.05] = 1.0
        # output_to_save[output_to_save < 0.05] = 0.0

        if (i + 1) % 50 == 0:
            if not os.path.exists(os.path.join(args.save_path, 'train/image', 'Epoch_{}'.format(epoch_log))):
                os.makedirs(os.path.join(args.save_path, 'train/image', 'Epoch_{}'.format(epoch_log)))
            image_path = os.path.join(args.save_path, 'train/image', 'Epoch_{}'.format(epoch_log))
            save_image(255 * output_to_save.float(), os.path.join(image_path, '{}.png'.format(i)), nrow=args.batch_size)

        main_loss = criterion_main(output_to_loss1, label_to_loss.float())
        aux_loss = criterion_aux(output_to_loss2, label_to_loss.float())
        loss = main_loss + aux_loss
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        n = image.size(0)
        main_loss_meter.update(main_loss.item(), n)
        aux_loss_meter.update(aux_loss.item(), n)
        loss_meter.update(loss.item(), n)
        batch_time.update(time.time() - end)
        end = time.time()

        current_iter = epoch * len(train_loader) + i + 1
        # current_lr = poly_learning_rate(args.base_lr, current_iter, max_iter, power=args.power)
        # optimizer.param_groups[0]['lr'] = current_lr
        remain_iter = max_iter - current_iter
        remain_time = remain_iter * batch_time.avg
        t_m, t_s = divmod(remain_time, 60)
        t_h, t_m = divmod(t_m, 60)
        remain_time = '{:02d}:{:02d}:{:02d}'.format(int(t_h), int(t_m), int(t_s))

        if (i + 1) % args.print_freq == 0:
            logger.info('Epoch: [{}/{}][{}/{}] '
                        'Data {data_time.val:.3f} ({data_time.avg:.3f}) '
                        'Batch {batch_time.val:.3f} ({batch_time.avg:.3f}) '
                        'Remain {remain_time} '
                        'Loss {loss_meter.val:.4f} '.format(epoch + 1, args.epochs, i + 1, len(train_loader),
                                                            batch_time=batch_time,
                                                            data_time=data_time,
                                                            remain_time=remain_time,
                                                            loss_meter=loss_meter))
            if not os.path.exists(os.path.join(args.save_path, 'train/loss')):
                os.makedirs(os.path.join(args.save_path, 'train/loss'))
            with open(os.path.join(args.save_path, 'train/loss',
                                   'Epoch{}_loss.txt'.format(epoch_log)), 'a') as loss_write:
                loss_write.write('Epoch:{}, iteration:{}, loss:{:.6f}\n'.format(epoch_log,
                                                                                i + 1,
                                                                                loss_meter.val))

    if not os.path.exists(os.path.join(args.save_path, 'train/metric')):
        os.makedirs(os.path.join(args.save_path, 'train/metric'))
    with open(os.path.join(args.save_path, 'train/metric',
                           'm.txt'), 'a') as metric_write:
        metric_write.write('Epoch:{}--Epoch_Avg_Loss:{:.6f}\n'.format(epoch_log, loss_meter.avg))

    return loss_meter.avg, main_loss_meter.avg, aux_loss_meter.avg


def validation(val_loader, model, criterion_main, criterion_aux, epoch_log):
    logger.info('>>>>>>>>>>>>>>>> Start Evaluation >>>>>>>>>>>>>>>>')
    batch_time = AverageMeter()
    data_time = AverageMeter()
    loss_meter = AverageMeter()
    main_loss_meter = AverageMeter()
    aux_loss_meter = AverageMeter()
    AT = torch.zeros(0, dtype=torch.float).cuda()
    AP = torch.zeros(0, dtype=torch.float).cuda()
    ATP = torch.zeros(0, dtype=torch.float).cuda()

    model.eval()
    end = time.time()
    for i, (image, label) in enumerate(val_loader):
        h = label.shape[2]
        w = label.shape[3]
        data_time.update(time.time() - end)
        image_in = image[:, 0, :, :].unsqueeze(1)
        image_in = image_in.cuda()
        label[:, 0, :, :] = label[:, 0, :, :] + label[:, 2, :, :]
        label[:, 2, :, :] = 0
        label = label.cuda()
        label_to_loss = label[:, 0, :, :].unsqueeze(1) / 255

        if (i + 1) % 10 == 0:
            if not os.path.exists(os.path.join(args.save_path, 'val/label', 'Epoch_{}'.format(epoch_log))):
                os.makedirs(os.path.join(args.save_path, 'val/label', 'Epoch_{}'.format(epoch_log)))
            label_path = os.path.join(args.save_path, 'val/label', 'Epoch_{}'.format(epoch_log))
            save_image(label.float(), os.path.join(label_path, '{}.png'.format(i)), nrow=args.batch_size_val)

        output_to_loss1, output_to_loss2 = model(image_in)
        zero = torch.zeros((args.batch_size, 2, h, w)).cuda()
        output_to_save = torch.cat((output_to_loss1, zero), dim=1)

        main_loss = criterion_main(output_to_loss1, label_to_loss.float())
        aux_loss = criterion_aux(output_to_loss2, label_to_loss.float())
        loss = main_loss + aux_loss
        n = image.size(0)
        if (i + 1) % 10 == 0:
            if not os.path.exists(os.path.join(args.save_path, 'val/image', 'Epoch_{}'.format(epoch_log))):
                os.makedirs(os.path.join(args.save_path, 'val/image', 'Epoch_{}'.format(epoch_log)))
            image_path = os.path.join(args.save_path, 'val/image', 'Epoch_{}'.format(epoch_log))
            save_image(255 * output_to_save.float(), os.path.join(image_path, '{}.png'.format(i)), nrow=args.batch_size_val)
        
        main_loss_meter.update(main_loss.item(), n)
        aux_loss_meter.update(aux_loss.item(), n)
        loss_meter.update(loss.item(), n)
        batch_time.update(time.time() - end)
        end = time.time()
        if (i + 1) % args.print_freq == 0:
            logger.info('Test: [{}/{}] '
                        'Data {data_time.val:.3f} ({data_time.avg:.3f}) '
                        'Batch {batch_time.val:.3f} ({batch_time.avg:.3f}) '
                        'Loss {loss_meter.val:.4f} ({loss_meter.avg:.4f}) '.format(i + 1, len(val_loader),
                                                                                   data_time=data_time,
                                                                                   batch_time=batch_time,
                                                                                   loss_meter=loss_meter))
            if not os.path.exists(os.path.join(args.save_path, 'val/loss')):
                os.makedirs(os.path.join(args.save_path, 'val/loss'))
            with open(os.path.join(args.save_path, 'val/loss',
                                   'Epoch{}_loss.txt'.format(epoch_log)), 'a') as loss_write:
                loss_write.write('Epoch:{}, iteration:{}, loss:{:.6f}\n'.format(epoch_log,
                                                                                i + 1,
                                                                                loss_meter.val))

        output_to_save[output_to_save >= args.threshold] = 1.0
        output_to_save[output_to_save < args.threshold] = 0.0
        output_to_loss1[output_to_loss1 >= args.threshold] = 1.0
        output_to_loss1[output_to_loss1 < args.threshold] = 0.0
        if (i + 1) % 10 == 0:
            if not os.path.exists(os.path.join(args.save_path, 'val_/image', 'Epoch_{}'.format(epoch_log))):
                os.makedirs(os.path.join(args.save_path, 'val_/image', 'Epoch_{}'.format(epoch_log)))
            image_path = os.path.join(args.save_path, 'val_/image', 'Epoch_{}'.format(epoch_log))
            save_image(255 * output_to_save.float(), os.path.join(image_path, '{}.png'.format(i)), nrow=8)
        # metric
        out = output_to_loss1
        target = label_to_loss
        T, P, TP = metric(out, target)
        AT = torch.cat([AT, T], dim=0)
        AP = torch.cat([AP, P], dim=0)
        ATP = torch.cat([ATP, TP], dim=0)

        dice_organ = (2 * TP + 1e-10) / (T + P + 1e-10)
        #loss_meter.update(loss.item(), n)
        #batch_time.update(time.time() - end)
        #end = time.time()


        if (i + 1) % args.print_freq == 0:
            logger.info('Test: [{}/{}] '
                        'Data {data_time.val:.3f} ({data_time.avg:.3f}) '
                        'Dice organ {:.4f} '
                        'Batch {batch_time.val:.3f} ({batch_time.avg:.3f}) '
                        'Loss {loss_meter.val:.4f} ({loss_meter.avg:.4f}) '.format(i + 1, len(val_loader),
                                                                                   dice_organ.sum() / args.batch_size_val,
                                                                                   data_time=data_time,
                                                                                   batch_time=batch_time,
                                                                                   loss_meter=loss_meter))

    dice, ppv, sensitivity = get_metric(AT, AP, ATP)
    dice_organ = dice.sum() / AT.shape[0]
    ppv_organ = ppv.sum() / AT.shape[0]
    sensitivity_organ = sensitivity.sum() / AT.shape[0]

    if not os.path.exists(os.path.join(args.save_path, 'metric')):
        os.makedirs(os.path.join(args.save_path, 'metric'))
    with open(os.path.join(args.save_path,
                           'metric',
                           'test_metric_epoch_{}.txt'.format(epoch_log)), 'a') as metric_write:
        metric_write.write('Test Reslt:\nAverage_loss:{:.6f}\nsensitivity_organ:{:.4f}\n'
                           'Dice organ:{:.4f}\n'
                           'PPv_organ:{:.4f}\n'.format(loss_meter.avg,
                                                       sensitivity_organ,
                                                       dice_organ,
                                                       ppv_organ))

    if not os.path.exists(os.path.join(args.save_path, 'val/metric')):
        os.makedirs(os.path.join(args.save_path, 'val/metric'))
    with open(os.path.join(args.save_path, 'val/metric',
                           'm.txt'), 'a') as metric_write:
        metric_write.write('Epoch:{}--Epoch_Avg_Loss:{:6f}\n'.format(epoch_log, loss_meter.avg))

    logger.info('Val result: Epoch_Avg_Loss{:.6f}.'.format(loss_meter.avg))

    logger.info('<<<<<<<<<<<<<<<<< End Evaluation <<<<<<<<<<<<<<<<<')

    return loss_meter.avg, main_loss_meter.avg, aux_loss_meter.avg, dice_organ


def test(val_loader, model, criterion_main, criterion_aux, epoch):
    logger.info('>>>>>>>>>>>>>>>> Start Test >>>>>>>>>>>>>>>>')
    batch_time = AverageMeter()
    data_time = AverageMeter()
    main_loss_meter = AverageMeter()
    aux_loss_meter = AverageMeter()
    loss_meter = AverageMeter()
    AT = torch.zeros(0, dtype=torch.float).cuda()
    AP = torch.zeros(0, dtype=torch.float).cuda()
    ATP = torch.zeros(0, dtype=torch.float).cuda()

    model.eval()
    end = time.time()
    for i, (image, label) in enumerate(val_loader):
        h = label.shape[2]
        w = label.shape[3]
        data_time.update(time.time() - end)
        image_in = image[:, 0, :, :].unsqueeze(1)
        image_in = image_in.cuda()
        label[:, 0, :, :] = label[:, 0, :, :] + label[:, 2, :, :]
        label[:, 2, :, :] = 0
        label = label.cuda()
        label_to_loss = label[:, 0, :, :].unsqueeze(1) / 255

        if not os.path.exists(os.path.join(args.save_path, 'test/Epoch_{}/label'.format(epoch))):
            os.makedirs(os.path.join(args.save_path, 'test/Epoch_{}/label'.format(epoch)))
        label_path = os.path.join(args.save_path, 'test/Epoch_{}/label'.format(epoch))
        save_image(label.float(), os.path.join(label_path, '{}.png'.format(i)), nrow=args.batch_size_val)

        output_to_loss1, output_to_loss2 = model(image_in)
        zero = torch.zeros((args.batch_size_val, 2, h, w)).cuda()
        output_to_save = torch.cat((output_to_loss1, zero), dim=1)

        output_to_save[output_to_save >= 0.5] = 1.0
        output_to_save[output_to_save < 0.5] = 0.0

        main_loss = criterion_main(output_to_loss1, label_to_loss.float())
        aux_loss = criterion_aux(output_to_loss2, label_to_loss.float())
        loss = main_loss + aux_loss
        n = image.size(0)

        output_to_loss1[output_to_loss1 >= 0.5] = 1.0
        output_to_loss1[output_to_loss1 < 0.5] = 0.0

        if not os.path.exists(os.path.join(args.save_path, 'test/Epoch_{}/image'.format(epoch))):
            os.makedirs(os.path.join(args.save_path, 'test/Epoch_{}/image'.format(epoch)))
        image_path = os.path.join(args.save_path, 'test/Epoch_{}/image'.format(epoch))
        save_image(255 * output_to_save.float(), os.path.join(image_path, '{}.png'.format(i)), nrow=args.batch_size_val)

        # metric
        out = output_to_loss1
        target = label_to_loss
        T, P, TP = metric(out, target)
        AT = torch.cat([AT, T], dim=0)
        AP = torch.cat([AP, P], dim=0)
        ATP = torch.cat([ATP, TP], dim=0)

        dice_organ = (2 * TP + 1e-10) / (T + P + 1e-10)
        loss_meter.update(loss.item(), n)
        main_loss_meter.update(main_loss.item(), n)
        aux_loss_meter.update(aux_loss.item(), n)
        batch_time.update(time.time() - end)
        end = time.time()

        # writer.add_scalar('Loss_test', loss_meter.val, i + 1)

        if (i + 1) % args.print_freq == 0:
            logger.info('Test: [{}/{}] '
                        'Data {data_time.val:.3f} ({data_time.avg:.3f}) '
                        'Dice organ {:.4f} '
                        'Batch {batch_time.val:.3f} ({batch_time.avg:.3f}) '
                        'Loss {loss_meter.val:.4f} ({loss_meter.avg:.4f}) '.format(i + 1, len(val_loader),
                                                                                   dice_organ.sum() / args.batch_size_val,
                                                                                   data_time=data_time,
                                                                                   batch_time=batch_time,
                                                                                   loss_meter=loss_meter))
            # logger.info('Evaluation: Sensitivity mean {:.4f} '
            #             'Dice mean {:.4f} '.format(sensitive_mean_meter.avg,
            #                                        Dice_mean_meter.avg))

            # if not os.path.exists(os.path.join(args.save_path, 'test/loss')):
            #     os.makedirs(os.path.join(args.save_path, 'test/loss'))
            # with open(os.path.join(args.save_path,
            #                        'test/loss',
            #                        'loss.txt'), 'a') as loss_write:
            #     loss_write.write('Test, iteration:{}, loss:{:.6f}'.format(i + 1, loss_meter.val))

    dice, ppv, sensitivity = get_metric(AT, AP, ATP)
    dice_organ = dice.sum()/AT.shape[0]
    ppv_organ = ppv.sum() / AT.shape[0]
    sensitivity_organ = sensitivity.sum() / AT.shape[0]

    if not os.path.exists(os.path.join(args.save_path, 'test', 'metric')):
        os.makedirs(os.path.join(args.save_path, 'test', 'metric'))
    with open(os.path.join(args.save_path,
                           'test/metric',
                           'test_metric.txt'), 'a') as metric_write:
        metric_write.write('Epoch_{}Test Reslt:\nAverage_loss:{:.6f}\nsensitivity_organ:{:.4f}\n'
                           'Dice organ:{:.4f}\n'
                           'PPv_organ:{:.4f}\n'.format(epoch,
                                                       loss_meter.avg,
                                                       sensitivity_organ,
                                                       dice_organ,
                                                       ppv_organ))

    logger.info('<<<<<<<<<<<<<<<<< End Test <<<<<<<<<<<<<<<<<')

    return loss_meter.avg, main_loss_meter.avg, aux_loss_meter.avg, dice_organ


def main():
    # train data
    train_transform = transform.Compose([
        transform.RandRotate([args.rotate_min, args.rotate_max], padding=[0, 0, 0], ignore_label=[0, 0, 0]),
        transform.Crop(496, crop_type='center', padding=[0, 0, 0]),
        transform.RandomGaussianBlur(),
        transform.RandomHorizontalFlip(),
        transform.ToTensor()])
    train_data = dataset.SemData(split='train', data_root=args.data_root, data_list=args.train_list,
                                 transform=train_transform)
    train_loader = torch.utils.data.DataLoader(train_data, batch_size=args.batch_size,
                                               shuffle=True,
                                               num_workers=args.workers, pin_memory=True,
                                               drop_last=True)
    # val data
    val_transform = transform.Compose([
        # transform.RandRotate([args.rotate_min, args.rotate_max], padding=[0, 0, 0], ignore_label=[0, 0, 0]),
        transform.Crop(496, crop_type='center', padding=[0, 0, 0]),
        # transform.RandomGaussianBlur(),
        # transform.RandomHorizontalFlip(),
        transform.ToTensor()])
    val_data = dataset.SemData(split='val', data_root=args.data_root, data_list=args.val_list, transform=val_transform)
    val_loader = torch.utils.data.DataLoader(val_data, batch_size=args.batch_size_val, shuffle=False,
                                             num_workers=args.workers, pin_memory=True, drop_last=True)
    
    test_data = dataset.SemData(split='val', data_root=args.data_root, data_list=args.test_list, transform=val_transform)
    test_loader = torch.utils.data.DataLoader(test_data, batch_size=args.batch_size_val, shuffle=False,
                                             num_workers=args.workers, pin_memory=True, drop_last=True) 
    criterion_m = DiceLoss()
    criterion_a = nn.BCELoss()
    
    torch.cuda.manual_seed_all(0)
    model = UNet(num_classes=1, in_channels=1, depth=5,
                 start_filts=64, up_mode='transpose',
                 merge_mode='concat')
    logger.info(model)
    # checkpoint = torch.load(args.checkpoint_path)
    model = torch.nn.DataParallel(model.cuda())
    # model.load_state_dict(checkpoint['state_dict'])
    optimizer = torch.optim.Adam(model.parameters(), lr=args.base_lr, weight_decay=args.weight_decay)
    # scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[10, 30, 50], gamma=0.1)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=0.0000001)
    for epoch in range(args.start_epoch, args.epochs):
        epoch_log = epoch + 1
        loss_train, main_loss_train, aux_loss_train = train(train_loader, model, optimizer, epoch, criterion_m, criterion_a, epoch_log)
        writer.add_scalar('loss_train', loss_train, epoch_log)
        writer.add_scalar('main_loss_train', main_loss_train, epoch_log)
        writer.add_scalar('aux_loss_train', aux_loss_train, epoch_log)

        if epoch_log % args.save_freq == 0:
            filename = args.save_path + '/train_epoch_' + str(epoch_log) + '.pth'
            logger.info('Saving checkpoint to: ' + filename)
            torch.save({'epoch': epoch_log, 'state_dict': model.state_dict(), 'optimizer': optimizer.state_dict()},
                       filename)
            # if epoch_log / args.save_freq > 2:
            #     deletename = args.save_path + '/train_epoch_' + str(epoch_log - args.save_freq * 2) + '.pth'
            #     os.remove(deletename)
        with torch.no_grad():
            loss_val, main_loss_val, aux_loss_val, dice_organ = validation(val_loader, model, criterion_m, criterion_a, epoch_log)
            writer.add_scalar('loss_val', loss_val, epoch_log)
            writer.add_scalar('main_loss_val', main_loss_val, epoch_log)
            writer.add_scalar('aux_loss_val', aux_loss_val, epoch_log)
            writer.add_scalar('Dice_organ', dice_organ, epoch_log)

            loss_test, main_loss_t, aux_loss_t, dice_organ_t= test(test_loader, model, criterion_m, criterion_a, epoch_log)
            writer.add_scalar('loss_test', loss_test, epoch_log)
            writer.add_scalar('main_loss_test', main_loss_t, epoch_log)
            writer.add_scalar('aux_loss_test', aux_loss_t, epoch_log)
            writer.add_scalar('Test_Dice_organ', dice_organ_t, epoch_log) 
       
        scheduler.step(epoch_log)


if __name__ == '__main__':
    if not os.path.exists(args.save_path):
        os.mkdir(args.save_path)
    os.environ["CUDA_VISIBLE_DEVICES"] = '1'
    with open(os.path.join(args.save_path, 'info.txt'), 'a') as network_information:
        network_information.write('Base_lr:{} \nEpochs:{} \nStart_epoch:{} \nData_root:{} \nTrain_list:{} \n'
                                  'Val_list:{} \nTest_list:{} \nMomentum:{} \nWeight_decay:{} \nSave_path:{} \n'
                                  'Batch_size:{} \nBatch_size_val:{} \nSave_freq:{} \nRotate_min:{} \nRotate_max:{} \n'
                                  'Power:{} \nClasses:{}'.format(args.base_lr, args.epochs, args.start_epoch,
                                                                 args.data_root, args.train_list, args.val_list,
                                                                 args.test_list, args.momentum, args.weight_decay,
                                                                 args.save_path, args.batch_size, args.batch_size_val,
                                                                 args.save_freq, args.rotate_min,
                                                                 args.rotate_max, args.power, args.classes))

    main()
