import torch
import os
import sys
sys.path.append('..')
from utils.util import AverageMeter, intersectionAndUnionGPU
import logging
import torch.nn as nn
# from model.Unet_1pc_conv_cat_aspp import UNet
from model.Unet_1pc_conv_cat_aspp_organ import UNet
# from model.Unet_cbam import UNet
# from model.Unet_se import UNet
import time
from utils import dataset, transform
import torch.utils.data
import numpy as np
from torchvision.utils import save_image
import argparse
from tensorboardX import SummaryWriter
from PIL import Image
from torchvision.transforms import transforms
import matplotlib.pyplot as plt
from tqdm import tqdm
import cv2


def metric(tensorpr,tensorgt):
    ttensorpr = tensorpr
    ttensorgt = tensorgt
    #print('rewrite done')

    intersection = ttensorpr * ttensorgt
    #print(intersection.size())
    #print('inter done')
    T = ttensorgt.sum((2, 3)).float()  # shape: b*c
    P = ttensorpr.sum((2, 3)).float()  # shape: b*c
    TP = intersection.sum((2, 3)).float()  # shape: b*c

    return T, P, TP


def get_metric(T, P, TP):
    dice = ((2*TP) + 1e-10) / (T+P+1e-10)
    ppv = (TP+1e-10) / (P+1e-10)
    sensitivity = (TP+1e-10) / (T+1e-10)
    return dice, ppv, sensitivity


def get_logger():
    logger_name = "main-logger"
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    fmt = "[%(asctime)s %(levelname)s %(filename)s line %(lineno)d %(process)d] %(message)s"
    handler.setFormatter(logging.Formatter(fmt))
    logger.addHandler(handler)
    return logger


def test(val_loader, model, criterion, args, logger, writer):
    logger.info('>>>>>>>>>>>>>>>> Start Test >>>>>>>>>>>>>>>>')
    batch_time = AverageMeter()
    data_time = AverageMeter()
    loss_meter = AverageMeter()
    AT = torch.zeros(0, dtype=torch.float).cuda()
    AP = torch.zeros(0, dtype=torch.float).cuda()
    ATP = torch.zeros(0, dtype=torch.float).cuda()

    model.eval()
    end = time.time()
    for i, (image, label) in enumerate(val_loader):
        h = label.shape[2]
        w = label.shape[3]
        data_time.update(time.time() - end)
        image_in = image[:, 0, :, :].unsqueeze(1)
        image_in = image_in.cuda()
        label[:, 0, :, :] = label[:, 0, :, :] + label[:, 2, :, :]
        label = label.cuda()
        label_to_loss = torch.cat((label[:, 0, :, :].unsqueeze(1), label[:, 2, :, :].unsqueeze(1)), dim=1)
        label_to_loss = label_to_loss / 255

        if not os.path.exists(os.path.join(args.save_path, 'label')):
            os.makedirs(os.path.join(args.save_path, 'label'))
        label_path = os.path.join(args.save_path, 'label')
        save_image(label.float(), os.path.join(label_path, '{}.png'.format(i)), nrow=args.batch_size_val)

        label_r = label[:, 0, :, :] / 255
        label_b = label[:, 2, :, :] / 255

        output_to_loss = model(image_in)
        zero = torch.zeros((args.batch_size_val, 1, h, w)).cuda()
        output_to_save_ = torch.cat((output_to_loss[:, 0, :, :].unsqueeze(1), zero), dim=1)
        output_to_save = torch.cat((output_to_save_, output_to_loss[:, 1, :, :].unsqueeze(1)), dim=1)

        output_to_save[output_to_save >= 0.5] = 1.0
        output_to_save[output_to_save < 0.5] = 0.0

        loss = criterion(output_to_loss, label_to_loss.float())
        n = image.size(0)

        if not os.path.exists(os.path.join(args.save_path, 'image')):
            os.makedirs(os.path.join(args.save_path, 'image'))
        image_path = os.path.join(args.save_path, 'image')
        save_image(255 * output_to_save.float(), os.path.join(image_path, '{}.png'.format(i)), nrow=args.batch_size_val)

        # metric
        out = torch.cat((output_to_save[:, 0, :, :].unsqueeze(1), output_to_save[:, 2, :, :].unsqueeze(1)), dim=1)
        target = label_to_loss
        T, P, TP = metric(out, target)
        AT = torch.cat([AT, T], dim=0)
        AP = torch.cat([AP, P], dim=0)
        ATP = torch.cat([ATP, TP], dim=0)

        dice_organ = (2 * TP[:, 0] + 1e-10) / (T[:, 0] + P[:, 0] + 1e-10)
        dice_tumor = (2 * TP[:, 1] + 1e-10) / (T[:, 1] + P[:, 1] + 1e-10)
        dice = (dice_tumor.sum() + dice_organ.sum()) / args.batch_size_val / 2

        loss_meter.update(loss.item(), n)
        batch_time.update(time.time() - end)
        end = time.time()

        writer.add_scalar('Loss_test', loss_meter.val, i + 1)

        if (i + 1) % args.print_freq == 0:
            logger.info('Test: [{}/{}] '
                        'Data {data_time.val:.3f} ({data_time.avg:.3f}) '
                        'Dice {:.4f} '
                        'Dice tumor {:.4f} '
                        'Dice organ {:.4f} '
                        'Batch {batch_time.val:.3f} ({batch_time.avg:.3f}) '
                        'Loss {loss_meter.val:.4f} ({loss_meter.avg:.4f}) '.format(i + 1, len(val_loader),
                                                                                   dice,
                                                                                   dice_tumor.sum() / args.batch_size_val,
                                                                                   dice_organ.sum() / args.batch_size_val,
                                                                                   data_time=data_time,
                                                                                   batch_time=batch_time,
                                                                                   loss_meter=loss_meter))
            # logger.info('Evaluation: Sensitivity mean {:.4f} '
            #             'Dice mean {:.4f} '.format(sensitive_mean_meter.avg,
            #                                        Dice_mean_meter.avg))

            if not os.path.exists(os.path.join(args.save_path, 'loss')):
                os.makedirs(os.path.join(args.save_path, 'loss'))
            with open(os.path.join(args.save_path,
                                   'loss',
                                   'loss.txt'), 'a') as loss_write:
                loss_write.write('Test, iteration:{}, loss:{:.6f}'.format(i + 1, loss_meter.val))

    dice, ppv, sensitivity = get_metric(AT, AP, ATP)
    dice_tumor = dice[:, 1].sum() / AT.shape[0]
    dice_organ = dice[:, 0].sum()/AT.shape[0]
    ppv_tumor = ppv[:, 1].sum() / AT.shape[0]
    ppv_organ = ppv[:, 0].sum() / AT.shape[0]
    sensitivity_tumor = sensitivity[:, 1].sum() / AT.shape[0]
    sensitivity_organ = sensitivity[:, 0].sum() / AT.shape[0]

    if not os.path.exists(os.path.join(args.save_path, 'metric')):
        os.makedirs(os.path.join(args.save_path, 'metric'))
    with open(os.path.join(args.save_path,
                           'metric',
                           'test_metric.txt'), 'a') as metric_write:
        metric_write.write('Test Reslt:\nAverage_loss:{:.4f}\n'
                           'sensitivity_mean:{:.4f}\nDice tumor {}\nDice organ {}\nDice_mean:{:.4f}\n'
                           'PPv_tumor:{:.4f}\nPPv_organ:{:.4f}'
                           'PPv_mean{:.4f}\n'.format(loss_meter.avg,
                                                     (sensitivity_organ + sensitivity_tumor) / 2,
                                                     dice_tumor,
                                                     dice_organ,
                                                     (dice_organ + dice_tumor) / 2,
                                                     ppv_tumor,
                                                     ppv_organ,
                                                     (ppv_organ + ppv_tumor) / 2))

    logger.info('<<<<<<<<<<<<<<<<< End Test <<<<<<<<<<<<<<<<<')

    return loss_meter.avg

# def visualization(model, loader, args, logger):
#     logger.info('>>>>>>>>>>>>>>>> Start Test >>>>>>>>>>>>>>>>')
#     batch_time = AverageMeter()
#     data_time = AverageMeter()
#     loss_meter = AverageMeter()
#     AT = torch.zeros(0, dtype=torch.float).cuda()
#     AP = torch.zeros(0, dtype=torch.float).cuda()
#     ATP = torch.zeros(0, dtype=torch.float).cuda()
#
#     model.eval()
#     end = time.time()
#     for i, (image, label, image_name) in enumerate(loader):
#         h = label.shape[2]
#         w = label.shape[3]
#         data_time.update(time.time() - end)
#         image_in = image[:, 0, :, :].unsqueeze(1)
#         image_in = image_in.cuda()
#         label[:, 0, :, :] = label[:, 0, :, :] / 255
#         label = label.cuda()
#
#         output1, output2 = model(image_in)
#         zero = torch.zeros((args.batch_size_val, 2, h, w)).cuda()
#         output_to_save = torch.cat((output1[:, 0, :, :].unsqueeze(1), zero), dim=1)
#
#         output_to_save[output_to_save >= 0.5] = 1.0
#         output_to_save[output_to_save < 0.5] = 0.0
#
#
#         if not os.path.exists(os.path.join(args.save_path, 'prediction')):
#             os.makedirs(os.path.join(args.save_path, 'prediction'))
#         image_path = os.path.join(args.save_path, 'prediction')
#         save_image(255 * output_to_save.float(), os.path.join(image_path, image_name[0]), nrow=args.batch_size_val)
#
#         if not os.path.exists(os.path.join(args.save_path, 'gt')):
#             os.makedirs(os.path.join(args.save_path, 'gt'))
#         gt_path = os.path.join(args.save_path, 'gt')
#         save_image(255 * label.float(), os.path.join(gt_path, image_name[0]), nrow=args.batch_size_val)
#
#         # metric
#         out = output1
#         target = label
#         T, P, TP = metric(out, target)
#         AT = torch.cat([AT, T], dim=0)
#         AP = torch.cat([AP, P], dim=0)
#         ATP = torch.cat([ATP, TP], dim=0)
#
#         dice_organ = (2 * TP[:, 0] + 1e-10) / (T[:, 0] + P[:, 0] + 1e-10)
#         batch_time.update(time.time() - end)
#         end = time.time()
#
#     dice, ppv, sensitivity = get_metric(AT, AP, ATP)
#     dice_organ = dice[:, 0].sum()/AT.shape[0]
#     ppv_organ = ppv[:, 0].sum() / AT.shape[0]
#     sensitivity_organ = sensitivity[:, 0].sum() / AT.shape[0]
#
#     return dice_organ, ppv_organ, sensitivity_organ



def main():
    parser = argparse.ArgumentParser(description='Test')
    parser.add_argument('--data_root', default='')
    parser.add_argument('--test_list', default='')
    parser.add_argument('--save_path', default='./')
    parser.add_argument('--save_freq', default=5, type=int)
    parser.add_argument('--print_freq', default=5, type=int)
    parser.add_argument('--batch_size_val', default=1, type=int)
    parser.add_argument('--checkpoint_path', default='../')
    parser.add_argument('--classes', default=2, help='num_classes')
    parser.add_argument('--workers', default=1)
    args = parser.parse_args()

    logger = get_logger()
    writer = SummaryWriter(args.save_path)

    if not os.path.exists(args.save_path):
        os.makedirs(args.save_path)

    # 最终模型
    model = UNet(num_classes=1, in_channels=1, depth=5,
                 start_filts=64, up_mode='transpose',
                 merge_mode='concat')
    # # CBAM模型
    # model = UNet(num_classes=1, in_channels=1, depth=5,
    #              start_filts=64, up_mode='transpose',
    #              merge_mode='concat')
    logger.info(model)
    checkpoint = torch.load(args.checkpoint_path)
    model = torch.nn.DataParallel(model.cuda())
    model.load_state_dict(checkpoint['state_dict'])
    test_transform = transform.Compose([
                                        # transform.RandRotate([args.rotate_min, args.rotate_max], padding=0, ignore_label=0),
                                        transform.Crop(496, crop_type='center', padding=[0, 0, 0]),
                                        # transform.RandomGaussianBlur(),
                                        # transform.RandomHorizontalFlip(),
                                        transform.ToTensor()])

    test_data = dataset.SemDataTest(split='val', data_root=args.data_root, data_list=args.test_list, transform=test_transform)
    val_loader = torch.utils.data.DataLoader(test_data, batch_size=args.batch_size_val, shuffle=False,
                                             num_workers=args.workers, pin_memory=True, drop_last=True)

    model.eval()

    attn_weights = []

    print(model)

    # hooks = [
    #     model.module.PC_Att.point_att.softmax.register_forward_hook(
    #         lambda self, input, output: attn_weights.append(output)
    #     )
    # ]

    # hooks = [
    #     model.module.down_convs[4].pc_attention.point_attention.register_forward_hook(
    #         lambda self, input, output: attn_weights.append(output)
    #     )
    # ]  hook pc_attention
    # hooks = [
    #     model.module.down_convs[4].relu.register_forward_hook(
    #         lambda self, input, output: attn_weights.append(output)
    #     )
    # ] # hook 最后下采样最后一层的relu

    hooks = [
        model.module.up_convs[0].conv2.register_forward_hook(
            lambda self, input, output: attn_weights.append(output)
        )]  # se and cbam

    for img, label, name in val_loader:
        image = img
        model(image[:, 0, :, :].unsqueeze(1))
        name = name[0]

        for hook in hooks:
            hook.remove()
        feature = attn_weights

        # 对注意模块加权后的权重进行可视化
        # feature = np.average(feature[0].detach().cpu().numpy()[0], axis=0)
        feature = feature[0].detach().cpu().numpy()[0]
        print(name)
        if not os.path.exists(os.path.join(args.save_path, 'test_{}'.format(name.split('.')[0]))):
            os.makedirs(os.path.join(args.save_path, 'test_{}'.format(name.split('.')[0])))
        import copy

        # visualize avg
        a = np.average(feature, axis=0)
        print(a.shape)
        a = ((a - a.min()) / (a.max() - a.min())) * 255
        resize_map = cv2.resize(a, (512, 512), cv2.INTER_LINEAR)
        resize_map = cv2.applyColorMap(np.uint8(resize_map), cv2.COLORMAP_JET)
        cv2.imwrite(os.path.join(args.save_path, 'test_{}'.format(name.split('.')[0]), 'map{}.png'.format('avg')),
                    resize_map)

        # visualize every layer
        # for i in tqdm(range(512)):
        #     a = copy.deepcopy(feature[i])
        #     if a.max == 0:
        #         continue
        #     a = ((a - a.min()) / (a.max() - a.min())) * 255
        #     resize_map = cv2.resize(a, (512, 512), cv2.INTER_LINEAR)
        #     resize_map = cv2.applyColorMap(np.uint8(resize_map), cv2.COLORMAP_JET)
        #     cv2.imwrite(os.path.join(args.save_path, 'test_{}'.format(name.split('.')[0]), 'map{}.png'.format(i)), resize_map)


    """
    # 对point attention 进行的reshape可视化
    feature = attn_weights[0].squeeze(0).reshape(31, 31, 31, 31).detach().cpu().numpy()
    if not os.path.exists(os.path.join(args.save_path, name[0].split('.')[0])):
        os.makedirs(os.path.join(args.save_path, name[0].split('.')[0]))

    for i in tqdm(range(31)):
        for j in range(31):
            resize_map = cv2.resize(feature[i, j], (512, 512), cv2.INTER_LINEAR)
            # resize_map = cv2.applyColorMap(resize_map, cv2.COLORMAP_CIVIDIS)
            # cv2.imwrite(os.path.join(args.save_path, name[0].split('.')[0], 'map{}_{}.png'.format(i, j)), resize_map)
            fig, axs = plt.subplots(ncols=1, nrows=1)
            axs.imshow(resize_map, interpolation='nearest',  cmap='cividis')
            axs.axis('off')

            fig.tight_layout()
            fig.savefig(os.path.join(args.save_path, name[0].split('.')[0], 'map{}_{}.png'.format(i, j)))
            plt.close()
    """
    # with torch.no_grad():
    #     dice, ppv, sensitivity = visualization(model, val_loader, args, logger)
    #     print(dice, ppv, sensitivity)


if __name__ == '__main__':
    main()
