# Collaborative Attention Guided Multi-Scale Feature Fusion Network for Medical Image Segmentation

This repository is the official implementation of TNSE paper [Collaborative Attention Guided Multi-Scale Feature Fusion Network for Medical Image Segmentation](https://ieeexplore.ieee.org/document/10316669). 

## Usage
### Requirements

To install requirements:

```setup
pip install -r requirements.txt
```
### Datasets
To download datasets:
- [TCIA](https://dev.cancerimagingarchive.net/)
- [MSD](https://decathlon-10.grand-challenge.org/)
- [KiTS](https://kits19.grand-challenge.org/data/)
- [Cardiac](https://www.cardiacatlas.org/)


### Training

To train the model, run this command:

```train
python train.py
```

### Evaluation

To evaluate the model, run this command:
```eval
python test.py 
```

## Citation

If CoAG-MuSFu is useful for your research, please consider citing:

@ARTICLE{10316669,
  author={Xu, Zhenghua and Tian, Biao and Liu, Shijie and Wang, Xiangtao and Yuan, Di and Gu, Junhua and Chen, Junyang and Lukasiewicz, Thomas and Leung, Victor C. M.},
  journal={IEEE Transactions on Network Science and Engineering}, 
  title={Collaborative Attention Guided Multi-Scale Feature Fusion Network for Medical Image Segmentation}, 
  year={2023},
  volume={},
  number={},
  pages={1-15},
  doi={10.1109/TNSE.2023.3332810}}

 If you have some issues, please contact liushijiea@163.com